﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration";
import LoginPage from "../../../../../authentication/functions/login-page";
import CostCentersIndexSelector from "../selectors/cost-centers.index.selector";
import CostCentersDetailSelector from "../selectors/cost-centers.detail.selector";
import ManageCostCenters from "../functions/manage-cost-centers"

const config = new Configuration();
const login = new LoginPage();
const detailsSelector = new CostCentersDetailSelector();
const indexSelector = new CostCentersIndexSelector();
const costCenter = new ManageCostCenters()

fixture`Finance - Cost center: Create Cost center`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach();
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
    })

test.meta({ type: 'base' })
    ('#36334: Check create Cost center when use Save and Close button', async t => {
        const createTC1 = new ManageCostCenters()

        //Create Cost center
        await createTC1.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        await createTC1.filterCostCenters(createTC1.costCentersValue)
        //Assert 
        await t
            .expect(indexSelector.costCentersTable.innerText).contains(createTC1.costCentersValue)
           // .expect(indexSelector.costCentersTable.innerText).contains(createTC1.nameValue)
        //Delete Cost center
        await createTC1.deleteCostCenter()
        await createTC1.filterCostCenters(createTC1.costCentersValue)
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    ('#36335: Check create Cost center when use Save and New button', async t => {
        const createTC2 = new ManageCostCenters()

        //Create Cost center
        await createTC2.createCostCenters()
        await t.click(detailsSelector.saveDropDownBtn)
        await t.click(detailsSelector.saveNewBtn)
        await t.click(detailsSelector.backBtn);
        //Assert 
        await createTC2.filterCostCenters(createTC2.costCentersValue)
        await t
            .expect(indexSelector.costCentersTable.innerText).contains(createTC2.costCentersValue)
            .expect(indexSelector.costCentersTable.innerText).contains(createTC2.nameValue)
        //Delete Cost center
        await createTC2.deleteCostCenter()
        await createTC2.filterCostCenters(createTC2.costCentersValue)
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36334: Check create Cost center when Cost center and company fields is duplicate', async t => {
        const createTC3 = new ManageCostCenters()

        //Create Cost center 1
        await createTC3.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)

        //Create Cost center 2
        await createTC3.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Diese Kostenstelle gibt es bereits')
            .click(detailsSelector.closeErrorMessage)
        //Back to Cost center list
        await t.click(detailsSelector.backBtn)
        //Delete Cost center
        await createTC3.filterCostCenters(createTC3.costCentersValue)
        await createTC3.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36336: Check create Cost center when Cost center is blank', async t => {
        //Create Cost center
        await costCenter.createCostCentersConfig(' ', 'Name Cost center')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to Cost center list
        await t.click(detailsSelector.backBtn)
    })

test.meta({ type: 'advance' })
    ('#36336: Check create Cost center when name field is blank', async t => {
        //Create Cost center
        await costCenter.createCostCentersConfig('Costcenter', ' ')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to Cost center list
        await t.click(detailsSelector.backBtn)
    })

test.meta({ type: 'advance' })
    ('#36338: Check create Cost center when Cost center field is more than 10 characters', async t => {
        //Create Cost center
        await costCenter.createCostCentersConfig('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', 'Name')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 10 Zeichen')
        //Back to Cost center list
        await t.click(detailsSelector.backBtn)
    })

test.meta({ type: 'advance' })
    ('#36338: Check create Cost center when Name field is more than 254 characters', async t => {
        //Create Cost center
        await costCenter.createCostCentersConfig('new code', 'Name Test new code Test new codeTest new codeTest new codeTest new codeTest  Test new code Test new codeTest new codeTest new codeTest new codeTest Name Test new code Test new codeTest new codeTest new codeTest new codeTest  Test new code Test new codeTes')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Maximale Länge: 254 Zeichen')
        //Back to Cost center list
        await t.click(detailsSelector.backBtn)
    })

