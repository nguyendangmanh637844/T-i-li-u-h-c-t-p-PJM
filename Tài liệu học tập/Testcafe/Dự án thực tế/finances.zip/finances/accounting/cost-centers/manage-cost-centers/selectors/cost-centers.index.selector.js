import { Selector } from "testcafe";

export default class CostCentersIndexSelector {
    constructor() {
        //Menu bar
        this.financeMenu = Selector('a').withText("Finanzen")
        this.accountingMenu = Selector('a').withText("Buchhaltung")
        this.costCentersMenu = Selector('a').withText("Kostenstellen")

        //List view
        this.addBtn = Selector('#btn-addNew');
        this.filterBox = Selector('div[class="dxbs-textbox"]');
        this.filterCost = Selector('.dxbs-grid-filter-row .dxbs-grid-table-border-bottom:nth-of-type(2) .dxbs-form-control');
        this.editBtn = Selector('#btn-edit');
        this.copyBtn = Selector('#btn-copy');
        this.deleteBtn = Selector('#btn-delete');
        this.confirmDeleteBtn = Selector('#btn-confirm-yes');
        this.cancelDeleteBtn = Selector('#btn-confirm-no');
        this.costCentersTable = Selector('div').withAttribute('class', 'dxbs-scroll-viewer-content');
        this.clearFilterBtn = Selector('button[class ="btn btn-sm dx-btn dxbs-edit-btn dxbs-clear-btn"]')

    }
};