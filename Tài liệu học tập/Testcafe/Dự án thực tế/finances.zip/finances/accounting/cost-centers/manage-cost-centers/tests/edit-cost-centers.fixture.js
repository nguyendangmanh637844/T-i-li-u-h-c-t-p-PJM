﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration";
import LoginPage from "../../../../../authentication/functions/login-page";
import CostCentersIndexSelector from "../selectors/cost-centers.index.selector";
import CostCentersDetailSelector from "../selectors/cost-centers.detail.selector";
import ManageCostCenters from "../functions/manage-cost-centers"

const config = new Configuration();
const login = new LoginPage();
const detailsSelector = new CostCentersDetailSelector();
const indexSelector = new CostCentersIndexSelector();
const costCenter = new ManageCostCenters()

fixture`Finance - Cost center: Edit Cost center`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach();
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
    })

test.meta({ type: 'base' })
    ('#36334: Check Edit Cost center when use Save and Close button', async t => {
        const createTC1 = new ManageCostCenters()
        const editTC1 = new ManageCostCenters()

        //Create Cost center
        await createTC1.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Edit Cost center
        await costCenter.filterCostCenters(createTC1.costCentersValue)
        await editTC1.editCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await costCenter.filterCostCenters(editTC1.costCentersEditValue)
        await t
            .expect(indexSelector.costCentersTable.innerText).contains(editTC1.costCentersEditValue)
            .expect(indexSelector.costCentersTable.innerText).contains(editTC1.nameEditValue)
        //Delete data
        await costCenter.deleteCostCenter()
        await costCenter.filterCostCenters(editTC1.costCentersEditValue)
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    ('#36335: Check Edit Cost center when use Save and New button', async t => {
        const createTC2 = new ManageCostCenters()
        const editTC2 = new ManageCostCenters()

        //Create Cost center
        await createTC2.createCostCenters()
        await t.click(detailsSelector.saveDropDownBtn)
        await t.click(detailsSelector.saveNewBtn)
        await t.click(detailsSelector.backBtn)
        //Edit Cost center
        await costCenter.filterCostCenters(createTC2.costCentersValue)
        await editTC2.editCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await costCenter.filterCostCenters(editTC2.costCentersEditValue)
        await t
            .expect(indexSelector.costCentersTable.innerText).contains(editTC2.costCentersEditValue)
            .expect(indexSelector.costCentersTable.innerText).contains(editTC2.nameEditValue)
        //Delete Cost center
        await costCenter.deleteCostCenter()
        await costCenter.filterCostCenters(editTC2.costCentersEditValue)
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36336: Check Edit Cost center when Cost center field is blank', async t => {
        const createTC3 = new ManageCostCenters()
        //Create Cost center
        await createTC3.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Edit Cost center
        await costCenter.filterCostCenters(createTC3.costCentersValue)
        await costCenter.editCostCentersConfig(' ', 'Kloon Name')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Delete data
        await t.click(detailsSelector.backBtn)
        await costCenter.filterCostCenters(createTC3.costCentersValue)
        await costCenter.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36337: Check Edit Cost center when duplicate Code&Company fields', async t => {
        const createTC4a = new ManageCostCenters()
        const createTC4b = new ManageCostCenters()

        //Create the first Cost center
        await createTC4a.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Create the second Cost center
        await createTC4b.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Edit the second Cost center
        await costCenter.filterCostCenters(createTC4b.costCentersValue)
        await costCenter.editCostCentersConfig(createTC4a.costCentersValue, 'Name')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Diese Kostenstelle gibt es bereits')
            .click(detailsSelector.closeErrorMessage)
        //Back to Cost center list
        await t.click(detailsSelector.backBtn)
        //Delete the first Cost center
        await costCenter.filterCostCenters(createTC4a.costCentersValue)
        await costCenter.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
        //Delete the second Cost center
        await costCenter.filterCostCenters(createTC4b.costCentersValue)
        await costCenter.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36338: Check Edit Cost center when Cost center field is more than 10 characters', async t => {
        const createTC5 = new ManageCostCenters()
        //Create Cost center
        await createTC5.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Edit Cost center
        await costCenter.filterCostCenters(createTC5.costCentersValue)
        await costCenter.editCostCentersConfig('Test new code', 'Plato Name')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 10 Zeichen')
        //Back to Cost center list
        await t.click(detailsSelector.backBtn)
        //Delete data
        await costCenter.filterCostCenters(createTC5.costCentersValue)
        await costCenter.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36339: Check Edit Cost center when Name field is blank', async t => {
        const createTC6 = new ManageCostCenters()
        //Create Cost center
        await createTC6.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Edit Cost center
        await costCenter.filterCostCenters(createTC6.costCentersValue)
        await costCenter.editCostCentersConfig('ACGCompany', ' ')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to Cost center list
        await t.click(detailsSelector.backBtn)
        //Delete data
        await costCenter.filterCostCenters(createTC6.costCentersValue)
        await costCenter.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36340: Check Edit Cost center when Name field is more than 254 characters', async t => {
        const createTC7 = new ManageCostCenters()
        //Create Cost center
        await createTC7.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Edit Cost center
        await costCenter.filterCostCenters(createTC7.costCentersValue)
        await costCenter.editCostCentersConfig('new code', 'Name Test new code Test new codeTest new codeTest new codeTest new codeTest  Test new code Test new codeTest new codeTest new codeTest new codeTest Name Test new code Test new codeTest new codeTest new codeTest new codeTest  Test new code Test new codeTes')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Maximale Länge: 254 Zeichen')
        //Back to Cost center list
        await t.click(detailsSelector.backBtn)
        //Delete data
        await costCenter.filterCostCenters(createTC7.costCentersValue)
        await costCenter.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })