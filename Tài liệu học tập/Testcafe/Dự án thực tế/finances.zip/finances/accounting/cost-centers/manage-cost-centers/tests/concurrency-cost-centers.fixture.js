﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration";
import LoginPage from "../../../../../authentication/functions/login-page";
import CostCentersIndexSelector from "../selectors/cost-centers.index.selector";
import CostCentersDetailSelector from "../selectors/cost-centers.detail.selector";
import ManageCostCenters from "../functions/manage-cost-centers"

const config = new Configuration();
const login = new LoginPage();
const detailsSelector = new CostCentersDetailSelector();
const indexSelector = new CostCentersIndexSelector();
const costCenter = new ManageCostCenters()

fixture`Finance - Cost center: Concurrency`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach();
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
    })

test.meta({ type: 'base' })
    ('#36153/#36166: Check concurrency when both users edit the same Cost center with Override option', async t => {
        const concurrencyTC1a = new ManageCostCenters()
        const concurrencyTC1b = new ManageCostCenters()
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);

        //Create Cost center at initial Window
        await t.switchToWindow(initialWindow);
        await concurrencyTC1a.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn);
        //Open detail view at initial Window
        await concurrencyTC1a.filterCostCenters(concurrencyTC1a.costCentersValue)
        await concurrencyTC1a.editCostCenters()

        //Open second browser
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
        //Open detail view at second Window and edit that record
        await concurrencyTC1b.filterCostCenters(concurrencyTC1a.costCentersValue)
        await concurrencyTC1b.editCostCenters()
        await t.click(detailsSelector.saveCloseBtn);

        //Open the first window
        await t.switchToWindow(initialWindow);
        await t
            .click(detailsSelector.saveCloseBtn)
            .wait(2000);
        //Assert
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert.')
            .expect(detailsSelector.errorMessage.innerText).contains('Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt.')
            .expect(detailsSelector.errorMessage.innerText).contains('Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben.')
            .expect(detailsSelector.errorMessage.innerText).contains('Widersprüchliche Informationen')
        //Assert informantion
        await t.expect(detailsSelector.errorMessage.innerText).contains(concurrencyTC1b.costCentersEditValue)
        await t.expect(detailsSelector.errorMessage.innerText).contains(concurrencyTC1b.nameEditValue)
        //Override information
        await t.click(detailsSelector.overrideBtn)
        //Assert
        await concurrencyTC1a.filterCostCenters(concurrencyTC1a.costCentersEditValue)
        await t
            .expect(indexSelector.costCentersTable.innerText).contains(concurrencyTC1a.costCentersEditValue)
        //Delete data
        await concurrencyTC1a.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    ('#36153/#36167: Check concurrency when both users edit the same Cost center with Refresh option', async t => {
        const concurrencyTC2a = new ManageCostCenters()
        const concurrencyTC2b = new ManageCostCenters()
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);

        //Create Cost center at initial Window
        await t.switchToWindow(initialWindow);
        await concurrencyTC2a.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn);
        //Open detail view at initial Window
        await concurrencyTC2a.filterCostCenters(concurrencyTC2a.costCentersValue)
        await concurrencyTC2a.editCostCenters()

        //Open second browser
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(4000)
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
        //Open detail view at second Window and edit that Cost center
        await concurrencyTC2a.filterCostCenters(concurrencyTC2a.costCentersValue)
        await concurrencyTC2b.editCostCenters()
        await t.click(detailsSelector.saveCloseBtn);

        //Open the first window
        await t.switchToWindow(initialWindow);
        await t
            .click(detailsSelector.saveCloseBtn)
            .wait(2000);
        //Assert 
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert.')
            .expect(detailsSelector.errorMessage.innerText).contains('Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt.')
            .expect(detailsSelector.errorMessage.innerText).contains('Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben.')
            .expect(detailsSelector.errorMessage.innerText).contains('Widersprüchliche Informationen')
        //Assert informantion
        await t.expect(detailsSelector.errorMessage.innerText).contains(concurrencyTC2b.costCentersEditValue)
        await t.expect(detailsSelector.errorMessage.innerText).contains(concurrencyTC2b.nameEditValue)
        //Refresh information
        await t.click(detailsSelector.refreshBtn)
        await t.wait(20000)
        //Assert
        await t.expect(detailsSelector.costCenterBox.value).contains(concurrencyTC2b.costCentersEditValue)
        await t.expect(detailsSelector.nameBox.value).contains(concurrencyTC2b.nameEditValue)
        await t.click(detailsSelector.backBtn)
        //Assert
        await concurrencyTC2b.filterCostCenters(concurrencyTC2b.costCentersEditValue)
        await t
            .expect(indexSelector.costCentersTable.innerText).contains(concurrencyTC2b.costCentersEditValue)
        //Delete data
        await concurrencyTC2b.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')

    });

test
    .meta({ type: 'base' })
    ('#36153/#36168: Check concurrency when both users edit the same Cost center with Cancel option', async t => {
        const concurrencyTC3a = new ManageCostCenters()
        const concurrencyTC3b = new ManageCostCenters()
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);

        //Create Cost center at initial Window
        await t.switchToWindow(initialWindow);
        await concurrencyTC3a.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn);
        //Open detail view at initial Window
        await concurrencyTC3a.filterCostCenters(concurrencyTC3a.costCentersValue)
        await concurrencyTC3a.editCostCenters()

        //Open second browser
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(4000)
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
        //Open detail view at second Window and edit that Cost center
        await concurrencyTC3a.filterCostCenters(concurrencyTC3a.costCentersValue)
        await concurrencyTC3b.editCostCenters()
        await t.click(detailsSelector.saveCloseBtn);

        //Open the first window
        await t.switchToWindow(initialWindow);
        await t
            .click(detailsSelector.saveCloseBtn)
            .wait(2000);
        //Assert
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert.')
            .expect(detailsSelector.errorMessage.innerText).contains('Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt.')
            .expect(detailsSelector.errorMessage.innerText).contains('Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben.')
            .expect(detailsSelector.errorMessage.innerText).contains('Widersprüchliche Informationen')
        //Assert informantion
        await t.expect(detailsSelector.errorMessage.innerText).contains(concurrencyTC3b.costCentersEditValue)
        await t.expect(detailsSelector.errorMessage.innerText).contains(concurrencyTC3b.nameEditValue)
        //Override information
        await t.click(detailsSelector.cancelBtn)
        //Assert
        await t.expect(detailsSelector.costCenterBox.value).contains(concurrencyTC3a.costCentersEditValue)
        await t.expect(detailsSelector.nameBox.value).contains(concurrencyTC3a.nameEditValue)
        await t.click(detailsSelector.backBtn)
        //Assert
        await concurrencyTC3b.filterCostCenters(concurrencyTC3b.costCentersEditValue)
        await t
            .expect(indexSelector.costCentersTable.innerText).contains(concurrencyTC3b.costCentersEditValue)
        //Delete data
        await concurrencyTC3b.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    });

test
    .meta({ type: 'base' })
    ('#36161: Check concurrency when both users delete the same Cost center', async t => {
        const concurrencyTC4 = new ManageCostCenters()
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);

        //Create Cost center at initial Window
        await t.switchToWindow(initialWindow);
        await concurrencyTC4.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn);
        //Open detail view at initial Window
        await concurrencyTC4.filterCostCenters(concurrencyTC4.costCentersValue)
        await t.click(indexSelector.deleteBtn)

        //Open second browser
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(4000)
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
        //Open detail view at second Window and edit that Cost center
        await concurrencyTC4.filterCostCenters(concurrencyTC4.costCentersValue)
        await concurrencyTC4.deleteCostCenter()

        //Open the first window
        await t.switchToWindow(initialWindow);
        await t
            .click(indexSelector.confirmDeleteBtn)
            .wait(2000)
            .expect(detailsSelector.errorMessage.innerText).contains('Kann nicht gelöscht werden. Der Datensatz wurde von einem anderen Benutzer gelöscht.')
            .click(detailsSelector.closeErrorMessage)

        //Assert
        await concurrencyTC4.filterCostCenters(concurrencyTC4.costCentersValue)
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    });

test
    .meta({ type: 'base' })
    ('#36155: Check concurrency when user 1 delete and user 2 edit the same Cost center', async t => {
        const concurrencyTC5 = new ManageCostCenters()
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);

        //Create Cost center at initial Window
        await t.switchToWindow(initialWindow);
        await concurrencyTC5.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn);
        //Open detail view at initial Window
        await concurrencyTC5.filterCostCenters(concurrencyTC5.costCentersValue)
        await t.click(indexSelector.deleteBtn)

        //Open second browser
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(4000)
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
        //Open detail view at second Window and edit that record
        await concurrencyTC5.filterCostCenters(concurrencyTC5.costCentersValue)
        await concurrencyTC5.editCostCenters()

        //Open the first window
        await t.switchToWindow(initialWindow);
        await t
            .click(indexSelector.confirmDeleteBtn)
            .wait(2000);

        //Open second browser
        await t.switchToWindow(window1);
        await t.click(detailsSelector.saveCloseBtn);
        //Assert
        await t.expect(detailsSelector.errorMessage.innerText).contains('Speichern nicht möglich. Die Datensatz wurde von einem anderen Benutzer gelöscht.')
        await t.click(detailsSelector.closeErrorMessage)
        //Assert
        await concurrencyTC5.filterCostCenters(concurrencyTC5.costCentersValue)
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    });

test
    .meta({ type: 'base' })
    ('#36155: Check concurrency when user 1 delete and user 2 click copy the same Cost center', async t => {
        const concurrencyTC6 = new ManageCostCenters()
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);

        //Create Account at initial Window
        await t.switchToWindow(initialWindow);
        await concurrencyTC6.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn);
        //Open detail view at initial Window
        await concurrencyTC6.filterCostCenters(concurrencyTC6.costCentersValue)

        //Open second browser
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(4000)
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
        //Open detail view at second Window and edit that record
        await concurrencyTC6.filterCostCenters(concurrencyTC6.costCentersValue)
        await concurrencyTC6.deleteCostCenter()

        //Open the first window
        await t.switchToWindow(initialWindow);
        await t
            .click(indexSelector.copyBtn)
            .wait(2000);

        //Assert
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz wurde von einem anderen Benutzer gelöscht.')
        await t.click(detailsSelector.closeErrorMessage)
    });

test
    .meta({ type: 'base' })
    ('#36155: Check concurrency when user 1 delete and user 2 click edit the same Cost center', async t => {
        const concurrencyTC7 = new ManageCostCenters()
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);

        //Create Account at initial Window
        await t.switchToWindow(initialWindow);
        await concurrencyTC7.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn);
        //Open detail view at initial Window
        await concurrencyTC7.filterCostCenters(concurrencyTC7.costCentersValue)

        //Open second browser
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(4000)
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
        //Open detail view at second Window and edit that record
        await concurrencyTC7.filterCostCenters(concurrencyTC7.costCentersValue)
        await concurrencyTC7.deleteCostCenter()

        //Open the first window
        await t.switchToWindow(initialWindow);
        await t
            .click(indexSelector.editBtn)
            .wait(2000);

        //Assert
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz wurde von einem anderen Benutzer gelöscht.')
        await t.click(detailsSelector.closeErrorMessage)
    });