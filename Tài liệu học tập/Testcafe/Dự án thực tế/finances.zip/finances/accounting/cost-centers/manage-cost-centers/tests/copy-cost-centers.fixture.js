﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration";
import LoginPage from "../../../../../authentication/functions/login-page";
import CostCentersIndexSelector from "../selectors/cost-centers.index.selector";
import CostCentersDetailSelector from "../selectors/cost-centers.detail.selector";
import ManageCostCenters from "../functions/manage-cost-centers"

const config = new Configuration();
const login = new LoginPage();
const detailsSelector = new CostCentersDetailSelector();
const indexSelector = new CostCentersIndexSelector();

fixture`Finance - Cost center: Copy Cost center`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach();
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.costCentersMenu);
    })

test.meta({ type: 'base' })
    ('#36334: Check Copy Cost center when use  Save and Close button', async t => {
        const manageTC1 = new ManageCostCenters()

        //Create  Cost center
        await manageTC1.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy  Cost center
        await manageTC1.filterCostCenters(manageTC1.costCentersValue)
        await manageTC1.copyCostCenters()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await manageTC1.filterCostCenters(manageTC1.costCenterCopyValue)
        await t
            .expect(indexSelector.costCentersTable.innerText).contains(manageTC1.costCenterCopyValue)
            .expect(indexSelector.costCentersTable.innerText).contains(manageTC1.nameValue);
        //Delete data
        await manageTC1.deleteCostCenter()
        await manageTC1.filterCostCenters(manageTC1.costCentersValue)
        await manageTC1.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    ('#36334: Check Cost center when use Save and New button', async t => {
        const manageTC2 = new ManageCostCenters()
        //Create Cost center
        await manageTC2.createCostCenters()
        await t.click(detailsSelector.saveCloseBtn);
        //Coppy Cost center
        await manageTC2.filterCostCenters(manageTC2.costCentersValue)
        await manageTC2.copyCostCenters()
        await t.click(detailsSelector.saveDropDownBtn)
        await t
            .click(detailsSelector.saveNewBtn)
            .click(detailsSelector.backBtn);
        //Assert 
        await manageTC2.filterCostCenters(manageTC2.costCenterCopyValue)
        await t
            .expect(indexSelector.costCentersTable.innerText).contains(manageTC2.costCenterCopyValue)
            .expect(indexSelector.costCentersTable.innerText).contains(manageTC2.nameValue);
        //Delete data
        await manageTC2.deleteCostCenter()
        await manageTC2.filterCostCenters(manageTC2.costCentersValue)
        await manageTC2.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36334: Check Copy Cost center when cost center field is blank', async t => {
        const manageTC4 = new ManageCostCenters()

        //Create Cost center
        await manageTC4.createCostCenters();
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy Cost center
        await manageTC4.filterCostCenters(manageTC4.costCentersValue)
        await manageTC4.copyCostCentersConfig()
        await t
            .click(detailsSelector.costCenterBox)
            .pressKey('ctrl+a delete')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
            .click(detailsSelector.backBtn);
        //Delete Cost center
        await manageTC4.filterCostCenters(manageTC4.costCentersValue)
        await manageTC4.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36334: Check Copy Cost center when Name field is blank', async t => {
        const manageTC5 = new ManageCostCenters()

        //Create Cost center
        await manageTC5.createCostCenters();
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy Cost center
        await manageTC5.filterCostCenters(manageTC5.costCentersValue)
        await manageTC5.copyCostCentersConfig()
        await t
            .click(detailsSelector.costCenterBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.costCenterBox, manageTC5.costCentersEditValue)
            .click(detailsSelector.nameBox)
            .pressKey('ctrl+a delete')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
            .click(detailsSelector.backBtn);
        //Delete Cost center
        await manageTC5.filterCostCenters(manageTC5.costCentersValue)
        await manageTC5.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36334: Check Copy Cost center when cost center field value is more than 10 characters', async t => {
        const manageTC3 = new ManageCostCenters()

        //Create Cost center
        await manageTC3.createCostCenters();
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy Cost center
        await manageTC3.filterCostCenters(manageTC3.costCentersValue)
        await manageTC3.copyCostCentersConfig()
        await t
            .click(detailsSelector.costCenterBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.costCenterBox,'Test - Kopieren')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 10 Zeichen')
            .click(detailsSelector.backBtn);
        //Delete Cost center
        await manageTC3.filterCostCenters(manageTC3.costCentersValue)
        await manageTC3.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36334: Check Copy Cost center when Name field value is more than 254 characters', async t => {
        const manageTC7 = new ManageCostCenters()

        //Create Cost center
        await manageTC7.createCostCenters();
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy Cost center
        await manageTC7.filterCostCenters(manageTC7.costCentersValue)
        await manageTC7.copyCostCentersConfig()
        await t
            .click(detailsSelector.costCenterBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.costCenterBox, manageTC7.costCentersEditValue)
            .click(detailsSelector.nameBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.nameBox, 'Name Test new code Test new codeTest new codeTest new codeTest new codeTest  Test new code Test new codeTest new codeTest new codeTest new codeTest Name Test new code Test new codeTest new codeTest new codeTest new codeTest  Test new code Test new codeTes')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Maximale Länge: 254 Zeichen')
            .click(detailsSelector.backBtn);
        //Delete Cost center
        await manageTC7.filterCostCenters(manageTC7.costCentersValue)
        await manageTC7.deleteCostCenter()
        await t.expect(indexSelector.costCentersTable.innerText).contains('Keine Daten zum Anzeigen')
    })

