import { Selector, t } from "testcafe"
import CostCentersIndexSelector from "../selectors/cost-centers.index.selector";
import CostCentersDetailSelector from "../selectors/cost-centers.detail.selector";
import Utils from "../../../../../../commons/utils";

const detailsSelector = new CostCentersDetailSelector();
const indexSelector = new CostCentersIndexSelector();
const randomData = new Utils();


export default class ManageCostCenters {
    constructor() {
        //create
        this.costCentersValue = randomData.getText('Cost_', 10);
        this.nameValue = randomData.getText('Cost_Centers_Name ', 20);
        //edit
        this.costCentersEditValue = randomData.getText('Edit_', 10);
        this.nameEditValue = randomData.getText('Edit Cost_Centers_Name ', 30);
        this.costCenterCopyValue = randomData.getText('Copy_', 10);

    }

    async filterCostCenters(code) {
        await t
            .click(indexSelector.filterCost)
            .pressKey('ctrl+a delete')
            .typeText(indexSelector.filterCost, code)
            .pressKey('enter')
    }

    async createCostCentersConfig(costCenter, name) {
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.costCenterBox, costCenter)
            .typeText(detailsSelector.nameBox, name)
    }

    async createCostCenters() {
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.costCenterBox, this.costCentersValue)
            .typeText(detailsSelector.nameBox, this.nameValue)
    }

    async fillvalue(value) {
        await t
            .click(type)
            .pressKey('ctrl+a delete')
            .typeText(value)
    }

    async editCostCentersConfig(costCenter, name) {
        await t
            .click(indexSelector.editBtn)
            .wait(2000)
            .click(detailsSelector.costCenterBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.costCenterBox, costCenter)
            .click(detailsSelector.nameBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.nameBox, name)
    }

    async editCostCenters() {
        //edit data
        await t
            .click(indexSelector.editBtn)
            .wait(2000)
            .click(detailsSelector.costCenterBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.costCenterBox, this.costCentersEditValue)
            .click(detailsSelector.nameBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.nameBox, this.nameEditValue)
    }

    async copyCostCentersConfig() {
        await t
            .click(indexSelector.editBtn)
            .wait(2000)
            .click(detailsSelector.copyBtn)
            .wait(3000)
            .expect(detailsSelector.costCenterBox.value).contains(' - Kopieren')
    }

    async copyCostCenters() {
        //edit data
        await t
            .click(indexSelector.editBtn)
            .wait(2000)
            .click(detailsSelector.copyBtn)
            .wait(3000)
            .expect(detailsSelector.costCenterBox.value).contains(' - Kopieren')
            .click(detailsSelector.costCenterBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.costCenterBox, this.costCenterCopyValue)
    }

    async deleteCostCenter() {
        await t
            .click(indexSelector.deleteBtn)
            .click(indexSelector.confirmDeleteBtn)
    }

}
