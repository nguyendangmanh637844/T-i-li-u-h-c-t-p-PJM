import { Selector, t } from "testcafe"
import CostCentersDetailSelector from "../../manage-cost-centers/selectors/cost-centers.detail.selector";
import PageDetails from "../selectors/page.details.selector";

const pageDetailCostCenter = new CostCentersDetailSelector();
const pageDetailTranslated = new PageDetails();

class CreateTranslateData {
    async createTranslate() {
        await t
            .click(pageDetailCostCenter.translateBtn)
            .typeText(pageDetailTranslated.nameDEbox, 'Name DE')
            .typeText(pageDetailTranslated.nameENbox, 'Name EN')
            .typeText(pageDetailTranslated.nameFRbox, 'Name FR')
            .click(pageDetailTranslated.saveBtn);
    }
}
export default CreateTranslateData