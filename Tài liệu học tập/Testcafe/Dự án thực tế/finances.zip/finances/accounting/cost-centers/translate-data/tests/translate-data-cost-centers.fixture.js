﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration";
import LoginPage from "../../../../../authentication/functions/login-page";
import CostCentersIndexSelector from "../../manage-cost-centers/selectors/cost-centers.index.selector";
import CostCentersDetailSelector from "../../manage-cost-centers/selectors/cost-centers.detail.selector";
import TranslateIndex from "../../../../../../commons/translate-selector"
import PageDetails from "../selectors/page.details.selector";
import ManageCostCenters from "../../manage-cost-centers/functions/manage-cost-centers";
import CreateTranslateData from "../functions/create-translate-data";
import EditTranslateData from "../functions/edit-translate-data";

const config = new Configuration();
const login = new LoginPage();
const detailsCostCenterSelector = new CostCentersDetailSelector();
const indexCostCenterSelector = new CostCentersIndexSelector();
const detailsTranslateSelector = new PageDetails();
const indexTranslateSelector = new TranslateIndex();
const createTranslateFunction = new CreateTranslateData();
const editTranslateFunction = new EditTranslateData();

fixture`Finance - Cost Centers: Translate data`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach();
        await login.login(config.UserName, config.Password);
        await t.click(indexCostCenterSelector.financeMenu)
        await t.click(indexCostCenterSelector.accountingMenu);
        await t.click(indexCostCenterSelector.costCentersMenu);
    })

test.meta({ type: 'advance' })
    ('Check translated data when input normal data at DE language', async t => {
        const manageTC1 = new ManageCostCenters()
        //Create Create Cost Centers
        await manageTC1.createCostCenters()
        await t.click(detailsCostCenterSelector.saveCloseBtn);
        //Open detail view
        await manageTC1.filterCostCenters(manageTC1.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000);
        //Open translate data detail view
        await t.click(detailsCostCenterSelector.translateBtn)
        //Assertion
        await t
            .expect(detailsTranslateSelector.nameDEbox.value).contains(manageTC1.nameValue)
            .expect(detailsTranslateSelector.nameENbox.value).contains(manageTC1.nameValue)
            .expect(detailsTranslateSelector.nameFRbox.value).contains(manageTC1.nameValue)
            .click(detailsTranslateSelector.cancelBtn)
            .click(detailsCostCenterSelector.backBtn);
        //Delete data
        await manageTC1.filterCostCenters(manageTC1.costCentersValue);
        await manageTC1.deleteCostCenter();
    })

test.meta({ type: 'advance' })
    ('Check translated data when input normal data at EN language', async t => {
        const manageTC2 = new ManageCostCenters()
        //Switch language to EN
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageENDrop);
        await t.wait(3000);
        //Create Create Cost Centers
        await manageTC2.createCostCenters()
        await t.click(detailsCostCenterSelector.saveCloseBtn);
        //Open detail view Cost Centers
        await manageTC2.filterCostCenters(manageTC2.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000);
        //Open translate data detail view
        await t.click(detailsCostCenterSelector.translateBtn)
        //Assertion
        await t
            .expect(detailsTranslateSelector.nameDEbox.value).contains(manageTC2.nameValue)
            .expect(detailsTranslateSelector.nameENbox.value).contains(manageTC2.nameValue)
            .expect(detailsTranslateSelector.nameFRbox.value).contains(manageTC2.nameValue)
            .click(detailsTranslateSelector.cancelBtn)
            .click(detailsCostCenterSelector.backBtn);
        //Delete data
        await manageTC2.filterCostCenters(manageTC2.costCentersValue);
        await manageTC2.deleteCostCenter();
    })

test.meta({ type: 'advance' })
    ('Check translated data when input normal data at FR language', async t => {
        const manageTC3 = new ManageCostCenters()
        //Switch language to FR
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageFRDrop);
        await t.wait(3000);
        //Create Create Cost Centers
        await manageTC3.createCostCenters()
        await t.click(detailsCostCenterSelector.saveCloseBtn);
        //Open detail view Cost Centers
        await manageTC3.filterCostCenters(manageTC3.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000);
        //Open translate data detail view
        await t.click(detailsCostCenterSelector.translateBtn)
        //Assertion
        await t
            .expect(detailsTranslateSelector.nameDEbox.value).contains(manageTC3.nameValue)
            .expect(detailsTranslateSelector.nameENbox.value).contains(manageTC3.nameValue)
            .expect(detailsTranslateSelector.nameFRbox.value).contains(manageTC3.nameValue)
            .click(detailsTranslateSelector.cancelBtn)
            .click(detailsCostCenterSelector.backBtn);
        //Delete data
        await manageTC3.filterCostCenters(manageTC3.costCentersValue);
        await manageTC3.deleteCostCenter();
    })

test.meta({ type: 'base' })
    ('#31589, #31591, #31592: Check translated data when entering form data translation first in default language', async t => {
        const manageTC4 = new ManageCostCenters()
        //Open Cost Centers form
        await t
            .click(indexCostCenterSelector.addBtn)
            .typeText(detailsCostCenterSelector.costCenterBox, manageTC4.costCentersValue)
        //Create translate data
        await createTranslateFunction.createTranslate();
        //Expected
        await t
            .expect(detailsCostCenterSelector.nameBox.value).contains('Name DE');
        //Save Cost Centers
        await t.click(detailsCostCenterSelector.saveCloseBtn);
        //Check master view
        await manageTC4.filterCostCenters(manageTC4.costCentersValue)
        //Aserrtion
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC4.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name DE');

        //Check data after swicth default to EN language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageENDrop);
        await t.wait(3000);
        await manageTC4.filterCostCenters(manageTC4.costCentersValue)
        //Aserrtion after swicth default to EN language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC4.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name EN');

        //Check data after swicth default to FR language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageFRDrop);
        await t.wait(3000);
        await manageTC4.filterCostCenters(manageTC4.costCentersValue)
        //Aserrtion after swicth default to FR language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC4.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name FR');
        //Delete data
        await manageTC4.deleteCostCenter();
    })

test.meta({ type: 'advance' })
    ('#31589, #31591, #31592: Check translated data when entering form data translation first in EN language', async t => {
        const manageTC5 = new ManageCostCenters()
        //Switch language to EN
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageENDrop);
        await t.wait(3000);
        //Open Cost Centers form
        await t
            .click(indexCostCenterSelector.addBtn)
            .typeText(detailsCostCenterSelector.costCenterBox, manageTC5.costCentersValue)
        //Create translate data
        await createTranslateFunction.createTranslate();
        //Expected
        await t
            .expect(detailsCostCenterSelector.nameBox.value).contains('Name EN');
        //Save Cost Centers
        await t.click(detailsCostCenterSelector.saveCloseBtn);
        //Check master view Cost Centers
        await manageTC5.filterCostCenters(manageTC5.costCentersValue)
        //Aserrtion
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC5.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name EN');

        //Check data after swicth default to DE language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageDEDrop);
        await t.wait(3000);
        await manageTC5.filterCostCenters(manageTC5.costCentersValue)
        //Aserrtion after swicth default to DE language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC5.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name DE');

        //Check data after swicth default to FR language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageFRDrop);
        await t.wait(3000);
        await manageTC5.filterCostCenters(manageTC5.costCentersValue)
        //Aserrtion after swicth default to FR language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC5.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name FR');
        //Delete data
        await manageTC5.deleteCostCenter();
    })

test.meta({ type: 'advance' })
    ('#31589, #31591, #31592: Check translated data when entering form data translation first in FR language', async t => {
        const manageTC6 = new ManageCostCenters()
        //Switch language to FR
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageFRDrop);
        await t.wait(3000);
        //Open Cost Centers form
        await t
            .click(indexCostCenterSelector.addBtn)
            .typeText(detailsCostCenterSelector.costCenterBox, manageTC6.costCentersValue)
        //Create translate data
        await createTranslateFunction.createTranslate();
        //Expected
        await t
            .expect(detailsCostCenterSelector.nameBox.value).contains('Name FR');
        //Save Cost Centers
        await t.click(detailsCostCenterSelector.saveCloseBtn);
        //Check master view Cost Centers
        await manageTC6.filterCostCenters(manageTC6.costCentersValue)
        //Aserrtion
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC6.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name FR');

        //Check data after swicth default to DE language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageDEDrop);
        await t.wait(3000);
        await manageTC6.filterCostCenters(manageTC6.costCentersValue)
        //Aserrtion after swicth default to DE language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC6.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name DE');

        //Check data after swicth default to EN language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageENDrop);
        await t.wait(3000);
        await manageTC6.filterCostCenters(manageTC6.costCentersValue)
        //Aserrtion after swicth default to EN language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC6.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name EN');
        //Delete data
        await manageTC6.deleteCostCenter();
    })

test.meta({ type: 'advance' })
    ('Check translated data when edit Cost Centers at default language', async t => {
        const manageTC7 = new ManageCostCenters()
        //Create Create Cost Centers
        await manageTC7.createCostCenters()
        await t.click(detailsCostCenterSelector.saveCloseBtn);
        //Open detail view Cost Centers
        await manageTC7.filterCostCenters(manageTC7.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000)
            .click(detailsCostCenterSelector.nameBox)
            .pressKey('Ctrl+a delete')
            .typeText(detailsCostCenterSelector.nameBox, 'Name Update DE')
            .click(detailsCostCenterSelector.saveCloseBtn);
        //Search
        await manageTC7.filterCostCenters(manageTC7.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000);
        //Open translate data detail view
        await t.click(detailsCostCenterSelector.translateBtn)
        //Assertion
        await t
            .expect(detailsTranslateSelector.nameDEbox.value).contains('Name Update DE')
            .expect(detailsTranslateSelector.nameENbox.value).contains(manageTC7.nameValue)
            .expect(detailsTranslateSelector.nameFRbox.value).contains(manageTC7.nameValue)
            .click(detailsTranslateSelector.cancelBtn)
            .click(detailsCostCenterSelector.backBtn);
        //Delete data
        await manageTC7.filterCostCenters(manageTC7.costCentersValue);
        await manageTC7.deleteCostCenter();
    })

test.meta({ type: 'advance' })
    ('Check translated data when edit Cost Centers at EN language', async t => {
        const manageTC8 = new ManageCostCenters()
        //Create Create Cost Centers
        await manageTC8.createCostCenters()
        await t.click(detailsCostCenterSelector.saveCloseBtn);
        //Swicth language EN language
        await t
            .click(indexTranslateSelector.languageToggle)
            .click(indexTranslateSelector.languageENDrop)
            .wait(4000);
        //Open detail view Cost Centers
        await manageTC8.filterCostCenters(manageTC8.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000)
            .click(detailsCostCenterSelector.nameBox)
            .pressKey('Ctrl+a delete')
            .typeText(detailsCostCenterSelector.nameBox, 'Name Update EN')
            .click(detailsCostCenterSelector.saveCloseBtn);
        //Search
        await manageTC8.filterCostCenters(manageTC8.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000);
        //Open translate data detail view
        await t.click(detailsCostCenterSelector.translateBtn)
        //Assertion
        await t
            .expect(detailsTranslateSelector.nameDEbox.value).contains(manageTC8.nameValue)
            .expect(detailsTranslateSelector.nameENbox.value).contains('Name Update EN')
            .expect(detailsTranslateSelector.nameFRbox.value).contains(manageTC8.nameValue)
            .click(detailsTranslateSelector.cancelBtn)
            .click(detailsCostCenterSelector.backBtn);
        //Delete data
        await manageTC8.filterCostCenters(manageTC8.costCentersValue);
        await manageTC8.deleteCostCenter();
    })

test.meta({ type: 'advance' })
    ('Check translated data when edit Cost Centers at FR language', async t => {
        const manageTC9 = new ManageCostCenters()
        //Create Create Cost Centers
        await manageTC9.createCostCenters()
        await t.click(detailsCostCenterSelector.saveCloseBtn);
        //Swicth language FR language
        await t
            .click(indexTranslateSelector.languageToggle)
            .click(indexTranslateSelector.languageFRDrop)
            .wait(4000);
        //Open detail view Cost Centers
        await manageTC9.filterCostCenters(manageTC9.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000)
            .click(detailsCostCenterSelector.nameBox)
            .pressKey('Ctrl+a delete')
            .typeText(detailsCostCenterSelector.nameBox, 'Name Update FR')
            .click(detailsCostCenterSelector.saveCloseBtn);
        //Search
        await manageTC9.filterCostCenters(manageTC9.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000);
        //Open translate data detail view
        await t.click(detailsCostCenterSelector.translateBtn)
        //Assertion
        await t
            .expect(detailsTranslateSelector.nameDEbox.value).contains(manageTC9.nameValue)
            .expect(detailsTranslateSelector.nameENbox.value).contains(manageTC9.nameValue)
            .expect(detailsTranslateSelector.nameFRbox.value).contains('Name Update FR')
            .click(detailsTranslateSelector.cancelBtn)
            .click(detailsCostCenterSelector.backBtn);
        //Delete data
        await manageTC9.filterCostCenters(manageTC9.costCentersValue);
        await manageTC9.deleteCostCenter();
    })

test.meta({ type: 'base' })
    ('#31619, #31620, #31621: Check translated data when edit form data translation at default language', async t => {
        const manageTC10 = new ManageCostCenters()
        //Open Cost Centers form
        await t
            .click(indexCostCenterSelector.addBtn)
            .typeText(detailsCostCenterSelector.costCenterBox, manageTC10.costCentersValue)
        //Create translate data
        await createTranslateFunction.createTranslate();
        //Save Cost Centers
        await t.click(detailsCostCenterSelector.saveCloseBtn);
        //Open detail view Cost Centers
        await manageTC10.filterCostCenters(manageTC10.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000);
        //Edit translate data
        await editTranslateFunction.edit();
        //Aserrtion in Detail view
        await t
            .expect(detailsCostCenterSelector.nameBox.value).contains('Name update DE')
            .click(detailsCostCenterSelector.saveCloseBtn);
        //Assert in view table
        await manageTC10.filterCostCenters(manageTC10.costCentersValue)
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC10.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name update DE');

        //Check data after swicth default to EN language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageENDrop);
        await t.wait(3000);
        await manageTC10.filterCostCenters(manageTC10.costCentersValue)
        //Aserrtion after swicth default to EN language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC10.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name update EN');

        //Check data after swicth default to FR language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageFRDrop);
        await t.wait(3000);
        await manageTC10.filterCostCenters(manageTC10.costCentersValue)
        //Aserrtion after swicth default to FR language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC10.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name update FR');
        //Delete data
        await manageTC10.deleteCostCenter();
    })

test.meta({ type: 'advance' })
    ('#31619, #31620, #31621: Check translated data when edit form data translation at EN language', async t => {
        const manageTC11 = new ManageCostCenters()
        //Open Cost Centers form
        await t
            .click(indexCostCenterSelector.addBtn)
            .typeText(detailsCostCenterSelector.costCenterBox, manageTC11.costCentersValue)
        //Create translate data
        await createTranslateFunction.createTranslate();
        //Save Cost Centers
        await t.click(detailsCostCenterSelector.saveCloseBtn);

        //swicth default to EN language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageENDrop);
        await t.wait(3000);

        //Open detail view Cost Centers
        await manageTC11.filterCostCenters(manageTC11.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000);
        //Edit translate data
        await editTranslateFunction.edit();
        //Aserrtion in Detail view
        await t
            .expect(detailsCostCenterSelector.nameBox.value).contains('Name update EN')
            .click(detailsCostCenterSelector.saveCloseBtn);
        //Assert in view table
        await manageTC11.filterCostCenters(manageTC11.costCentersValue)
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC11.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name update EN');

        //Check data after swicth default to DE language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageDEDrop);
        await t.wait(3000);
        await manageTC11.filterCostCenters(manageTC11.costCentersValue)
        //Aserrtion after swicth default to DE language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC11.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name update DE');

        //Check data after swicth default to FR language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageFRDrop);
        await t.wait(3000);
        await manageTC11.filterCostCenters(manageTC11.costCentersValue)
        //Aserrtion after swicth default to FR language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC11.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name update FR');
        //Delete data
        await manageTC11.deleteCostCenter();
    })

test.meta({ type: 'advance' })
    ('#31619, #31620, #31621: Check translated data when edit form data translation at FR language', async t => {
        const manageTC12 = new ManageCostCenters()
        //Open Cost Centers form
        await t
            .click(indexCostCenterSelector.addBtn)
            .typeText(detailsCostCenterSelector.costCenterBox, manageTC12.costCentersValue)
        //Create translate data
        await createTranslateFunction.createTranslate();
        //Save Cost Centers
        await t.click(detailsCostCenterSelector.saveCloseBtn);

        //swicth default to EN language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageFRDrop);
        await t.wait(3000);

        //Open detail view Cost Centers
        await manageTC12.filterCostCenters(manageTC12.costCentersValue)
        await t
            .click(indexCostCenterSelector.editBtn)
            .wait(2000);
        //Edit translate data
        await editTranslateFunction.edit();
        //Aserrtion in Detail view
        await t
            .expect(detailsCostCenterSelector.nameBox.value).contains('Name update FR')
            .click(detailsCostCenterSelector.saveCloseBtn);
        //Assert in view table
        await manageTC12.filterCostCenters(manageTC12.costCentersValue)
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC12.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name update FR');

        //Check data after swicth default to DE language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageDEDrop);
        await t.wait(3000);
        await manageTC12.filterCostCenters(manageTC12.costCentersValue)
        //Aserrtion after swicth default to DE language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC12.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name update DE');

        //Check data after swicth default to EN language
        await t.click(indexTranslateSelector.languageToggle);
        await t.click(indexTranslateSelector.languageENDrop);
        await t.wait(3000);
        await manageTC12.filterCostCenters(manageTC12.costCentersValue)
        //Aserrtion after swicth default to EN language
        await t
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains(manageTC12.costCentersValue)
            .expect(indexCostCenterSelector.costCentersTable.innerText).contains('Name update EN');
        //Delete data
        await manageTC12.deleteCostCenter();
    })