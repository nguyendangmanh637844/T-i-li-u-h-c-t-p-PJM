import { Selector, t } from "testcafe"
import CostCentersDetailSelector from "../../manage-cost-centers/selectors/cost-centers.detail.selector";
import PageDetails from "../selectors/page.details.selector";

const pageDetailCostCenters = new CostCentersDetailSelector();
const pageDetailTranslated = new PageDetails();

class EditTranslateData {
    async edit() {
        await t
            .click(pageDetailCostCenters.translateBtn)
            .click(pageDetailTranslated.nameDEbox)
            .pressKey('ctrl+a delete')
            .typeText(pageDetailTranslated.nameDEbox, 'Name update DE')
            .click(pageDetailTranslated.nameENbox)
            .pressKey('ctrl+a delete')
            .typeText(pageDetailTranslated.nameENbox, 'Name update EN')
            .click(pageDetailTranslated.nameFRbox)
            .pressKey('ctrl+a delete')
            .typeText(pageDetailTranslated.nameFRbox, 'Name update FR')
            .click(pageDetailTranslated.saveBtn);
    }
}
export default EditTranslateData