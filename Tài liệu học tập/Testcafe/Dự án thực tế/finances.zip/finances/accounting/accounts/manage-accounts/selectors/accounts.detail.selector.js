import { Selector } from "testcafe";

export default class AccountsDetailSelector {
    constructor() {
        //Textbox fields
        this.companyDropdown = Selector('#cbx-template');
        this.companyOption = this.companyDropdown.find('option');
        this.accountBox = Selector('#tb-acc-account');

        this.sortBox = Selector('#tb-sortorder')
        this.activeCheckBox = Selector('#cb-enabled');
        this.requestdeleteCheckBox = Selector('#cb-has-deleted')

        //Buttons
        this.saveCloseBtn = Selector('button[class="btn btn-sm btn-success"]')
        this.saveDropDownBtn = Selector('button[class="btn btn-sm btn-success dropdown-toggle dropdown-toggle-split"]')
        this.saveNewBtn = Selector('a').withText("Speichern und neu")
        this.deleteBtn = Selector('#btn-clear');
        this.resetBtn = Selector('#btn-reset');
        this.copyBtn = Selector('#btn-duplicate');
        this.backBtn = Selector('.fa-long-arrow-alt-left');

        //Asser
        this.vldMessage = Selector('div[class="validation-message"]')
        this.errorMessage = Selector('div').withAttribute('class', 'modal-body dxbs-modal-body');
        this.closeErrorMessage = Selector('#btn-close-alert')
        this.overrideBtn = Selector('#btn-confirm-overide')
        this.refreshBtn = Selector('#btn-confirm-yes')
        this.cancelBtn = Selector('#btn-confirm-no')

    }
};