import { Selector, t } from "testcafe"
import AccountsIndexSelector from "../selectors/accounts.index.selector";
import AccountsDetailSelector from "../selectors/accounts.detail.selector";
import Utils from "../../../../../../commons/utils";

const detailsSelector = new AccountsDetailSelector();
const indexSelector = new AccountsIndexSelector();
const randomData = new Utils();


export default class ManageAccounts {
    constructor() {
        //create
        this.accountValue = randomData.getText('Autotest_', 15);
        //edit
        this.accountEditValue = randomData.getText('Autotest_', 15);
        this.accountCopyValue = randomData.getText('Autotest_', 15);

    }

    async filterAccounts(account) {
        await t
            .click(indexSelector.filterAccount)
            .pressKey('ctrl+a delete')
            .typeText(indexSelector.filterAccount, account)
            .pressKey('enter')
    }

    async createAccountConfig(account) {
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.accountBox, account)
    }

    async createAccount() {
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.accountBox, this.accountValue)
    }

    async editAccountConfig(account) {
        await t
            .click(indexSelector.editBtn)
            .wait(2000)
            .click(detailsSelector.accountBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.accountBox, account)
    }

    async editAccount() {
        //edit data
        await t
            .click(indexSelector.editBtn)
            .wait(2000)
            .click(detailsSelector.accountBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.accountBox, this.accountEditValue)
    }

    async copyAccountConfig() {
        await t
            .click(indexSelector.editBtn)
            .wait(2000)
            .click(detailsSelector.copyBtn)
            .wait(3000)
            .expect(detailsSelector.accountBox.value).contains(' - Kopieren')
    }

    async copyAccount() {
        //edit data
        await t
            .click(indexSelector.editBtn)
            .wait(2000)
            .click(detailsSelector.copyBtn)
            .wait(3000)
            .expect(detailsSelector.accountBox.value).contains(' - Kopieren')
            .click(detailsSelector.accountBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.accountBox, this.accountCopyValue)
    }
    async copyAccountMasterView() {
        //edit data
        await t
            .click(indexSelector.copyBtn)
            .wait(3000)
            .expect(detailsSelector.accountBox.value).contains(' - Kopieren')
            .click(detailsSelector.accountBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.accountBox, this.accountCopyValue)
    }

    async deleteAccount() {
        await t
            .click(indexSelector.deleteBtn)
            .click(indexSelector.confirmDeleteBtn)
    }

}
