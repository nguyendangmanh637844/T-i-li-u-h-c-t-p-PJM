﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration";
import LoginPage from "../../../../../authentication/functions/login-page";
import AccountsIndexSelector from "../selectors/accounts.index.selector";
import AccountsDetailSelector from "../selectors/accounts.detail.selector";
import ManageAccounts from "../functions/manage-accounts"

const config = new Configuration();
const login = new LoginPage();
const detailsSelector = new AccountsDetailSelector();
const indexSelector = new AccountsIndexSelector();
const account = new ManageAccounts()

fixture`Finance - Accounts: Copy Account`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach();
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.accountsMenu);
    })

test.meta({ type: 'base' })
    ('#36334: Check copy Account when use  Save and Close button', async t => {
        const manageTC1 = new ManageAccounts()

        //Create  Account
        await manageTC1.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy  Account
        await manageTC1.filterAccounts(manageTC1.accountValue)
        await manageTC1.copyAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await manageTC1.filterAccounts(manageTC1.accountCopyValue)
        await t
            .expect(indexSelector.accountsTable.innerText).contains(manageTC1.accountCopyValue);
        //Delete data
        await manageTC1.deleteAccount()
        await manageTC1.filterAccounts(manageTC1.accountValue)
        await manageTC1.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    ('#36334: Check Copy Account when use  Save and New button', async t => {
        const manageTC2 = new ManageAccounts()

        //Create  Account
        await manageTC2.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy  Account
        await manageTC2.filterAccounts(manageTC2.accountValue)
        await manageTC2.copyAccount()
        await t.click(detailsSelector.saveDropDownBtn)
        await t.click(detailsSelector.saveNewBtn)
        await t.click(detailsSelector.backBtn)
        //Assert 
        await manageTC2.filterAccounts(manageTC2.accountCopyValue)
        await t
            .expect(indexSelector.accountsTable.innerText).contains(manageTC2.accountCopyValue);
        //Delete data
        await manageTC2.deleteAccount()
        await manageTC2.filterAccounts(manageTC2.accountValue)
        await manageTC2.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36334: Check copy Account when use  Copy button in master view', async t => {
        const manageTC3 = new ManageAccounts()

        //Create  Account
        await manageTC3.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy  Account
        await manageTC3.filterAccounts(manageTC3.accountValue)
        await manageTC3.copyAccountMasterView()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await manageTC3.filterAccounts(manageTC3.accountCopyValue)
        await t
            .expect(indexSelector.accountsTable.innerText).contains(manageTC3.accountCopyValue);
        //Delete data
        await manageTC3.deleteAccount()
        await manageTC3.filterAccounts(manageTC3.accountValue)
        await manageTC3.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36334: Check copy Account when Account and company fields is duplicate', async t => {
        const createTC4 = new ManageAccounts()

        //Create Account
        await createTC4.createAccount()
        await t.click(detailsSelector.saveCloseBtn)

        //Copy Account
        await createTC4.copyAccountConfig()
        await t
            .click(detailsSelector.accountBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.accountBox, createTC4.accountValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Dieses Konto hat bereits existiert')
            .click(detailsSelector.closeErrorMessage)
        //Back to Account list
        await t.click(detailsSelector.backBtn)
        //Delete Account
        await createTC4.filterAccounts(createTC4.accountValue)
        await createTC4.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36336: Check copy Account when Account is blank', async t => {
        const createTC5 = new ManageAccounts()
        //Create Account
        await createTC5.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Copy Account
        await createTC5.copyAccountConfig()
        await t
            .click(detailsSelector.accountBox)
            .pressKey('ctrl+a delete')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to Account list
        await t.click(detailsSelector.backBtn)
        //Delete Account
        await createTC5.filterAccounts(createTC5.accountValue)
        await createTC5.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36338: Check copy Account when Account field is more than 15 characters', async t => {
        const createTC6 = new ManageAccounts()
        //Create Account
        await createTC6.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Copy Account
        await createTC6.copyAccountConfig()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 15 Zeichen')
        //Back to Account list
        await t.click(detailsSelector.backBtn)
        //Delete Account
        await createTC6.filterAccounts(createTC6.accountValue)
        await createTC6.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })
