﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration";
import LoginPage from "../../../../../authentication/functions/login-page";
import AccountsIndexSelector from "../selectors/accounts.index.selector";
import AccountsDetailSelector from "../selectors/accounts.detail.selector";
import ManageAccounts from "../functions/manage-accounts";

const config = new Configuration();
const login = new LoginPage();
const detailsSelector = new AccountsDetailSelector();
const indexSelector = new AccountsIndexSelector();
const account = new ManageAccounts();

fixture`Finance - Accounts: Concurrency Account`
  .page(config.UrlAdmin)
  .beforeEach(async (t) => {
    await config.configBeforeEach();
    await login.login(config.UserName, config.Password);
    await t.click(indexSelector.financeMenu);
    await t.click(indexSelector.accountingMenu);
    await t.click(indexSelector.accountsMenu);
  });

test.meta({ type: "base" })(
  "#36153/#36166: Check concurrency when both users edit the same Account with Override option",
  async (t) => {
    const concurrencyTC1a = new ManageAccounts();
    const concurrencyTC1b = new ManageAccounts();
    const initialWindow = await t.getCurrentWindow();
    const window1 = await t.openWindow(config.UrlAdmin);

    //Create Account at initial Window
    await t.switchToWindow(initialWindow);
    await concurrencyTC1a.createAccount();
    await t.click(detailsSelector.saveCloseBtn);
    //Open detail view at initial Window
    await concurrencyTC1a.filterAccounts(concurrencyTC1a.accountValue);
    await concurrencyTC1a.editAccount();

    //Open second browser
    await t.switchToWindow(window1);
    await t.maximizeWindow();
    await t.wait(7000);
    await login.login(config.UserName, config.Password);
    await t.click(indexSelector.financeMenu);
    await t.click(indexSelector.accountingMenu);
    await t.click(indexSelector.accountsMenu);
    //Open detail view at second Window and edit that record
    await concurrencyTC1b.filterAccounts(concurrencyTC1a.accountValue);
    await concurrencyTC1b.editAccount();
    await t.click(detailsSelector.saveCloseBtn);

    //Open the first window
    await t.switchToWindow(initialWindow);
    await t.click(detailsSelector.saveCloseBtn).wait(2000);
    //Assert
    await t
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert."
      )
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt."
      )
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben."
      )
      .expect(detailsSelector.errorMessage.innerText)
      .contains("Widersprüchliche Informationen");
    //Assert informantion
    await t
      .expect(detailsSelector.errorMessage.innerText)
      .contains(concurrencyTC1b.accountEditValue);
    //Override information
    await t.click(detailsSelector.overrideBtn);
    //Assert
    await concurrencyTC1a.filterAccounts(concurrencyTC1a.accountEditValue);
    await t
      .expect(indexSelector.accountsTable.innerText)
      .contains(concurrencyTC1a.accountEditValue);
    //Delete data
    await concurrencyTC1a.deleteAccount();
    await t
      .expect(indexSelector.accountsTable.innerText)
      .contains("Keine Daten zum Anzeigen");
  }
);

test.meta({ type: "base" })(
  "#36153/#36167: Check concurrency when both users edit the same Account with Refresh option",
  async (t) => {
    const concurrencyTC2a = new ManageAccounts();
    const concurrencyTC2b = new ManageAccounts();
    const initialWindow = await t.getCurrentWindow();
    const window1 = await t.openWindow(config.UrlAdmin);

    //Create Account at initial Window
    await t.switchToWindow(initialWindow);
    await concurrencyTC2a.createAccount();
    await t.click(detailsSelector.saveCloseBtn);
    //Open detail view at initial Window
    await concurrencyTC2a.filterAccounts(concurrencyTC2a.accountValue);
    await concurrencyTC2a.editAccount();

    //Open second browser
    await t.switchToWindow(window1);
    await t.maximizeWindow();
    await t.wait(4000);
    await login.login(config.UserName, config.Password);
    await t.click(indexSelector.financeMenu);
    await t.click(indexSelector.accountingMenu);
    await t.click(indexSelector.accountsMenu);
    //Open detail view at second Window and edit that Account
    await concurrencyTC2a.filterAccounts(concurrencyTC2a.accountValue);
    await concurrencyTC2b.editAccount();
    await t.click(detailsSelector.saveCloseBtn);

    //Open the first window
    await t.switchToWindow(initialWindow);
    await t.click(detailsSelector.saveCloseBtn).wait(2000);
    //Assert
    await t
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert."
      )
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt."
      )
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben."
      )
      .expect(detailsSelector.errorMessage.innerText)
      .contains("Widersprüchliche Informationen");
    //Assert informantion
    await t
      .expect(detailsSelector.errorMessage.innerText)
      .contains(concurrencyTC2b.accountEditValue);
    //Refresh information
    await t.click(detailsSelector.refreshBtn);
    await t.wait(30000);
    //Assert
    await t
      .expect(detailsSelector.accountBox.value)
      .contains(concurrencyTC2b.accountEditValue)
    // await t.click(detailsSelector.backBtn);
    //Assert
    await concurrencyTC2b.filterAccounts(concurrencyTC2b.accountEditValue);
    await t
      .expect(indexSelector.accountsTable.innerText)
      .contains(concurrencyTC2b.accountEditValue);
    //Delete data
    await concurrencyTC2b.deleteAccount();
    await t
      .expect(indexSelector.accountsTable.innerText)
      .contains("Keine Daten zum Anzeigen");
  }
);

test.meta({ type: "base" })(
  "#36153/#36168: Check concurrency when both users edit the same Account with Cancel option",
  async (t) => {
    const concurrencyTC3a = new ManageAccounts();
    const concurrencyTC3b = new ManageAccounts();
    const initialWindow = await t.getCurrentWindow();
    const window1 = await t.openWindow(config.UrlAdmin);

    //Create Account at initial Window
    await t.switchToWindow(initialWindow);
    await concurrencyTC3a.createAccount();
    await t.click(detailsSelector.saveCloseBtn);
    //Open detail view at initial Window
    await concurrencyTC3a.filterAccounts(concurrencyTC3a.accountValue);
    await concurrencyTC3a.editAccount();

    //Open second browser
    await t.switchToWindow(window1);
    await t.maximizeWindow();
    await t.wait(4000);
    await login.login(config.UserName, config.Password);
    await t.click(indexSelector.financeMenu);
    await t.click(indexSelector.accountingMenu);
    await t.click(indexSelector.accountsMenu);
    //Open detail view at second Window and edit that Account
    await concurrencyTC3a.filterAccounts(concurrencyTC3a.accountValue);
    await concurrencyTC3b.editAccount();
    await t.click(detailsSelector.saveCloseBtn);

    //Open the first window
    await t.switchToWindow(initialWindow);
    await t.click(detailsSelector.saveCloseBtn).wait(2000);
    //Assert
    await t
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert."
      )
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt."
      )
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben."
      )
      .expect(detailsSelector.errorMessage.innerText)
      .contains("Widersprüchliche Informationen");
    //Assert informantion
    await t
      .expect(detailsSelector.errorMessage.innerText)
      .contains(concurrencyTC3b.accountEditValue);
    //Override information
    await t.click(detailsSelector.cancelBtn);
    //Assert
    await t
      .expect(detailsSelector.accountBox.value)
      .contains(concurrencyTC3a.accountEditValue);
    await t.click(detailsSelector.backBtn);
    //Assert
    await concurrencyTC3b.filterAccounts(concurrencyTC3b.accountEditValue);
    await t
      .expect(indexSelector.accountsTable.innerText)
      .contains(concurrencyTC3b.accountEditValue);
    //Delete data
    await concurrencyTC3b.deleteAccount();
    await t
      .expect(indexSelector.accountsTable.innerText)
      .contains("Keine Daten zum Anzeigen");
  }
);

test.meta({ type: "base" })(
  "#36161: Check concurrency when both users delete the same Account",
  async (t) => {
    const concurrencyTC4 = new ManageAccounts();
    const initialWindow = await t.getCurrentWindow();
    const window1 = await t.openWindow(config.UrlAdmin);

    //Create Cost center at initial Window
    await t.switchToWindow(initialWindow);
    await concurrencyTC4.createAccount();
    await t.click(detailsSelector.saveCloseBtn);
    //Open detail view at initial Window
    await concurrencyTC4.filterAccounts(concurrencyTC4.accountValue);
    await t.click(indexSelector.deleteBtn);

    //Open second browser
    await t.switchToWindow(window1);
    await t.maximizeWindow();
    await t.wait(4000);
    await login.login(config.UserName, config.Password);
    await t.click(indexSelector.financeMenu);
    await t.click(indexSelector.accountingMenu);
    await t.click(indexSelector.accountsMenu);
    //Open detail view at second Window and edit that Account
    await concurrencyTC4.filterAccounts(concurrencyTC4.accountValue);
    await concurrencyTC4.deleteAccount();

    //Open the first window
    await t.switchToWindow(initialWindow);
    await t
      .click(indexSelector.confirmDeleteBtn)
      .wait(2000)
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Kann nicht gelöscht werden. Der Datensatz wurde von einem anderen Benutzer gelöscht."
      )
      .click(detailsSelector.closeErrorMessage);

    //Assert
    await concurrencyTC4.filterAccounts(concurrencyTC4.accountValue);
    await t
      .expect(indexSelector.accountsTable.innerText)
      .contains("Keine Daten zum Anzeigen");
  }
);

test.meta({ type: "base" })(
  "#36155: Check concurrency when user 1 delete and user 2 edit the same Account",
  async (t) => {
    const concurrencyTC5 = new ManageAccounts();
    const initialWindow = await t.getCurrentWindow();
    const window1 = await t.openWindow(config.UrlAdmin);

    //Create Account at initial Window
    await t.switchToWindow(initialWindow);
    await concurrencyTC5.createAccount();
    await t.click(detailsSelector.saveCloseBtn);
    //Open detail view at initial Window
    await concurrencyTC5.filterAccounts(concurrencyTC5.accountValue);
    await t.click(indexSelector.deleteBtn);

    //Open second browser
    await t.switchToWindow(window1);
    await t.maximizeWindow();
    await t.wait(4000);
    await login.login(config.UserName, config.Password);
    await t.click(indexSelector.financeMenu);
    await t.click(indexSelector.accountingMenu);
    await t.click(indexSelector.accountsMenu);
    //Open detail view at second Window and edit that record
    await concurrencyTC5.filterAccounts(concurrencyTC5.accountValue);
    await concurrencyTC5.editAccount();

    //Open the first window
    await t.switchToWindow(initialWindow);
    await t.click(indexSelector.confirmDeleteBtn).wait(2000);

    //Open second browser
    await t.switchToWindow(window1);
    await t.click(detailsSelector.saveCloseBtn);
    //Assert
    await t
      .expect(detailsSelector.errorMessage.innerText)
      .contains(
        "Speichern nicht möglich. Die Datensatz wurde von einem anderen Benutzer gelöscht."
      );
    await t.click(detailsSelector.closeErrorMessage);
    //Assert
    await concurrencyTC5.filterAccounts(concurrencyTC5.accountValue);
    await t
      .expect(indexSelector.accountsTable.innerText)
      .contains("Keine Daten zum Anzeigen");
  }
);

test.meta({ type: "base" })(
  "#36155: Check concurrency when user 1 delete and user 2 click copy the same Account",
  async (t) => {
    const concurrencyTC6 = new ManageAccounts();
    const initialWindow = await t.getCurrentWindow();
    const window1 = await t.openWindow(config.UrlAdmin);

    //Create Account at initial Window
    await t.switchToWindow(initialWindow);
    await concurrencyTC6.createAccount();
    await t.click(detailsSelector.saveCloseBtn);
    //Open detail view at initial Window
    await concurrencyTC6.filterAccounts(concurrencyTC6.accountValue);

    //Open second browser
    await t.switchToWindow(window1);
    await t.maximizeWindow();
    await t.wait(4000);
    await login.login(config.UserName, config.Password);
    await t.click(indexSelector.financeMenu);
    await t.click(indexSelector.accountingMenu);
    await t.click(indexSelector.accountsMenu);
    //Open detail view at second Window and edit that record
    await concurrencyTC6.filterAccounts(concurrencyTC6.accountValue);
    await concurrencyTC6.deleteAccount();

    //Open the first window
    await t.switchToWindow(initialWindow);
    await t.click(indexSelector.copyBtn).wait(2000);

    //Assert
    await t
      .expect(detailsSelector.errorMessage.innerText)
      .contains("Der Datensatz wurde von einem anderen Benutzer gelöscht.");
    await t.click(detailsSelector.closeErrorMessage);
  }
);

test.meta({ type: "base" })(
  "#36155: Check concurrency when user 1 delete and user 2 click edit the same Account",
  async (t) => {
    const concurrencyTC7 = new ManageAccounts();
    const initialWindow = await t.getCurrentWindow();
    const window1 = await t.openWindow(config.UrlAdmin);

    //Create Account at initial Window
    await t.switchToWindow(initialWindow);
    await concurrencyTC7.createAccount();
    await t.click(detailsSelector.saveCloseBtn);
    //Open detail view at initial Window
    await concurrencyTC7.filterAccounts(concurrencyTC7.accountValue);

    //Open second browser
    await t.switchToWindow(window1);
    await t.maximizeWindow();
    await t.wait(4000);
    await login.login(config.UserName, config.Password);
    await t.click(indexSelector.financeMenu);
    await t.click(indexSelector.accountingMenu);
    await t.click(indexSelector.accountsMenu);
    //Open detail view at second Window and edit that record
    await concurrencyTC7.filterAccounts(concurrencyTC7.accountValue);
    await concurrencyTC7.deleteAccount();

    //Open the first window
    await t.switchToWindow(initialWindow);
    await t.click(indexSelector.editBtn).wait(2000);

    //Assert
    await t
      .expect(detailsSelector.errorMessage.innerText)
      .contains("Der Datensatz wurde von einem anderen Benutzer gelöscht.");
    await t.click(detailsSelector.closeErrorMessage);
  }
);
