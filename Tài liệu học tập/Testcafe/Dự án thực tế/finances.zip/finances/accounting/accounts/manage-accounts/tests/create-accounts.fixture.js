﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration";
import LoginPage from "../../../../../authentication/functions/login-page";
import AccountsIndexSelector from "../selectors/accounts.index.selector";
import AccountsDetailSelector from "../selectors/accounts.detail.selector";
import ManageAccounts from "../functions/manage-accounts"

const config = new Configuration();
const login = new LoginPage();
const detailsSelector = new AccountsDetailSelector();
const indexSelector = new AccountsIndexSelector();
const account = new ManageAccounts()

fixture`Finance - Accounts: Create Account`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach();
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.accountsMenu);
    })

test.meta({ type: 'base' })
    ('#36334: Check create Account when use Save and Close button', async t => {
        const createTC1 = new ManageAccounts()

        //Create Account
        await createTC1.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        await createTC1.filterAccounts(createTC1.accountValue)
        //Assert 
        await t
            .expect(indexSelector.accountsTable.innerText).contains(createTC1.accountValue)
        //Delete data
        await createTC1.deleteAccount()
        await createTC1.filterAccounts(createTC1.accountValue)
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    ('#36335: Check create Account when use Save and New button', async t => {
        const createTC2 = new ManageAccounts()

        //Create Account
        await createTC2.createAccount()
        await t.click(detailsSelector.saveDropDownBtn)
        await t.click(detailsSelector.saveNewBtn)
        await t.click(detailsSelector.backBtn);
        //Assert 
        await createTC2.filterAccounts(createTC2.accountValue)
        await t
            .expect(indexSelector.accountsTable.innerText).contains(createTC2.accountValue)
        //Delete Account
        await createTC2.deleteAccount()
        await createTC2.filterAccounts(createTC2.accountValue)
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })


test.meta({ type: 'advance' })
    ('#36334: Check create Account when Account and company fields is duplicate', async t => {
        const createTC3 = new ManageAccounts()

        //Create Account 1
        await createTC3.createAccount()
        await t.click(detailsSelector.saveCloseBtn)

        //Create Account 2
        await createTC3.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Dieses Konto hat bereits existiert')
            .click(detailsSelector.closeErrorMessage)
        //Back to Account list
        await t.click(detailsSelector.backBtn)
        //Delete Account
        await createTC3.filterAccounts(createTC3.accountValue)
        await createTC3.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36336: Check create Account when Account is blank', async t => {
        //Create Account
        await account.createAccountConfig('  ')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to Account list
        await t.click(detailsSelector.backBtn)
    })

test.meta({ type: 'advance' })
    ('#36338: Check create Account when Account field is more than 15 characters', async t => {
        //Create Account
        await account.createAccountConfig('Name Test new hi')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 15 Zeichen')
        //Back to Account list
        await t.click(detailsSelector.backBtn)
    })
