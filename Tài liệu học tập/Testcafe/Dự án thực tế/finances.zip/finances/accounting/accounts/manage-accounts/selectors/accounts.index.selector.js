import { Selector } from "testcafe";

export default class AccountsIndexSelector {
    constructor() {
        //Menu bar
        this.financeMenu = Selector('a').withText("Finanzen")
        this.accountingMenu = Selector('a').withText("Buchhaltung")
        this.accountsMenu = Selector('a').withText("Konten")

        //List view
        this.addBtn = Selector('#btn-addNew');
        this.filterBox = Selector('div[class="dxbs-textbox"]');
        this.filterAccount = Selector('.dxbs-grid-filter-row .dxbs-grid-table-border-bottom:nth-of-type(2) .dxbs-form-control')
        this.editBtn = Selector('#btn-edit');
        this.copyBtn = Selector('#btn-copy');
        this.deleteBtn = Selector('#btn-delete');
        this.confirmDeleteBtn = Selector('#btn-confirm-yes');
        this.cancelDeleteBtn = Selector('#btn-confirm-no');
        this.accountsTable = Selector('div').withAttribute('class', 'dxbs-scroll-viewer-content');
        this.clearFilterBtn = Selector('button[class ="btn btn-sm dx-btn dxbs-edit-btn dxbs-clear-btn"]')

    }
};