﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration";
import LoginPage from "../../../../../authentication/functions/login-page";
import AccountsIndexSelector from "../selectors/accounts.index.selector";
import AccountsDetailSelector from "../selectors/accounts.detail.selector";
import ManageAccounts from "../functions/manage-accounts"

const config = new Configuration();
const login = new LoginPage();
const detailsSelector = new AccountsDetailSelector();
const indexSelector = new AccountsIndexSelector();
const account = new ManageAccounts()

fixture`Finance - Accounts: Edit Account`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach();
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.accountingMenu);
        await t.click(indexSelector.accountsMenu);
    })

test.meta({ type: 'base' })
    ('#36334: Check Edit Account when use Save and Close button', async t => {
        const createTC1 = new ManageAccounts()
        const editTC1 = new ManageAccounts()

        //Create Account
        await createTC1.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Edit Account
        await account.filterAccounts(createTC1.accountValue)
        await editTC1.editAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await account.filterAccounts(editTC1.accountEditValue)
        await t
            .expect(indexSelector.accountsTable.innerText).contains(editTC1.accountEditValue)
        //Delete data
        await account.deleteAccount()
        await account.filterAccounts(editTC1.accountEditValue)
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    ('#36335: Check Edit Account when use Save and New button', async t => {
        const createTC2 = new ManageAccounts()
        const editTC2 = new ManageAccounts()

        //Create Account
        await createTC2.createAccount()
        await t.click(detailsSelector.saveDropDownBtn)
        await t.click(detailsSelector.saveNewBtn)
        await t.click(detailsSelector.backBtn)
        //Edit Account
        await account.filterAccounts(createTC2.accountValue)
        await editTC2.editAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await account.filterAccounts(editTC2.accountEditValue)
        await t
            .expect(indexSelector.accountsTable.innerText).contains(editTC2.accountEditValue)
        //Delete Account
        await account.deleteAccount()
        await account.filterAccounts(editTC2.accountEditValue)
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    ('#36336: Check Edit Account when Account field is blank', async t => {
        const createTC3 = new ManageAccounts()
        //Create Account
        await createTC3.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Edit Account
        await account.filterAccounts(createTC3.accountValue)
        await account.editAccountConfig(' ')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Delete data
        await t.click(detailsSelector.backBtn)
        await account.filterAccounts(createTC3.accountValue)
        await account.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36337: Check Edit Account when duplicate Account&Company fields', async t => {
        const createTC4a = new ManageAccounts()
        const createTC4b = new ManageAccounts()

        //Create the first Account
        await createTC4a.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Create the second Account
        await createTC4b.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Edit the second Account
        await account.filterAccounts(createTC4b.accountValue)
        await account.editAccountConfig(createTC4a.accountValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Assert
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Dieses Konto hat bereits existiert')
            .click(detailsSelector.closeErrorMessage)
        //Back to Account list
        await t.click(detailsSelector.backBtn)
        //Delete the first Account
        await account.filterAccounts(createTC4a.accountValue)
        await account.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
        //Delete the second Account
        await account.filterAccounts(createTC4b.accountValue)
        await account.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#36338: Check Edit Account when Account field is more than 15 characters', async t => {
        const createTC5 = new ManageAccounts()
        //Create Account
        await createTC5.createAccount()
        await t.click(detailsSelector.saveCloseBtn)
        //Edit Account
        await account.filterAccounts(createTC5.accountValue)
        await account.editAccountConfig('Name Test new hi')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 15 Zeichen')
        //Back to Account list
        await t.click(detailsSelector.backBtn)
        //Delete data
        await account.filterAccounts(createTC5.accountValue)
        await account.deleteAccount()
        await t.expect(indexSelector.accountsTable.innerText).contains('Keine Daten zum Anzeigen')
    })

