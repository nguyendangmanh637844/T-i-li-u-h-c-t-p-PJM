import { Selector, t } from "testcafe";
import Configuration from "../../../../../commons/configuration"
import LoginPage from "../../../../authentication/functions/login-page"
import VATCodeIndexSelector from "../../vat-code/manage-vat-code/selectors/vat-code.index.selector";
import VATOptionsDetailSelector from "../selectors/vat-options.detail.selector";

const config = new Configuration()
const login = new LoginPage()
const detailsSelector = new VATOptionsDetailSelector()
const indexSelector = new VATCodeIndexSelector()

fixture`Finance - VAT Options`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatOptionsMenu)
    })

test.meta({ type: 'base' })
    ('#37812: Check create VAT Options successfully', async t => {
        //Create VAT Options
        await t
            .click(detailsSelector.vatTransitionBox)
            .pressKey("ctrl+a delete")
            .typeText(detailsSelector.vatTransitionBox, "3")
            .click(detailsSelector.saveBtn);
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Mehrwertsteuer-Optionen erfolgreich gespeichert')
            .click(detailsSelector.closeErrorMessage)
    })

test.meta({ type: 'base' })
    ('#37812: Check create VAT Options unsuccessfully when VAT transition period >12', async t => {
        //Create VAT Options
        await t
            .click(detailsSelector.vatTransitionBox)
            .pressKey("ctrl+a delete")
            .typeText(detailsSelector.vatTransitionBox, "13");
        await t
            .expect(detailsSelector.vatTransitionBox.value).contains('12')
    })