import { Selector } from "testcafe";

export default class VATOptionsIndexSelector {
    constructor() {
        //Menu bar
        this.financeMenu = Selector('a').withText("Finanzen")
       // this.vatMenu = Selector('a').withText("")
        this.vatOptionsMenu = Selector('a').withText("MWST-Optionen")

        /*//Label layout
        this.userProfileBtn = Selector('i[title="User Info"]');
        this.userSettingBtn = Selector('a').withAttribute('class', 'dropdown-item btn');
        this.labelDropdown = Selector('select').withAttribute('class', 'form-control-sm w-100');
        this.regularLabel = Selector('option').withAttribute('value', 'Regular');
        this.floatingLabel = Selector('option').withAttribute('value', 'Floating');
        this.automaticLabel = Selector('option').withAttribute('value', 'Automatic');
        this.closeLabelBtn = Selector('#btn-close-alert');*/

    }
};