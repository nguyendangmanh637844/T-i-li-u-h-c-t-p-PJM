import { Selector } from "testcafe";

export default class VATOptionsDetailSelector {
    constructor() {
        //Textbox fields
        //this.vatCurrencyDropdown = Selector('#')
        this.vatTransitionBox = Selector('#tb-vat-period')

        //Buttons
        this.saveBtn = Selector('#btn-saveAndClose');
        this.resetBtn = Selector('#btn-reset');

        //Asser
        this.vldMessage = Selector('div[class="validation-message"]')
        this.errorMessage = Selector('p').withAttribute('class', 'blazored-toast-message');
        this.closeErrorMessage = Selector('#btn-close-alert')
        this.overrideBtn = Selector('#btn-confirm-overide')
        this.refreshBtn = Selector('#btn-confirm-yes')
        this.cancelBtn = Selector('#btn-confirm-no')

    }
}