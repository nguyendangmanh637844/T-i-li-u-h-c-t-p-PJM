﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration"
import LoginPage from "../../../../../authentication/functions/login-page"
import VATCodeIndexSelector from "../../manage-vat-code/selectors/vat-code.index.selector"
import VATCodeDetailSelector from "../../manage-vat-code/selectors/vat-code.detail.selector"
import ManageVATCode from "../../manage-vat-code/functions/manage-vat-code"
import ManageVATRate from "../../vat-rate/functions/manage-vat-rate"

import TranslateVATCodeDetails from "../selectors/translate-vat-code.detail.selector";
import TranslateIndex from "../../../../../../commons/translate-selector"
import TranslateData from "../functions/translate-vat-code"

const config = new Configuration();
const login = new LoginPage();
const detailsSelector = new VATCodeDetailSelector();
const indexSelector = new VATCodeIndexSelector();

const translateDetail = new TranslateVATCodeDetails();
const translateIndex = new TranslateIndex();
const vatCode = new ManageVATCode()
const vatRate = new ManageVATRate()
const translate = new TranslateData();


fixture`Finance - VAT Code: Translate VAT Code`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach();
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatCodeMenu)
    })

test.meta({ type: 'base' })
     ('#37418: Check translated data when input normal data at DE language', async t => {
                const create1 = new ManageVATCode()

                //Create VAT Code
                await vatCode.createVATCode(create1.codeValue, create1.textValue)
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn)
                //Open detail view VAT Code
                await vatCode.filterVATCode(create1.codeValue)
                await t.click(indexSelector.editBtn)
                //Open translate data detail view
                await t.click(detailsSelector.translateBtn)
                await t.wait(2000)
                //Assertion
                await t
                    .expect(translateDetail.textDEBox.value).contains(create1.textValue)
                    .expect(translateDetail.textENBox.value).contains(create1.textValue)
                    .expect(translateDetail.textFRBox.value).contains(create1.textValue)
                    .click(translateDetail.cancelBtn)
                    .click(detailsSelector.backBtn);
                //Delete data
                await vatCode.filterVATCode(create1.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')

            })

test.meta({ type: 'base' })
            ('#37425: Check translated data when input normal data at EN language', async t => {
                const create2 = new ManageVATCode()

                //Switch language to DE
                await t.click(translateIndex.languageToggle);
                await t.click(translateIndex.languageENDrop);
                await t.wait(3000);
                //Create VAT Code
                await vatCode.createVATCode(create2.codeValue, create2.textValue)
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn)
                //Open detail view VAT Code
                await vatCode.filterVATCode(create2.codeValue)
                await t.click(indexSelector.editBtn)
                //Open translate data detail view
                await t.click(detailsSelector.translateBtn)
                await t.wait(2000)
                //Assertion
                await t
                    .expect(translateDetail.textDEBox.value).contains(create2.textValue)
                    .expect(translateDetail.textENBox.value).contains(create2.textValue)
                    .expect(translateDetail.textFRBox.value).contains(create2.textValue)
                    .click(translateDetail.cancelBtn)
                    .click(detailsSelector.backBtn)
                //Delete data
                await vatCode.filterVATCode(create2.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('No data to display')
            })

test.meta({ type: 'base' })
            ('#37424: Check translated data when input normal data at FR language', async t => {
                const create3 = new ManageVATCode()

                //Switch language to FR 
                await t.click(translateIndex.languageToggle);
                await t.click(translateIndex.languageFRDrop);
                await t.wait(3000);
                //Create VAT Code
                await vatCode.createVATCode(create3.codeValue, create3.textValue)
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn)
                //Open detail view VAT Code
                await vatCode.filterVATCode(create3.codeValue)
                await t.click(indexSelector.editBtn)
                //Open translate data detail view
                await t.click(detailsSelector.translateBtn)
                await t.wait(2000)
                //Assertion
                await t
                    .expect(translateDetail.textDEBox.value).contains(create3.textValue)
                    .expect(translateDetail.textENBox.value).contains(create3.textValue)
                    .expect(translateDetail.textFRBox.value).contains(create3.textValue)
                    .click(translateDetail.cancelBtn)
                    .click(detailsSelector.backBtn);
                //Delete data
                await vatCode.filterVATCode(create3.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('Aucune donnée à afficher')
            })

test.meta({ type: 'base' })

            ('#37419/37421/37422: Check translated data when entering form data translation first in default language', async t => {
                const create4 = new ManageVATCode()
                //Create VAT Code
                await t
                    .click(indexSelector.addBtn)
                    .typeText(detailsSelector.codeBox, create4.codeValue);
                //Create translated data
                await translate.createTranslate()
                //Expected
                await t
                    .expect(detailsSelector.textBox.value).contains('Text DE');
                //Save VAT Code
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn);
                await vatCode.filterVATCode(create4.codeValue)
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains(create4.codeValue)
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text DE')
                //Check data after swicth default to EN language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageENDrop)
                    .wait(3000)
                await vatCode.filterVATCode(create4.codeValue)
                //Assert after swicth default to EN language
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains(create4.codeValue)
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text EN')
                //Check data after swicth default to FR language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageFRDrop)
                    .wait(5000)
                await vatCode.filterVATCode(create4.codeValue)
                //Assert after swicth default to FR language
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains(create4.codeValue)
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text FR')
                //Delete data
                await t.click(indexSelector.clearFilterBtn)
                await vatCode.filterVATCode(create4.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('Aucune donnée à afficher')
            })

test.meta({ type: 'base' })

            ('#37426/37427/37428: Check translated data when entering form data translation first in EN language', async t => {
                const create5 = new ManageVATCode()
                //Swicth to EN language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageENDrop)
                    .wait(3000);
                //Create VAT Code
                await t
                    .click(indexSelector.addBtn)
                    .typeText(detailsSelector.codeBox, create5.codeValue);
                //Create translated data
                await translate.createTranslate()
                //Expected
                await t
                    .expect(detailsSelector.textBox.value).contains('Text EN');
                //Save VAT Code
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn);
                await vatCode.filterVATCode(create5.codeValue)
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains(create5.codeValue)
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text EN')
                //Check data after swicth default to DE language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageDEDrop)
                    .wait(3000)
                await vatCode.filterVATCode(create5.codeValue)
                //Assert after swicth default to EN language
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains(create5.codeValue)
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text DE')
                //Check data after swicth default to FR language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageFRDrop)
                    .wait(5000)
                await vatCode.filterVATCode(create5.codeValue)
                //Assert after swicth default to FR language
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains(create5.codeValue)
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text FR')
                //Delete data
                await t.click(indexSelector.clearFilterBtn)
                await vatCode.filterVATCode(create5.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('Aucune donnée à afficher')
            })

test.meta({ type: 'base' })

            ('#37429/37430/37431: Check translated data when entering form data translation first in FR language', async t => {
                const create6 = new ManageVATCode()
                //Swicth to EN language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageFRDrop)
                    .wait(3000);
                //Create VAT Code
                await t
                    .click(indexSelector.addBtn)
                    .typeText(detailsSelector.codeBox, create6.codeValue);
                //Create translated data
                await translate.createTranslate()
                //Expected
                await t
                    .expect(detailsSelector.textBox.value).contains('Text FR');
                //Save VAT Code
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn);
                await vatCode.filterVATCode(create6.codeValue)
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains(create6.codeValue)
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text FR')
                //Check data after swicth default to DE language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageDEDrop)
                    .wait(3000)
                await vatCode.filterVATCode(create6.codeValue)
                //Assert after swicth default to EN language
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains(create6.codeValue)
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text DE')
                //Check data after swicth default to EN language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageENDrop)
                    .wait(5000)
                await vatCode.filterVATCode(create6.codeValue)
                //Assert after swicth default to FR language
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains(create6.codeValue)
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text EN')
                //Delete data
                await t.click(indexSelector.clearFilterBtn)
                await vatCode.filterVATCode(create6.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('No data to display')
            })

test.meta({ type: 'base' })

            ('#37457: Check translated data when edit VAT Code at default language', async t => {
                const create7 = new ManageVATCode()
                //Create VAT Code
                await vatCode.createVATCode(create7.codeValue, create7.textValue)
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn)
                //Edit VAT Code
                await vatCode.filterVATCode(create7.codeValue)
                await vatCode.editVATCode(create7.codeValue, 'Text update DE')
                await t.click(detailsSelector.saveCloseBtn)
                await t.wait(5000)
                //Assert
                await vatCode.filterVATCode(create7.codeValue)
                await t
                    .click(indexSelector.editBtn)
                    .click(detailsSelector.translateBtn)
                    .wait(2000)
                    .expect(translateDetail.textDEBox.value).contains('Text update DE')
                    .expect(translateDetail.textENBox.value).contains(create7.textValue)
                    .expect(translateDetail.textFRBox.value).contains(create7.textValue)
                    .click(translateDetail.cancelBtn)
                    .click(detailsSelector.backBtn)
                //Delete data
                await vatCode.filterVATCode(create7.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')

            })


test.meta({ type: 'base' })
            ('#37458: Check translated data when edit VAT Code at EN language', async t => {
                const create8 = new ManageVATCode()
                //Create setting-context
                await vatCode.createVATCode(create8.codeValue, create8.textValue)
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn)
                //Swicth language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageENDrop)
                    .wait(4000);
                //Edit setting-context
                await vatCode.filterVATCode(create8.codeValue)
                await vatCode.editVATCode(create8.codeValue, 'Text update EN')
                await t.click(detailsSelector.saveCloseBtn)
                //Assert
                await vatCode.filterVATCode(create8.codeValue)
                await t
                    .click(indexSelector.editBtn)
                    .click(detailsSelector.translateBtn)
                    .expect(translateDetail.textENBox.value).contains('Text update EN')
                    .expect(translateDetail.textDEBox.value).contains(create8.textValue)
                    .expect(translateDetail.textFRBox.value).contains(create8.textValue)
                    .click(translateDetail.cancelBtn)
                    .click(detailsSelector.backBtn)
                //Delete data

                await vatCode.filterVATCode(create8.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('No data to display')
            })

test.meta({ type: 'base' })

            ('#37459: Check translated data when edit VAT Code at FE language', async t => {
                const create9 = new ManageVATCode()
                //Create setting-context
                await vatCode.createVATCode(create9.codeValue, create9.textValue)
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn)
                //Swicth language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageFRDrop)
                    .wait(4000);
                //Edit setting-context
                await vatCode.filterVATCode(create9.codeValue)
                await vatCode.editVATCode(create9.codeValue, 'Text update FE')
                await t.click(detailsSelector.saveCloseBtn)
                //Assert
                await vatCode.filterVATCode(create9.codeValue)
                await t
                    .click(indexSelector.editBtn)
                    .click(detailsSelector.translateBtn)
                    .expect(translateDetail.textFRBox.value).contains('Text update FE')
                    .expect(translateDetail.textENBox.value).contains(create9.textValue)
                    .expect(translateDetail.textDEBox.value).contains(create9.textValue)
                    .click(translateDetail.cancelBtn)
                    .click(detailsSelector.backBtn)
                //Delete data
                await vatCode.filterVATCode(create9.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('Aucune donnée à afficher')
            })

test.meta({ type: 'base' })

            ('#37460/37461/37462: Check translated data when edit form data translation at default language', async t => {
                const create10 = new ManageVATCode()
                //Create payment
                await t
                    .click(indexSelector.addBtn)
                    .typeText(detailsSelector.codeBox, create10.codeValue);
                //Create translated data
                await translate.createTranslate()
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn)
                //Edit translate data
                await vatCode.filterVATCode(create10.codeValue)
                await t.click(indexSelector.editBtn)
                await translate.editTranslate()
                await t.click(detailsSelector.saveCloseBtn)
                //Assert  after edit translate data
                await vatCode.filterVATCode(create10.codeValue)
                await t.click(indexSelector.editBtn)
                await t
                    //Assert in view detail
                    .expect(detailsSelector.textBox.value).contains('Text update DE')
                    .click(detailsSelector.backBtn)
                    //Assert in view table
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text update DE');
                //Check when switch to EN language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageENDrop)
                    .wait(3000);
                //Assert after switch to EN language
                await vatCode.filterVATCode(create10.codeValue)
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text update EN');
                //Check when switch to FR language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageFRDrop)
                    .wait(3000);
                //Assert after switch to FR language
                await vatCode.filterVATCode(create10.codeValue)
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text update FR');
                //Delete data
                await t.click(indexSelector.clearFilterBtn)
                await vatCode.filterVATCode(create10.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('Aucune donnée à afficher')
            })

test.meta({ type: 'base' })
            ('#37463/37464/37465: Check translated data when edit form data translation at EN language', async t => {
                const create11 = new ManageVATCode()

                //Switch to EN language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageENDrop)
                    .wait(3000);

                //Create VAT Code
                await t
                    .click(indexSelector.addBtn)
                    .typeText(detailsSelector.codeBox, create11.codeValue);
                //Create translated data
                await translate.createTranslate()
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn);
                //Edit translate data
                await vatCode.filterVATCode(create11.codeValue)
                await t.click(indexSelector.editBtn)
                await translate.editTranslate()
                await t.click(detailsSelector.saveCloseBtn)
                //Assert  after edit translate data
                await vatCode.filterVATCode(create11.codeValue)
                await t.click(indexSelector.editBtn)
                await t
                    //Assert in view detail
                    .expect(detailsSelector.textBox.value).contains('Text update EN')
                    .click(detailsSelector.backBtn)
                    //Assert in view table
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text update EN');
                //Check when switch to DN language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageDEDrop)
                    .wait(3000);
                //Assert after switch to EN language
                await vatCode.filterVATCode(create11.codeValue)
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text update DE');
                //Check when switch to FR language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageFRDrop)
                    .wait(3000);
                //Assert after switch to FR language
                await vatCode.filterVATCode(create11.codeValue)
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text update FR');
                //Delete data
                await t.click(indexSelector.clearFilterBtn)
                await vatCode.filterVATCode(create11.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('Aucune donnée à afficher')
            })

test.meta({ type: 'base' })
            ('#37466/37467/37468: Check translated data when edit form data translation at FE language', async t => {
                const create12 = new ManageVATCode()

                //Switch to FE language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageFRDrop)
                    .wait(3000);
                //Create payment
                await t
                    .click(indexSelector.addBtn)
                    .typeText(detailsSelector.codeBox, create12.codeValue);
                //Create translated data
                await translate.createTranslate()
                await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
                await t.click(detailsSelector.saveCloseBtn).debug();
                //Edit translate data
                await vatCode.filterVATCode(create12.codeValue)
                await t.click(indexSelector.editBtn)
                await translate.editTranslate()
                await t.click(detailsSelector.saveCloseBtn)
                //Assert  after edit translate data
                await vatCode.filterVATCode(create12.codeValue)
                await t.click(indexSelector.editBtn)
                await t
                    //Assert in view detail
                    .expect(detailsSelector.textBox.value).contains('Text update FR')
                    .click(detailsSelector.backBtn)
                    //Assert in view tabl
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text update FR');
                //Check when switch to DE language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageDEDrop)
                    .wait(3000);
                //Assert after switch to DE language
                await vatCode.filterVATCode(create12.codeValue)
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text update DE');
                //Check when switch to EN language
                await t
                    .click(translateIndex.languageToggle)
                    .click(translateIndex.languageENDrop)
                    .wait(3000);
                //Assert after switch to FR language
                await vatCode.filterVATCode(create12.codeValue)
                await t
                    .expect(indexSelector.vatCodeTable.innerText).contains('Text update EN');
                //Delete data
                await t.click(indexSelector.clearFilterBtn)
                await vatCode.filterVATCode(create12.codeValue)
                await vatCode.deleteVATCode()
                await t.expect(indexSelector.vatCodeTable.innerText).contains('No data to display')
            })

