import { Selector, t } from "testcafe"
import VATCodeDetailSelector from "../../manage-vat-code/selectors/vat-code.detail.selector";
import TranslateVATCodeDetails from "../selectors/translate-vat-code.detail.selector";

const pageDetailVATCode = new VATCodeDetailSelector()
const translate = new TranslateVATCodeDetails();

export default class TranslateData {
    async createTranslate() {
        await t
            .click(pageDetailVATCode.translateBtn)
            .typeText(translate.textDEBox, 'Text DE')
            .typeText(translate.textENBox, 'Text EN')
            .typeText(translate.textFRBox, 'Text FR')
            .click(translate.saveBtn);
    }

    async editTranslate() {
        await t
            .click(pageDetailVATCode.translateBtn)
            .click(translate.textDEBox)
            .pressKey('ctrl+a delete')
            .typeText(translate.textDEBox, 'Text update DE')
            .click(translate.textENBox)
            .pressKey('ctrl+a delete')
            .typeText(translate.textENBox, 'Text update EN')
            .click(translate.textFRBox)
            .pressKey('ctrl+a delete')
            .typeText(translate.textFRBox, 'Text update FR')
            .click(translate.saveBtn);
    }
}
