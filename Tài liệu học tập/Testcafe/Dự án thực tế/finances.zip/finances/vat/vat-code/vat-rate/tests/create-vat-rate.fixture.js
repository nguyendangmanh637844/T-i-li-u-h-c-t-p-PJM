﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration"
import LoginPage from "../../../../../authentication/functions/login-page"
import VATRateIndexSelector from "../selectors/vat-rate.index.selector";
import VATRateDetailSelector from "../selectors/vat-rate.detail.selector";
import ManageVATRate from "../functions/manage-vat-rate"
import ManageVATCode from "../../manage-vat-code/functions/manage-vat-code"
import VATCodeIndexSelector from "../../manage-vat-code/selectors/vat-code.index.selector"
import VATCodeDetailSelector from "../../manage-vat-code/selectors/vat-code.detail.selector"

const config = new Configuration()
const login = new LoginPage()
const detailsSelector = new VATRateDetailSelector()
const indexSelector = new VATRateIndexSelector()
const vatRate = new ManageVATRate()
const vatCode = new ManageVATCode()
const codeIndexSelector = new VATCodeIndexSelector()
const codeDetailSelector = new VATCodeDetailSelector()


fixture`Finance - VAT Rate: Create VAT Rate`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(codeIndexSelector.financeMenu)
        await t.click(codeIndexSelector.vatMenu)
        await t.click(codeIndexSelector.vatCodeMenu)
    })

test.meta({ type: 'base' })
    ('#37812: Create VAT Rate with valid value', async t => {
        const createVATCode1 = new ManageVATCode()
       
        //Create VAT Code
        await vatCode.createVATCode(createVATCode1.codeValue, createVATCode1.textValue)
         //Create VAT Rate
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        //Assert 
        await t
            .expect(indexSelector.vatRateTable.innerText).contains('24.05.2022')
            .expect(indexSelector.vatRateTable.innerText).contains('Rate text')
            .expect(indexSelector.vatRateTable.innerText).contains('Rate Short text')
            .expect(indexSelector.vatRateTable.innerText).contains('10')
        await t.click(codeDetailSelector.saveCloseBtn)
       
        await vatCode.filterVATCode(createVATCode1.codeValue)
        await t.click(codeIndexSelector.editBtn)
        
        //Delete Vat Rate
        await vatRate.deleteVATRate()
        await t.expect(indexSelector.vatRateTable.innerText).contains('Keine Daten zum Anzeigen')

        //Delete Vat Code
        await t.click(codeDetailSelector.backBtn)
        await vatCode.filterVATCode(createVATCode1.codeValue)
        await vatCode.deleteVATCode()
        await t.expect(codeIndexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37814: Create VAT Rate with blank Text', async t => {
        const createVATCode2 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(createVATCode2.codeValue, createVATCode2.textValue)
        await vatRate.createVATRate(' ', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t
            .expect(detailsSelector.valMessage.innerText).contains('Dieses Feld ist erforderlich')
            .click(detailsSelector.cancelBtn)      
        // Back to list VAT Code
        await t.click(codeDetailSelector.backBtn)
        await vatCode.filterVATCode(createVATCode2.codeValue)
        await t.expect(codeIndexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37816: Create VAT Rate with Text more than 100 characters', async t => {
        const createVATCode3 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(createVATCode3.codeValue, createVATCode3.textValue)
        await vatRate.createVATRate(' VAT Rate text VAT Rate text VAT Rate text VAT Rate text VAT Rate text VAT Rate text VAT Rate text VAT Rate text VAT Rate text VAT Rate text VAT Rate text VAT Rate ', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        //Assert
        await t
            .expect(detailsSelector.valMessage.innerText).contains('Die maximale Länge beträgt 100 Zeichen')
            .click(detailsSelector.cancelBtn)
        //Back to Vat Code list
        await t.click(codeDetailSelector.backBtn)
        await vatCode.filterVATCode(createVATCode3.codeValue)
        await t.expect(codeIndexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37817: Create VAT Rate with blank Short Text', async t => {
        const createVATCode4 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(createVATCode4.codeValue, createVATCode4.textValue)
        //Create VAT Rate
        await vatRate.createVATRate('Rate text', ' ', 'Rate Print text', '10', '24.05.2022')
        //Assert
        await t
            .expect(detailsSelector.valMessage.innerText).contains('Dieses Feld ist erforderlich')
            .click(detailsSelector.cancelBtn)
        //Back Vat Code list
        await t.click(codeDetailSelector.backBtn)
        await vatCode.filterVATCode(createVATCode4.codeValue)
        await t.expect(codeIndexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37818: Create VAT Rate with Short Text more than 100 characters', async t => {
        const createVATCode5 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(createVATCode5.codeValue, createVATCode5.textValue)
        //Create VAT Rate
        await vatRate.createVATRate('Rate text', 'VAT Rate Short text VAT Rate Short text VAT Rate Short text  VAT Rate Short text  VAT Rate Short text  VAT Rate Short text  VAT Rate Short text  VAT Rate Short text   ', 'Rate Print text', '10', '24.05.2022')
        //Assert
        await t
            .expect(detailsSelector.valMessage.innerText).contains('Die maximale Länge beträgt 100 Zeichen')
            .click(detailsSelector.cancelBtn)
        //Back to Vat Code list
        await t.click(codeDetailSelector.backBtn)
        await vatCode.filterVATCode(createVATCode5.codeValue)
        await t.expect(codeIndexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37887: Create VAT Rate with blank Print Text', async t => {
        const createVATCode6 = new ManageVATCode()
        //Create VAT Code
        await vatCode.createVATCode(createVATCode6.codeValue, createVATCode6.textValue)
        //Create VAT Rate
        await vatRate.createVATRate('Rate text', 'Rate Short text ', '  ', '10', '24.05.2022')
        //Assert
        await t
            .expect(detailsSelector.valMessage.innerText).contains('Dieses Feld ist erforderlich')
            .click(detailsSelector.cancelBtn)
        //Back to Vat Code list
        await t.click(codeDetailSelector.backBtn)
        await vatCode.filterVATCode(createVATCode6.codeValue)
        await t.expect(codeIndexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37888: Create VAT Rate with Print Text more than 100 characters', async t => {
        const createVATCode7 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(createVATCode7.codeValue, createVATCode7.textValue)
        //Create VAT Rate
        await vatRate.createVATRate('Rate text', 'Rate Short text ', 'VAT Rate Print text VAT Rate Print text VAT Rate Print text  VAT Rate Print text  VAT Rate Print text  VAT Rate Print text  VAT Rate Print text  VAT Rate Print text   ', '10', '24.05.2022')
        //Assert
        await t
            .expect(detailsSelector.valMessage.innerText).contains('Die maximale Länge beträgt 100 Zeichen')
            .click(detailsSelector.cancelBtn)
        //Back to Vat Code list
        await t.click(codeDetailSelector.backBtn)
        await vatCode.filterVATCode(createVATCode7.codeValue)
        await t.expect(codeIndexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37891: Create VAT Rate with duplicate value of Valid from field', async t => {
        const createVATCode8 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(createVATCode8.codeValue, vatCode.textValue)
        //Create VAT Rate
        await vatRate.createVATRate('Rate text 1', 'Rate Short text 1', 'Rate Print text 1', '10', '24.05.2022')
        //Assert 
        await t
            .expect(indexSelector.vatRateTable.innerText).contains('24.05.2022')
            .expect(indexSelector.vatRateTable.innerText).contains('Rate text')
            .expect(indexSelector.vatRateTable.innerText).contains('Rate Short text')
            .expect(indexSelector.vatRateTable.innerText).contains('10')
        await vatRate.createVATRate('Rate text 2', 'Rate Short text 2', 'Rate Print text 2', '10', '24.05.2022')
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Dieses Gültig-ab-Datum hat bereits existiert')
            .click(detailsSelector.closeMessage)
            .click(detailsSelector.cancelBtn)
        //Delete Vat Rate
        await vatRate.deleteVATRate()
        await t.expect(indexSelector.vatRateTable.innerText).contains('Keine Daten zum Anzeigen')
        //Delete Vat Code
        await t.click(codeDetailSelector.backBtn)
        await vatCode.filterVATCode(createVATCode8.codeValue)
        await t.expect(codeIndexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

