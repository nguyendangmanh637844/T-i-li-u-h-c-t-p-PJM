import VATRateIndexSelector from "../selectors/vat-rate.index.selector";
import VATRateDetailSelector from "../selectors/vat-rate.detail.selector";
import { t } from "testcafe";

const indexSelector = new VATRateIndexSelector();
const detailSelector = new VATRateDetailSelector();

export default class ManageVATRate {
    async createVATRate(text, shortText, printText, rate, from) {
        await t
            .click(indexSelector.addBtn)
            .click(detailSelector.textBox)
            .pressKey('ctrl+a delete')
            .typeText(detailSelector.textBox, text)
            .click(detailSelector.shortTextBox)
            .pressKey('ctrl+a delete')
            .typeText(detailSelector.shortTextBox, shortText)
            .click(detailSelector.printTextBox)
            .pressKey('ctrl+a delete')
            .typeText(detailSelector.printTextBox, printText)
            .click(detailSelector.rateBox)
            .pressKey('ctrl+a delete')
            .typeText(detailSelector.rateBox, rate)
            .click(detailSelector.validFromBox)
            .pressKey('ctrl+a delete')
            .typeText(detailSelector.validFromBox, from)
            .click(detailSelector.saveBtn)
            .wait(2000);
    }

    async editVATRate(text, shortText, printText, rate, from) {
        await t
            .click(indexSelector.editBtn)
            .click(detailSelector.textBox)
            .pressKey('ctrl+a delete')
            .typeText(detailSelector.textBox, text)
            .click(detailSelector.shortTextBox)
            .pressKey('ctrl+a delete')
            .typeText(detailSelector.shortTextBox, shortText)
            .click(detailSelector.printTextBox)
            .pressKey('ctrl+a delete')
            .typeText(detailSelector.printTextBox, printText)
            .click(detailSelector.rateBox)
            .pressKey('ctrl+a delete')
            .typeText(detailSelector.rateBox, rate)
            .click(detailSelector.validFromBox)
            .pressKey('ctrl+a delete')
            .typeText(detailSelector.validFromBox, from)
            .click(detailSelector.saveBtn)
            .wait(2000);
    }

    async deleteVATRate() {
        await t
            .click(indexSelector.deleteBtn)
            .click(indexSelector.yesConfirmDeleteBtn)
    }
}
