import { Selector } from "testcafe";

export default class VATRateDetailSelector {
    constructor() {
        this.textBox = Selector('#vatcoderate-text')
        this.shortTextBox = Selector('#vatcoderate-shorttext')
        this.printTextBox = Selector('#vatcoderate-printtext')
        this.rateBox = Selector('#vatcoderate-rate')
        this.validFromBox = Selector('#vatcoderate-validfrom')
        this.validUntilBox = Selector('vatcoderate-validuntil')
        this.vatCodeBox = Selector('#vatcoderate-vat-input')

        this.cancelBtn = Selector('#btn-Cancel')
        this.saveBtn = Selector('#btn-submit')

        this.valMessage = Selector('div[class="validation-message"]')
        this.errorMessage = Selector('div[class="modal-content dxbs-modal-content"]')
        this.closeMessage = Selector('#btn-close-alert')
    }
};