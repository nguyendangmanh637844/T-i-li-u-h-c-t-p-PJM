import { Selector } from "testcafe";

export default class VATRateIndexSelector {
    constructor() {
        this.addBtn = Selector('#btn-add-vatcode-rate')
        this.editBtn = Selector('#btn-edit')
        this.deleteBtn = Selector('#btn-delete')
        this.yesConfirmDeleteBtn = Selector('#btn-confirm-yes')
        this.cancelConfirmDeleteBtn = Selector('#btn-confirm-no')
        this.vatRateTable = Selector('div').withAttribute('class','dxbs-scroll-viewer-content')
    }
};