﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration"
import LoginPage from "../../../../../authentication/functions/login-page"
import VATCodeIndexSelector from "../selectors/vat-code.index.selector"
import VATCodeDetailSelector from "../selectors/vat-code.detail.selector"
import ManageVATCode from "../functions/manage-vat-code"
import ManageVATRate from "../../vat-rate/functions/manage-vat-rate"

const config = new Configuration()
const login = new LoginPage()
const detailsSelector = new VATCodeDetailSelector()
const indexSelector = new VATCodeIndexSelector()
const vatCode = new ManageVATCode()
const vatRate = new ManageVATRate()

fixture`Finance - VAT Code: Copy VAT Code`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatCodeMenu)
    })

test.meta({ type: 'base' })
    ('#37581: Copy VAT Code with Save and Close button', async t => {
        const create1 = new ManageVATCode()
        const copy1 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(create1.codeValue, create1.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        //copy VAT Code
        await vatCode.filterVATCode(create1.codeValue)
        await vatCode.copyVATCode(copy1.codeValue, copy1.textValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await vatCode.filterVATCode(copy1.codeValue)
        await t
            .expect(indexSelector.vatCodeTable.innerText).contains(copy1.codeValue)
            .expect(indexSelector.vatCodeTable.innerText).contains(copy1.textValue)
        //Delete Vat Code
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    ('#37388: copy VAT Code with Save and New button', async t => {
        const create2 = new ManageVATCode()
        const copy2 = new ManageVATCode()

        //Create VAT Code 
        await vatCode.createVATCode(create2.codeValue, create2.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        //copy VAT Code
        await vatCode.filterVATCode(create2.codeValue)
        await vatCode.copyVATCode(copy2.codeValue, copy2.textValue)
        await t.click(detailsSelector.saveDropDownBtn).click(detailsSelector.saveNewBtn)
        await t.click(detailsSelector.backBtn)
        //Assert 
        await vatCode.filterVATCode(copy2.codeValue)
        await t
            .expect(indexSelector.vatCodeTable.innerText).contains(copy2.codeValue)
            .expect(indexSelector.vatCodeTable.innerText).contains(copy2.textValue)
        //Delete VAT Code
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37389: copy VAT Code with blank Code', async t => {
        const create3 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(create3.codeValue, create3.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        //copy VAT Code
        await vatCode.filterVATCode(create3.codeValue)
        await vatCode.copyVATCode(' ', 'Text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to VAT Code list
        await t.click(detailsSelector.backBtn)
        //Delete VAT Code
        await vatCode.filterVATCode(create3.codeValue)
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37390: copy VAT Code with duplicate Code', async t => {
        const create41 = new ManageVATCode()
        const create42 = new ManageVATCode()

        //Create the first VAT Code
        await vatCode.createVATCode(create41.codeValue, create41.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        //Create the second VAT Code
        await vatCode.createVATCode(create42.codeValue, create42.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        //copy VAT Code 2
        await vatCode.filterVATCode(create42.codeValue)
        await vatCode.copyVATCode(create41.codeValue, 'Text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('')
            .click(detailsSelector.closeErrorMessage)
        //Back to VAT Code list
        await t.click(detailsSelector.backBtn)
        //Delete VAT Code 1
        await vatCode.filterVATCode(create41.codeValue)
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
        //Delete VAT Code 2
        await t.click(indexSelector.clearFilterBtn)
        await vatCode.filterVATCode(create42.codeValue)
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37391: copy VAT Code with Code more than 50 characters', async t => {
        const create5 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(create5.codeValue, create5.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        //copy VAT Code 
        await vatCode.filterVATCode(create5.codeValue)
        await vatCode.copyVATCode('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', 'Text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 50 Zeichen')
        //Back to VAT Code list
        await t.click(detailsSelector.backBtn)
        //Delete VAT code
        await vatCode.filterVATCode(create5.codeValue)
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    ('#37392: Create VAT Code with blank Text', async t => {
        const create6 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(create6.codeValue, create6.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        //copy VAT Code
        await vatCode.filterVATCode(create6.codeValue)
        await vatCode.copyVATCode('VAT Code', ' ')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to VAT Code list
        await t.click(detailsSelector.backBtn)
        //Delete VAT code
        await vatCode.filterVATCode(create6.codeValue)
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')

    })

test.meta({ type: 'advance' })
    ('#37393: copy VAT Code with Text more than 254 characters', async t => {
        const create7 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(create7.codeValue, create7.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        //copy VAT Code
        await vatCode.filterVATCode(create7.codeValue)
        await vatCode.copyVATCode('VAT Code', 'Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 254 Zeichen')
        //Back to payment list
        await t.click(detailsSelector.backBtn)
        //Delete VAT code
        await vatCode.filterVATCode(create7.codeValue)
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })