import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration"
import LoginPage from "../../../../../authentication/functions/login-page"
import VATCodeIndexSelector from "../selectors/vat-code.index.selector"
import VATCodeDetailSelector from "../selectors/vat-code.detail.selector"
import ManageVATCode from "../functions/manage-vat-code"
import ManageVATRate from "../../vat-rate/functions/manage-vat-rate"

const config = new Configuration()
const login = new LoginPage()
const detailsSelector = new VATCodeDetailSelector()
const indexSelector = new VATCodeIndexSelector()
const vatCode = new ManageVATCode()
const vatRate = new ManageVATRate()


fixture`Finance - VAT Code: Filter VAT Code`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatCodeMenu)
    })

test.meta({ type: 'base' })
    ('#37338: Filter VAT Code with valid Code', async t => {
    const create1 = new ManageVATCode()

    //Create VAT Code
    await vatCode.createVATCode(create1.codeValue, create1.textValue)
    await vatRate.createVATRate('Rate text 1', 'Rate Short text 1', 'Rate Print text 1', '10', '24.05.2022')
    await t.click(detailsSelector.saveCloseBtn)
    await vatCode.filterVATCode(create1.codeValue)
    //Assert 
    await t
        .expect(indexSelector.vatCodeTable.innerText).contains(create1.codeValue)
        .expect(indexSelector.vatCodeTable.innerText).contains(create1.textValue)
    //Delete Vat Code
    await vatCode.deleteVATCode()
    await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
})

test.meta({ type: 'advance' })
    ('#37338: Filter VAT Code with invalid Code', async t => {
    const create2 = new ManageVATCode()

    //Create VAT Code
    await vatCode.createVATCode(create2.codeValue, create2.textValue)
    await vatRate.createVATRate('Rate text 1', 'Rate Short text 1', 'Rate Print text 1', '10', '24.05.2022')

    await t.click(detailsSelector.saveCloseBtn)
    await vatCode.filterVATCode("123@abc")
    //Assert 
    await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    //Delete Vat Code
    await t.click(indexSelector.clearFilterBtn)
    await vatCode.filterVATCode(create2.codeValue)
    await t
        .expect(indexSelector.vatCodeTable.innerText).contains(create2.codeValue)
        .expect(indexSelector.vatCodeTable.innerText).contains(create2.textValue)
    await vatCode.deleteVATCode()
    await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
})