import { Selector, t } from "testcafe"
import VATCodeIndexSelector from "../selectors/vat-code.index.selector";
import VATCodeDetailSelector from "../selectors/vat-code.detail.selector";
import Utils from "../../../../../../commons/utils";

const detailsSelector = new VATCodeDetailSelector();
const indexSelector = new VATCodeIndexSelector();
const randomData = new Utils();


export default class ManageVATCode {
    constructor() {
        this.codeValue = randomData.getText('VAT_Code', 15);
        this.textValue = randomData.getText('VAT_Text', 15)

    }
    async filterVATCode(code) {
        await t
            .click(indexSelector.filterBox)
            .pressKey('ctrl+a delete')
            .typeText(indexSelector.filterBox, code)
            .pressKey('enter')
    }

    async createVATCode(code, text) {
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.codeBox, code)
            .typeText(detailsSelector.textBox, text)
    }

    async editVATCode(code, text) {
        await t
            .click(indexSelector.editBtn)
            .click(detailsSelector.codeBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.codeBox, code)
            .click(detailsSelector.textBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.textBox, text)
    }

    async copyVATCode(code, text) {
        await t
            .click(indexSelector.editBtn)
            .click(detailsSelector.copyBtn)
            .click(detailsSelector.codeBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.codeBox, code)
            .click(detailsSelector.textBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.textBox, text)
    }

    async deleteVATCode() {
        await t
            .click(indexSelector.deleteBtn)
            .click(indexSelector.confirmDeleteBtn)
    }

}
