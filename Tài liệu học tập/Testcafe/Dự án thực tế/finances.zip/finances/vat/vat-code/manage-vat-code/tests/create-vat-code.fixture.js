﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration"
import LoginPage from "../../../../../authentication/functions/login-page"
import VATCodeIndexSelector from "../selectors/vat-code.index.selector"
import VATCodeDetailSelector from "../selectors/vat-code.detail.selector"
import ManageVATCode from "../functions/manage-vat-code"
import ManageVATRate from "../../vat-rate/functions/manage-vat-rate"

const config = new Configuration()
const login = new LoginPage()
const detailsSelector = new VATCodeDetailSelector()
const indexSelector = new VATCodeIndexSelector()
const vatCode = new ManageVATCode()
const vatRate = new ManageVATRate()


fixture`Finance - VAT Code: Create VAT Code`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatCodeMenu)
    })

test.meta({ type: 'base' })
    ('#37365: Create VAT Code with Save and Close button', async t => {
    const create1 = new ManageVATCode()

    //Create VAT Code
    await vatCode.createVATCode(create1.codeValue, create1.textValue)
    await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
    await t.click(detailsSelector.saveCloseBtn)
    await vatCode.filterVATCode(create1.codeValue)
    //Assert 
    await t
        .expect(indexSelector.vatCodeTable.innerText).contains(create1.codeValue)
        .expect(indexSelector.vatCodeTable.innerText).contains(create1.textValue)
    //Delete Vat Code
    await vatCode.deleteVATCode()
    await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    (' Create VAT Code no VAT Rate', async t => {
        const create5 = new ManageVATCode()

        //Create VAT Code
        await vatCode.createVATCode(create5.codeValue, create5.textValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('MwSt-Satz ist erforderlich')
            .click(detailsSelector.closeErrorMessage)
        //Back to Vat Code
        await t.click(detailsSelector.backBtn)
        await vatCode.filterVATCode(create5.codeValue)
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    ('#37366: Create VAT Code with Save and New button', async t => {
     const create2 = new ManageVATCode()

     //Create VAT Code 
    await vatCode.createVATCode(create2.codeValue, create2.textValue)
    await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
    await t.click(detailsSelector.saveDropDownBtn)
            .click(detailsSelector.saveNewBtn)
    await t.click(detailsSelector.backBtn);
    //Assert 
        await vatCode.filterVATCode(create2.codeValue)
    await t
        .expect(indexSelector.vatCodeTable.innerText).contains(create2.codeValue)
        .expect(indexSelector.vatCodeTable.innerText).contains(create2.textValue)
    //Delete VAT Code
    await vatCode.deleteVATCode()
    await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
})


test.meta({ type: 'advance' })
    ('#37367: Create VAT Code with blank Code', async t => {

    //Create VAT Code
    await vatCode.createVATCode(' ', 'text')
    await t.click(detailsSelector.saveCloseBtn)
    //Assert 
    await t
        .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
    //Back to VAT Code list
    await t.click(detailsSelector.backBtn)
})

test.meta({ type: 'advance' })
    ('#37368: Create VAT Code with duplicate Code', async t => {
    const create4 = new ManageVATCode()
    //Create the first VAT Code
     await vatCode.createVATCode(create4.codeValue, create4.textValue)
     await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
     await t.click(detailsSelector.saveCloseBtn)
    //Create the second VAT Code
     await vatCode.createVATCode(create4.codeValue, create4.textValue)
     await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
    await t.click(detailsSelector.saveCloseBtn)
    //Assert 
    await t
        .expect(detailsSelector.errorMessage.innerText).contains('Dieser MWST-Code hat bereits existiert')
        .click(detailsSelector.closeErrorMessage)
    //Back to VAT Code list
    await t.click(detailsSelector.backBtn)
    //Delete VAT Code
    await vatCode.filterVATCode(create4.codeValue)
    await vatCode.deleteVATCode()
    await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
})

test.meta({ type: 'advance' })
    ('#37369: Create VAT Code with Code more than 50 characters', async t => {

    //Create VAT Code
    await vatCode.createVATCode('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', 'Text')
    await t.click(detailsSelector.saveCloseBtn)
    //Assert 
    await t
        .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 50 Zeichen')
    //Back to VAT Code list
    await t.click(detailsSelector.backBtn)
})

test.meta({ type: 'advance' })
    ('#37370: Create VAT Code with blank Text', async t => {

    //Create VAT Code
    await vatCode.createVATCode('VAT Code',  ' ')
    await t.click(detailsSelector.saveCloseBtn)
    //Assert 
    await t
        .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
    //Back to VAT Code list
    await t.click(detailsSelector.backBtn)
})

test.meta({ type: 'advance' })
    ('#37371: Create VAT Code with Text more than 254 characters', async t => {

    //Create VAT Code
    await vatCode.createVATCode('VAT Code', 'Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text Test VAT Code Text')
    await t.click(detailsSelector.saveCloseBtn)
    //Assert 
    await t
        .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 254 Zeichen')
    //Back to VAT Code list
    await t.click(detailsSelector.backBtn)
})