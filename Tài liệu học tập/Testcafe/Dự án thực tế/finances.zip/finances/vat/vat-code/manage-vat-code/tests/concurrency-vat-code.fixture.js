﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../../commons/configuration"
import LoginPage from "../../../../../authentication/functions/login-page"
import VATCodeIndexSelector from "../selectors/vat-code.index.selector"
import VATCodeDetailSelector from "../selectors/vat-code.detail.selector"
import ManageVATCode from "../functions/manage-vat-code"
import ManageVATRate from "../../vat-rate/functions/manage-vat-rate"

const config = new Configuration()
const login = new LoginPage()
const detailsSelector = new VATCodeDetailSelector()
const indexSelector = new VATCodeIndexSelector()
const vatCode = new ManageVATCode()
const vatRate = new ManageVATRate()

fixture`Finance - VAT Code: Concurrency VAT Code`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatCodeMenu)
    })

test
    /*Scenario: #37475/37487: Check concurrency when users edit VAT Code with Override option' 
      - Open browser, login with user 1, edit a VAT Code
      - Open new browser, login with user 2, edit the same VAT Code with user 1, click Save
      - Back to user 1, click Save
      - Click Override
       */
    ('#37475/37487: Check concurrency when users edit VAT Code with Override option', async t => {
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);
        const create1 = new ManageVATCode()
        const edit11 = new ManageVATCode()
        const edit12 = new ManageVATCode()

        //Create VAT Code at window 1
        await t.switchToWindow(initialWindow);
        await vatCode.createVATCode(create1.codeValue, create1.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        // Edit VAT Code at window 1
        await vatCode.filterVATCode(create1.codeValue)
        await vatCode.editVATCode(edit11.codeValue, edit11.textValue)
        //Edit VAT Code at window 2
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatCodeMenu)
        await vatCode.filterVATCode(create1.codeValue)
        await vatCode.editVATCode(edit12.codeValue, edit12.textValue)
        await t.click(detailsSelector.saveCloseBtn)
        //switch to window 1
        await t.switchToWindow(initialWindow);
        await t.click(detailsSelector.saveCloseBtn)
        await t.wait(3000)
        //Assert message
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Widersprüchliche Informationen')
        //Assert informantion
        await t.expect(detailsSelector.errorMessage.innerText).contains(edit12.codeValue)
        await t.expect(detailsSelector.errorMessage.innerText).contains(edit12.textValue)

        //Override information
        await t.click(detailsSelector.overrideBtn)
        //Assert
        await vatCode.filterVATCode(edit11.codeValue)
        await t
            .expect(indexSelector.vatCodeTable.innerText).contains(edit11.codeValue)
            .expect(indexSelector.vatCodeTable.innerText).contains(edit11.textValue)
        //Delete data
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test
    /*Scenario: #37475/37487: Check concurrency when users edit VAT Code with Refresh option'
      - Open browser, login with user 1, edit a VAT Code
      - Open new browser, login with user 2, edit the same VAT Code with user 1, click Save
      - Back to user 1, click Save
      - Click Refresh
       */
    ('#37475/37488: Check concurrency when both users edit the same VAT Code with Refresh option', async t => {
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);
        const create2 = new ManageVATCode()
        const edit21 = new ManageVATCode()
        const edit22 = new ManageVATCode()

        //Create VAT Code at window 1
        await t.switchToWindow(initialWindow);
        await vatCode.createVATCode(create2.codeValue, create2.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        // Edit VAT Code at window 1
        await vatCode.filterVATCode(create2.codeValue)
        await vatCode.editVATCode(edit21.codeValue, edit21.textValue)

        //Edit VAT Code at window 2
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatCodeMenu)
        await vatCode.filterVATCode(create2.codeValue)
        await vatCode.editVATCode(edit22.codeValue, edit22.textValue)
        await t.click(detailsSelector.saveCloseBtn)
        //switch to window 1
        await t.switchToWindow(initialWindow);
        await t.click(detailsSelector.saveCloseBtn)
        await t.wait(3000)
        //Assert message
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Widersprüchliche Informationen')
        //Assert informantion
        await t.expect(detailsSelector.errorMessage.innerText).contains(edit22.codeValue)
        await t.expect(detailsSelector.errorMessage.innerText).contains(edit22.textValue)
        await t.wait(5000)
        await t.click(detailsSelector.refreshBtn)
        await t.wait(2000)
        await t.expect(detailsSelector.codeBox.value).contains(edit22.codeValue)
        await t.expect(detailsSelector.textBox.value).contains(edit22.textValue)
        await t.click(detailsSelector.backBtn)
        //Assert
        await vatCode.filterVATCode(edit22.codeValue)
        await t
            .expect(indexSelector.vatCodeTable.innerText).contains(edit22.codeValue)
            .expect(indexSelector.vatCodeTable.innerText).contains(edit22.textValue)
        //Delete data
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test
    /*Scenario: #337475/37489: Check concurrency when users edit VAT Code with Cancel option'
      - Open browser, login with user 1, edit a VAT Code
      - Open new browser, login with user 2, edit the same VAT Code with user 1, click Save
      - Back to user 1, click Save
      - Click Cancel
       */
    ('#37475/37489: Check concurrency when both users edit the same VAT Code with Cancel option', async t => {
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);
        const create3 = new ManageVATCode()
        const edit31 = new ManageVATCode()
        const edit32 = new ManageVATCode()

        //Create VAT Code at window 1
        await t.switchToWindow(initialWindow);
        await vatCode.createVATCode(create3.codeValue, create3.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        // Edit VAT Code at window 1
        await vatCode.filterVATCode(create3.codeValue)
        await vatCode.editVATCode(edit31.codeValue, edit31.textValue)

        //Edit VAT Code at window 2
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatCodeMenu)
        await vatCode.filterVATCode(create3.codeValue)
        await vatCode.editVATCode(edit32.codeValue, edit32.textValue)
        await t.click(detailsSelector.saveCloseBtn)
        //switch to window 1
        await t.switchToWindow(initialWindow);
        await t.click(detailsSelector.saveCloseBtn)
        await t.wait(3000)
        //Assert message
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Widersprüchliche Informationen')
        //Assert informantion
        await t.expect(detailsSelector.errorMessage.innerText).contains(edit32.codeValue)
        await t.expect(detailsSelector.errorMessage.innerText).contains(edit32.textValue)

        await t.click(detailsSelector.cancelBtn)
        await t.expect(detailsSelector.codeBox.value).contains(edit31.codeValue)
        await t.expect(detailsSelector.textBox.value).contains(edit31.textValue)
        await t.click(detailsSelector.backBtn)
        //Assert
        await vatCode.filterVATCode(edit32.codeValue)
        await t
            .expect(indexSelector.vatCodeTable.innerText).contains(edit32.codeValue)
            .expect(indexSelector.vatCodeTable.innerText).contains(edit32.textValue)
        //Delete data
        await vatCode.deleteVATCode()
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test
    /*Scenario: #37483: Check concurrency when users delete the same VAT Code'
       - Open browser, login with user 1, delete a VAT Code
       - Open new browser, login with user 2, delete the same VAT Code with user 1, click Save
       - Back to user 1, click Save
        */
    ('#37483: Check concurrency when both users delete the same VAT Code', async t => {
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);
        const create4 = new ManageVATCode()

        //Create VAT Code at window 1
        await t.switchToWindow(initialWindow);
        await vatCode.createVATCode(create4.codeValue, create4.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn)
        // Delete VAT Code at window 1
        await vatCode.filterVATCode(create4.codeValue)
        await t.click(indexSelector.deleteBtn)

        //Delete VAT Code at window 2
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatCodeMenu)
        await vatCode.filterVATCode(create4.codeValue)
        await vatCode.deleteVATCode()
        //switch to window 1
        await t.switchToWindow(initialWindow);
        await t.click(indexSelector.confirmDeleteBtn)
            .wait(2000)
            .expect(detailsSelector.errorMessage.innerText).contains('Kann nicht gelöscht werden. Der Datensatz wurde von einem anderen Benutzer gelöscht.')
            .click(detailsSelector.closeErrorMessage)
        //Assert
        await vatCode.filterVATCode(create4.codeValue)
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test
    /*Scenario:  #36229: Check concurrency when user 1 delete and user 2 edit the same payment'
   - Open browser, login with user 1, delete a payment
   - Open new browser, login with user 2, edit the same payment with user 1
   - Back to user 1, click Save
   - Back to user 2, click Save
*/
    .meta({ type: 'base' })
    ('#36229: Check concurrency when user 1 delete and user 2 edit the same payment', async t => {
        const initialWindow = await t.getCurrentWindow();
        const window1 = await t.openWindow(config.UrlAdmin);
        const create5 = new ManageVATCode()
        const edit52 = new ManageVATCode()

        //Create currency at initial Window
        await t.switchToWindow(initialWindow);
        await vatCode.createVATCode(create5.codeValue, create5.textValue)
        await vatRate.createVATRate('Rate text', 'Rate Short text', 'Rate Print text', '10', '24.05.2022')
        await t.click(detailsSelector.saveCloseBtn);
        //Open detail view at initial Window
        await vatCode.filterVATCode(create5.codeValue)
        await t.click(indexSelector.deleteBtn)

        //Open second browser
        await t.switchToWindow(window1);
        await t.maximizeWindow()
        await t.wait(5000)
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.vatMenu)
        await t.click(indexSelector.vatCodeMenu)
        //Open detail view at second Window and edit that account
        await vatCode.filterVATCode(create5.codeValue)
        await vatCode.editVATCode(edit52.codeValue, edit52.textValue)

        //Open the first window
        await t.switchToWindow(initialWindow);
        await t
            .click(indexSelector.confirmDeleteBtn)
            .wait(2000);

        //Open second browser
        await t.switchToWindow(window1);
        await t.click(detailsSelector.saveCloseBtn)
        //Assert
        await t.expect(detailsSelector.errorMessage.innerText).contains('Speichern nicht möglich. Die Datensatz wurde von einem anderen Benutzer gelöscht.')
        await t.click(detailsSelector.closeErrorMessage)
        //Assert
        await vatCode.filterVATCode(create5.codeValue)
        await t.expect(indexSelector.vatCodeTable.innerText).contains('Keine Daten zum Anzeigen')

    });