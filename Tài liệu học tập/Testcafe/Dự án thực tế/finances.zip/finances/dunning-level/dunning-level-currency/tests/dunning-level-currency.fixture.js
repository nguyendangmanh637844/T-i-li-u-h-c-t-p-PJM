import { Selector, t } from "testcafe";
import Configuration from "../../../../../commons/configuration";
import LoginPage from "../../../../authentication/functions/login-page";
import DunningDetailSelector from "../../manage-dunning-level/selectors/dunning.detail.selector";
import DunningIndexSelector from "../../manage-dunning-level/selectors/dunning.index.selector";
import ManageDunningLevel from "../../manage-dunning-level/functions/manage-dunning-level";
import DunningCurrencyIndexSelector from "../selectors/dunning-level-currency.index.selector";
import DunningCurrencyDetailSelector from "../selectors/dunning-level-currency.detail.selector";
import CreateDunningCurrency from "../functions/create-dunning-level-currency";
import EditDunningCurrency from "../functions/edit-dunning-level-currency";

const config = new Configuration();
const login = new LoginPage();
const detailDunningSelector = new DunningDetailSelector();
const indexDunningSelector = new DunningIndexSelector();
const detailSelector = new DunningCurrencyDetailSelector();
const indexSelector = new DunningCurrencyIndexSelector();
const createDunningCurrency = new CreateDunningCurrency();
const editDunningCurrency = new EditDunningCurrency();

fixture`Finance - Dunning: Dunning level currency`
  .page(config.UrlAdmin)
  .beforeEach(async (t) => {
    await config.configBeforeEach();
    await login.login(config.UserName, config.Password);
    await t.click(indexDunningSelector.financeMenu);
    await t.click(indexDunningSelector.dunningLevelsMenu);
  });

test.meta({ type: "base" })(
  "Check create Dunning level currency successfully when create Dunning level",
  async (t) => {
    const manageDunningTC1 = new ManageDunningLevel();
    //Create Create Dunning levels
    await manageDunningTC1.createDunningLevels();
    //Create exchange rate
    await createDunningCurrency.createDunningCurrency();
    await t.click(detailDunningSelector.saveCloseBtn);
    //Open detail view Dunning level
    await manageDunningTC1.filterDunning(manageDunningTC1.codeValue);
    await t.click(indexDunningSelector.editBtn);
    await t.wait(2000);
    await t.scrollIntoView(indexSelector.addBtn, { offsetX: -1, offsetY: -1 });
    //Assertion
    await t
      .expect(indexSelector.dataTable.innerText)
      .contains("2,05")
      .expect(indexSelector.dataTable.innerText)
      .contains("9999,99")
      .expect(indexSelector.dataTable.innerText)
      .contains("20.10.2021")
      .click(detailDunningSelector.backBtn)
      .wait(3000);
    //Delete data
    await manageDunningTC1.filterDunning(manageDunningTC1.codeValue);
    await manageDunningTC1.deleteDunning();
  }
);

test.meta({ type: "base" })(
  "Check create Dunning level currency successfully when edit Dunning level",
  async (t) => {
    const manageDunningTC1a = new ManageDunningLevel();
    //Create Create Dunning levels
    await manageDunningTC1a.createDunningLevels();
    await t.click(detailDunningSelector.saveCloseBtn);
    //Open detail view Dunning level
    await manageDunningTC1a.filterDunning(manageDunningTC1a.codeValue);
    await t.click(indexDunningSelector.editBtn);
    await t.wait(2000);
    //Create exchange rate
    await createDunningCurrency.createDunningCurrency();
    await t.click(detailDunningSelector.saveCloseBtn);
    //Open detail view Dunning level
    await manageDunningTC1a.filterDunning(manageDunningTC1a.codeValue);
    await t.click(indexDunningSelector.editBtn);
    //Assertion
    await t
      .expect(indexSelector.dataTable.innerText)
      .contains("2,05")
      .expect(indexSelector.dataTable.innerText)
      .contains("9999,99")
      .expect(indexSelector.dataTable.innerText)
      .contains("20.10.2021")
      .click(detailDunningSelector.backBtn)
      .wait(3000);
    //Delete data
    await manageDunningTC1a.filterDunning(manageDunningTC1a.codeValue);
    await manageDunningTC1a.deleteDunning();
  }
);

test.meta({ type: "base" })(
  "Check create more Dunning level currency successfully when Edit Dunning level",
  async (t) => {
    const manageDunningTC1b = new ManageDunningLevel();
    //Create Create Dunning levels
    await manageDunningTC1b.createDunningLevels();
    //Create Dunning currency
    await createDunningCurrency.createDunningCurrency();
    await t.click(detailDunningSelector.saveCloseBtn);
    //Open detail view Dunning level
    await manageDunningTC1b.filterDunning(manageDunningTC1b.codeValue);
    await t.click(indexDunningSelector.editBtn);
    await t.wait(2000);
    await t.scrollIntoView(indexSelector.addBtn, { offsetX: -1, offsetY: -1 });
    //Create more Dunning currency
    await createDunningCurrency.createDunningCurrencyConfig("21.10.2021");
    await createDunningCurrency.createDunningCurrencyConfig("22.10.2021");
    await createDunningCurrency.createDunningCurrencyConfig("23.10.2021");
    await t.click(detailDunningSelector.saveCloseBtn);
    //Open detail view Dunning level
    await manageDunningTC1b.filterDunning(manageDunningTC1b.codeValue);
    await t.click(indexDunningSelector.editBtn);
    await t.scrollIntoView(indexSelector.addBtn, { offsetX: -1, offsetY: -1 });
    //Assertion
    await t
      .expect(indexSelector.dataTable.innerText)
      .contains("2,05")
      .expect(indexSelector.dataTable.innerText)
      .contains("9999,99")
      .expect(indexSelector.dataTable.innerText)
      .contains("20.10.2021")
      .click(detailDunningSelector.backBtn)
      .wait(3000);
    //Delete data
    await manageDunningTC1b.filterDunning(manageDunningTC1b.codeValue);
    await manageDunningTC1b.deleteDunning();
  }
);

test.meta({ type: "base" })(
  "Check create Dunning level currency unsuccessfully when duplicate date",
  async (t) => {
    const manageDunningTC2 = new ManageDunningLevel();
    //Create Create Dunning levels
    await manageDunningTC2.createDunningLevels();
    //Create first Dunning level currency
    await createDunningCurrency.createDunningCurrency();
    //Create second Dunning level currency
    await createDunningCurrency.createDunningCurrency();
    //Assertion
    await t
      .expect(
        Selector("i").withAttribute(
          "style",
          "text-align:center; word-wrap:unset"
        ).innerText
      )
      .contains("Dieser Wechselkurs hat bereits existiert")
      .click(Selector("#btn-close-alert"))
      .click(detailSelector.cancelBtn);
    await t.click(detailDunningSelector.saveCloseBtn);
    //Delete data
    await manageDunningTC2.filterDunning(manageDunningTC2.codeValue);
    await manageDunningTC2.deleteDunning();
  }
);

test.meta({ type: "base" })(
  "Check Edit Dunning level currency successfully",
  async (t) => {
    const manageDunningTC3 = new ManageDunningLevel();
    //Create Create Dunning levels
    await manageDunningTC3.createDunningLevels();
    //Create exchange rate
    await createDunningCurrency.createDunningCurrency();
    await t.click(detailDunningSelector.saveCloseBtn);
    //Open detail view Dunning level
    await manageDunningTC3.filterDunning(manageDunningTC3.codeValue);
    await t.click(indexDunningSelector.editBtn);
    await t.wait(2000);
    //Edit exchange rate
    await editDunningCurrency.editDunningCurrency();
    await t.click(detailDunningSelector.saveCloseBtn);
    //Open detail view Dunning level
    await manageDunningTC3.filterDunning(manageDunningTC3.codeValue);
    await t.click(indexDunningSelector.editBtn);
    //Assertion
    await t
      .expect(indexSelector.dataTable.innerText)
      .contains("10,05")
      .expect(indexSelector.dataTable.innerText)
      .contains("111,25")
      .expect(indexSelector.dataTable.innerText)
      .contains("10.10.2021")
      .click(detailDunningSelector.backBtn)
      .wait(3000);
    //Delete data
    await manageDunningTC3.filterDunning(manageDunningTC3.codeValue);
    await manageDunningTC3.deleteDunning();
  }
);

test.meta({ type: "base" })(
  "Check Delete Dunning level currency successfully",
  async (t) => {
    const manageDunningTC4 = new ManageDunningLevel();
    //Create Create Dunning levels
    await manageDunningTC4.createDunningLevels();
    //Create Dunning level currency
    await createDunningCurrency.createDunningCurrency();
    await t.click(detailDunningSelector.saveCloseBtn);
    //Open detail view Dunning level
    await manageDunningTC4.filterDunning(manageDunningTC4.codeValue);
    await t.click(indexDunningSelector.editBtn);
    await t.wait(2000);
    //delete Dunning level currency
    await t
      .click(indexSelector.deleteBtn)
      .click(indexSelector.yesConfirmDeleteBtn);
    //Assertion
    await t
      .expect(indexSelector.dataTable.innerText)
      .contains("Keine Daten zum Anzeigen")
      .click(detailDunningSelector.backBtn)
      .wait(3000);
    //Delete data
    await manageDunningTC4.filterDunning(manageDunningTC4.codeValue);
    await manageDunningTC4.deleteDunning();
  }
);

test.meta({ type: "base" })(
  "Check cancel Delete Dunning level currency successfully",
  async (t) => {
    const manageDunningTC5 = new ManageDunningLevel();
    //Create Create Dunning levels
    await manageDunningTC5.createDunningLevels();
    //Create Dunning level currency
    await createDunningCurrency.createDunningCurrency();
    await t.click(detailDunningSelector.saveCloseBtn);
    //Open detail view Dunning level
    await manageDunningTC5.filterDunning(manageDunningTC5.codeValue);
    await t.click(indexDunningSelector.editBtn);
    await t.wait(2000);
    //Cancel delete Dunning level currency
    await t
      .click(indexSelector.deleteBtn)
      .click(indexSelector.cancelConfirmDeleteBtn);
    //Assertion
    await t
      .expect(indexSelector.dataTable.innerText)
      .contains("2,05")
      .expect(indexSelector.dataTable.innerText)
      .contains("9999,99")
      .expect(indexSelector.dataTable.innerText)
      .contains("20.10.2021")
      .click(detailDunningSelector.backBtn)
      .wait(3000);
    //Delete data
    await manageDunningTC5.filterDunning(manageDunningTC5.codeValue);
    await manageDunningTC5.deleteDunning();
  }
);
