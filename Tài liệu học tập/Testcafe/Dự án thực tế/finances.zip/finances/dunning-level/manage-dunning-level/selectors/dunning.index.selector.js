import { Selector } from "testcafe";

export default class DunningIndexSelector {
    constructor() {
        //Menu bar
        this.financeMenu = Selector('a').withText("Finanzen")
        this.dunningLevelsMenu = Selector('a').withText("Mahnstufen")

        //List view
        this.addBtn = Selector('#btn-addNew');
        this.filterBox = Selector("td:nth-of-type(1) > .dxbs-edit-clbv.dxbs-textbox  .dxbs-editor-input-container> input")
        this.editBtn = Selector('#btn-edit > i');
        this.deleteBtn = Selector('#btn-delete');
        this.confirmDeleteBtn = Selector('#btn-confirm-yes');
        this.cancelDeleteBtn = Selector('#btn-confirm-no');
        this.dunningTable = Selector('div').withAttribute('class', 'dxbs-scroll-viewer-content')
        this.clearFilterBtn = Selector('button[class ="btn btn-sm dx-btn dxbs-edit-btn dxbs-clear-btn"]')

    }
};