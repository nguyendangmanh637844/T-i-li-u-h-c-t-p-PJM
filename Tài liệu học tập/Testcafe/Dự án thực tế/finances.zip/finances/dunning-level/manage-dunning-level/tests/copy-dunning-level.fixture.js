﻿import { Selector, t } from "testcafe";
import Configuration from "../../../../../commons/configuration";
import LoginPage from "../../../../authentication/functions/login-page";
import DunningIndexSelector from "../selectors/dunning.index.selector";
import DunningDetailSelector from "../selectors/dunning.detail.selector";
import ManageDunningLevel from "../functions/manage-dunning-level"

const config = new Configuration();
const login = new LoginPage();
const detailsSelector = new DunningDetailSelector();
const indexSelector = new DunningIndexSelector();

fixture`Finance - Dunning level: Copy dunning`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach();
        await login.login(config.UserName, config.Password);
        await t.click(indexSelector.financeMenu)
        await t.click(indexSelector.dunningLevelsMenu);
    })

test.meta({ type: 'basis' })
    ('#36334: Check Copy dunning when use Save and Close button', async t => {
        const manageDunningTC1 = new ManageDunningLevel()
        const codeCopy = manageDunningTC1.codeValue + ' - Kopieren';

        //Create dunning level
        await manageDunningTC1.createDunningLevels()
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy Dunning
        await manageDunningTC1.filterDunning(manageDunningTC1.codeValue)
        await manageDunningTC1.copyDunningLevels()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await manageDunningTC1.filterDunning(manageDunningTC1.codeValue)
        await t
            .expect(indexSelector.dunningTable.innerText).contains(codeCopy)
            .expect(indexSelector.dunningTable.innerText).contains(manageDunningTC1.codeValue)
            .expect(indexSelector.dunningTable.innerText).contains(manageDunningTC1.nameValue);
        //Delete dunning level
        await manageDunningTC1.deleteDunning()
        await manageDunningTC1.deleteDunning()
        await manageDunningTC1.filterDunning(manageDunningTC1.codeValue)
        await t.expect(indexSelector.dunningTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'basis' })
    ('#36334: Check Copy dunning when use Save and New button', async t => {
        const manageDunningTC2 = new ManageDunningLevel()
        const codeCopy = manageDunningTC2.codeValue + ' - Kopieren';
        //Create dunning level
        await manageDunningTC2.createDunningLevels()
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy Dunning
        await manageDunningTC2.filterDunning(manageDunningTC2.codeValue)
        await manageDunningTC2.copyDunningLevels()
        await t
            .click(detailsSelector.saveDropDownBtn)
            .click(detailsSelector.saveNewBtn)
            .click(detailsSelector.backBtn)
            .click(detailsSelector.backBtn)
        //Assert 
        await manageDunningTC2.filterDunning(manageDunningTC2.codeValue)
        await t
            .expect(indexSelector.dunningTable.innerText).contains(codeCopy)
            .expect(indexSelector.dunningTable.innerText).contains(manageDunningTC2.codeValue)
            .expect(indexSelector.dunningTable.innerText).contains(manageDunningTC2.nameValue);
        //Delete dunning level
        await manageDunningTC2.deleteDunning()
        await manageDunningTC2.deleteDunning()
        await manageDunningTC2.filterDunning(manageDunningTC2.codeValue)
        await t.expect(indexSelector.dunningTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'basis' })
    ('#36334: Check Copy dunning when Code field is value = 51 character', async t => {
        const manageDunningTC3 = new ManageDunningLevel()

        //Create dunning level
        await manageDunningTC3.createDunningconfig(manageDunningTC3.code50Value, '30 net')
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy Dunning
        await manageDunningTC3.filterDunning(manageDunningTC3.code50Value)
        await manageDunningTC3.copyDunningLevels()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 50 Zeichen')
            .click(detailsSelector.backBtn);
        //Delete dunning level
        await manageDunningTC3.filterDunning(manageDunningTC3.code50Value)
        await manageDunningTC3.deleteDunning()
        await t.expect(indexSelector.dunningTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'basis' })
    ('#36334: Check Copy dunning unsuccessful when code is  duplicated', async t => {
        const manageDunningTC4a = new ManageDunningLevel()
        const manageDunningTC4b = new ManageDunningLevel()
        const codeCopy = manageDunningTC4a.codeValue + ' - Kopieren';

        //Create first dunning level
        await manageDunningTC4a.createDunningLevels()
        await t.click(detailsSelector.saveCloseBtn)
        //Create 2nd dunning level
        await manageDunningTC4b.createDunningLevels()
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy Dunning
        await manageDunningTC4a.filterDunning(manageDunningTC4a.codeValue)
        await manageDunningTC4a.copyDunningLevels()
        await t.click(detailsSelector.saveCloseBtn)
        //Coppy duplicate Dunning
        await manageDunningTC4b.filterDunning(manageDunningTC4b.codeValue)
        await manageDunningTC4b.editDunningConfig(codeCopy,'Khoict')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Dieses Kurzzeichen hat bereits existiert')
            .click(detailsSelector.closeErrorMessage)
        //Back to dunning level list
        await t.click(detailsSelector.backBtn)
        //Delete dunning level
        await manageDunningTC4a.filterDunning(codeCopy)
        await manageDunningTC4a.deleteDunning()
        await t.expect(indexSelector.dunningTable.innerText).contains('Keine Daten zum Anzeigen')
    })