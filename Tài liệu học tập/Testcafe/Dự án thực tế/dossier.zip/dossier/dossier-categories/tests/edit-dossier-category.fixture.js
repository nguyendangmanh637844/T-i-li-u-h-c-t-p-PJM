﻿import { Selector, t } from "testcafe"
import Configuration from "../../../../commons/configuration"
import LoginPage from "../../../authentication/functions/login-page"
import ActionsSelector from "../../../../commons/actions-selector"
import MessageSelector from "../../../../commons/messages-selector"
import CommonFunction from "../../../../commons/common-function"

import DossierCategorySelector from "../selectors/dossier-category.selector"
import ManageDossierCategory from "../functions/manage-dossier-category"

const config = new Configuration()
const login = new LoginPage()
const action = new ActionsSelector()
const message = new MessageSelector()
const func = new CommonFunction()

const selector = new DossierCategorySelector()
const dossierCat = new ManageDossierCategory()

fixture`Dossier - Dossier Categoy: Edit`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(selector.dossierMenu)
        await t.click(selector.dossierCategoryMenu)
    })

test.meta({ type: 'base' })
    /*Scenario #43153: Edit Basic Category
       - Open Edit Basic Category form
       - Input valid value in all fields
       - Click on Save button
       - Verify value 
       */
    ('#43153: Edit Basic Category ', async t => {
        const create1 = new ManageDossierCategory()
        const edit1 = new ManageDossierCategory()
        const basicCategory1 = Selector('span').withText(create1.nameValue)
        const editBasicCategory1 = Selector('span').withText(edit1.nameValue)

        //Create Basic Category
        await dossierCat.createBasicCategory(create1.codeValue, create1.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory1.exists).ok()
        //Edit
        await t.click(basicCategory1)
        await dossierCat.editBasicCategory(edit1.codeValue, edit1.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(editBasicCategory1.exists).ok()
        //Delete Dossier Category
        await t.click(editBasicCategory1)
        await func.deleteInDetail()
        // Assert
        await t.expect(editBasicCategory1.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43154: Edit basic ctegory with blank Code
       - Open Edit Basic Category form
       - Leave Code field blank
       - Click on Save button
       - Verify message
       */
    ('#43154: Edit basic ctegory with blank Code', async t => {
        const create2 = new ManageDossierCategory()
        const edit2 = new ManageDossierCategory()
        const basicCategory2 = Selector('span').withText(create2.nameValue)
        const editBasicCategory2 = Selector('span').withText(edit2.nameValue)

        //Create basic category
        await dossierCat.createBasicCategory(create2.codeValue, create2.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory2.exists).ok()
        //Edit
        await t.click(basicCategory2)
        await dossierCat.editBasicCategory(' ', edit2.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.fieldRequired_DE)
        //Delete Dossier Category
        await t.click(editBasicCategory2)
        await func.deleteInDetail()
        //Assert
        await t.expect(editBasicCategory2.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43155: Edit basic category with duplicate Code
      - Open Edit Basic Category form
      - Input value in fields
      - Click on Save button
      - Verify message
      */
    ('#43155: Edit basic category with duplicate Code', async t => {
        const create31 = new ManageDossierCategory()
        const create32 = new ManageDossierCategory()
        const edit31 = new ManageDossierCategory()

        const basicCategory31 = Selector('span').withText(create31.nameValue)
        const basicCategory32 = Selector('span').withText(create32.nameValue)
        const editBasicCategory31 = Selector('span').withText(edit31.nameValue)

        //Create the first basic category
        await dossierCat.createBasicCategory(create31.codeValue, create31.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory31.exists).ok()
        //Create the second
        await dossierCat.createBasicCategory(create32.codeValue, create32.nameValue)
        await t .click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory32.exists).ok()
        //Edit the first Basic Category
        await t.click(basicCategory31)
        await dossierCat.editBasicCategory(edit31.codeValue, edit31.nameValue)
        await t .click(action.saveOnlyBtn)
        //Edit the second Basic Category
        await t.click(basicCategory32)
        await dossierCat.editBasicCategory(edit31.codeValue, edit31.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t
            .expect(message.errorMessage.innerText).contains('Dieses Kurzzeichen existiert bereits')
            .click(message.closeErrorMessage)
        //Delete the first Basic Category
        await t.click(editBasicCategory31)
        await func.deleteInDetail()
       // await t.expect(editBasicCategory31.exists).notOk()
         //Delete the second Basic Category
        await t.click(editBasicCategory31)
        await func.deleteInDetail()
        await t.expect(editBasicCategory31.exists).notOk()
    })

test.meta({ type: 'advance' })
/*Scenario #43156: Edit basic category with Code more than 50 characters
  - Open Edit Basic Category form
  - Input value in fields
  - Click on Save button
  - Verify message
  */

    ('#43156: Create basic category with Code more than 50 characters', async t => {
        const create4 = new ManageDossierCategory()
        const edit4 = new ManageDossierCategory()
        const basicCategory4 = Selector('span').withText(create4.nameValue)
        const editBasicCategory4 = Selector('span').withText(edit4.nameValue)
        //Create basic category
        await dossierCat.createBasicCategory(create4.codeValue, create4.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert
        await t.expect(basicCategory4.exists).ok()
        //Edit Dossier Category
        await t.click(basicCategory4)
        await dossierCat.editBasicCategory('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', edit4.nameValue)
        await t .click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.max50Characters_DE)
        //Delete Dossier Category
        await t.click(editBasicCategory4)
        await func.deleteInDetail()
        //Assert 
        await t.expect(editBasicCategory4.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43157: Edit basic category with blank Name
      - Open edit Basic Category form
      - Leave Name field blank
      - Click on Save button
      - Verify message
      */
 
    ('#43157: Edit basic category with blank Name', async t => {
        const create5 = new ManageDossierCategory()
        const edit5 = new ManageDossierCategory()
        const basicCategory5 = Selector('span').withText(create5.nameValue)
        const editBasicCategory5 = Selector('span').withText(edit5.codeValue)
        //Create basic category
        await dossierCat.createBasicCategory(create5.codeValue, create5.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory5.exists).ok()
        //Edit Dossier Category
        await t.click(basicCategory5)
        await dossierCat.editBasicCategory(edit5.codeValue, ' ')
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.fieldRequired_DE)
        //Delete Dossier Category
        await t.click(editBasicCategory5)
        await func.deleteInDetail()
        await t.expect(editBasicCategory5.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43158: Edit basic category with Name more than 254 characters
      - Open Edit Basic Category form
      - Input value in fields
      - Click on Save button
      - Verify message
      */
    ('#43158: Edit basic category with Name more than 254 characters', async t => {
        const create6 = new ManageDossierCategory()
        const edit6 = new ManageDossierCategory()
        const basicCategory6 = Selector('span').withText(create6.nameValue)
        const editBasicCategory6 = Selector('span').withText(edit6.codeValue)

        //Create basic category
        await dossierCat.createBasicCategory(create6.codeValue, create6.nameValue)
        await t .click(action.saveOnlyBtn)
        //Assert
        await t.expect(basicCategory6.exists).ok()
        //Edit Dossier Category
        await t.click(basicCategory6)
        await dossierCat.editBasicCategory(edit6.codeValue, 'Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text')
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.max254Characters_DE)
        //Delete Dossier Category
        await t.click(editBasicCategory6)
        await func.deleteInDetail()
        //Assert 
        await t.expect(editBasicCategory6.exists).notOk()
    })

test.meta({ type: 'base' })
    /*Scenario #43169: Edit Category 
       - Open Edit Category form
       - Input valid value in all fields
       - Click on Save button
       - Verify value 
       */
    ('#43169: Edit Category ', async t => {
        const create71 = new ManageDossierCategory()
        const create72 = new ManageDossierCategory()
        const edit72 = new ManageDossierCategory()
        const basicCategory71 = Selector('span').withText(create71.nameValue)
        const category72 = Selector('span').withText(create72.nameValue)
        const editCategory72 = Selector('span').withText(edit72.nameValue)

        //Create Basic Category
        await dossierCat.createBasicCategory(create71.codeValue, create71.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory71.exists).ok()
        //Create category inside
        await t.click(basicCategory71)
        await dossierCat.createCategory(create72.codeValue, create72.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(category72.exists).ok()
        //Edit  
        await t.click(category72)
        await dossierCat.editCategory(edit72.codeValue, edit72.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(editCategory72.exists).ok()
         //Delete category
        await t.click(editCategory72)
        await func.deleteInDetail()
        //Assert 
        await t.expect(editCategory72.exists).notOk()
        //Delete category
        await t.click(basicCategory71)
        await func.deleteInDetail()
        await t.expect(basicCategory71.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43170: Edit ctegory with blank Code
       - Open Edit Category form
       - Leave Code field blank
       - Click on Save button
       - Verify message
       */
    ('#43170: Create ctegory with blank Code', async t => {
        const create81 = new ManageDossierCategory()
        const create82 = new ManageDossierCategory()
        const edit82 = new ManageDossierCategory()

        const basicCategory81 = Selector('span').withText(create81.nameValue)
        const category82 = Selector('span').withText(create82.nameValue)
        const editCategory82 = Selector('span').withText(edit82.nameValue)

        //Create basic category
        await dossierCat.createBasicCategory(create81.codeValue, create81.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory81.exists).ok()
        //Create category
        await t.click(basicCategory81)
        await dossierCat.createCategory(create82.codeValue, create82.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(category82.exists).ok()
        //Edit category
        await t.click(category82)
        await dossierCat.editCategory(' ', edit82.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.codeFieldRequired_DE)
        //Delete category
        await t.click(editCategory82)
        await func.deleteInDetail()
        //Assert 
        await t.expect(category82.exists).notOk()
        //Delete basic category
        await t.click(basicCategory81)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory81.exists).notOk()

    })

test.meta({ type: 'advance' })
    /*Scenario #43171: Edit category with duplicate Code
      - Open Edit Category form
      - Input value in fields
      - Click on Save button
      - Verify message
      */
   
    ('#43171: Edit category with duplicate Code', async t => {
        const create91 = new ManageDossierCategory()
        const create92 = new ManageDossierCategory()
        const create93 = new ManageDossierCategory()
        const edit91 = new ManageDossierCategory()

        const basicCategory91 = Selector('span').withText(create91.nameValue)
        const category92 = Selector('span').withText(create92.nameValue)
        const category93 = Selector('span').withText(create93.nameValue)
        const editCategory91 = Selector('span').withText(edit91.nameValue)
        
        //Create basic Category
        await dossierCat.createBasicCategory(create91.codeValue, create91.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory91.exists).ok()
        //Create the first category
        await t.click(basicCategory91)
        await dossierCat.createCategory(create92.codeValue, create92.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.wait(2000)
        //Create the second Dossier Category
        await t.click(basicCategory91)
        await dossierCat.createCategory(create93.codeValue, create93.nameValue)
        await t.click(action.saveOnlyBtn)
        //Edit the first category
        await t.click(category92)
        await dossierCat.editCategory(edit91.codeValue, edit91.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.wait(2000)
        //Assert 
        await t.expect(editCategory91.exists).ok()
        //Edit the second category
        await t.click(category93)
        await dossierCat.editCategory(edit91.codeValue, edit91.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t
            .expect(message.errorMessage.innerText).contains('Dieses Kurzzeichen existiert bereits')
            .click(message.closeErrorMessage)
        //Delete the second category
        await t.click(editCategory91)
        await func.deleteInDetail()
        await t.click(editCategory91)
        await func.deleteInDetail()
        //Assert 
        await t.expect(editCategory91.exists).notOk()
        //Delete basic category
        await t.doubleClick(basicCategory91)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory91.exists).notOk()
    })

test.meta({ type: 'advance' })
/*Scenario #43172: Edit category with Code more than 50 characters
  - Open Edit Category form
  - Input value in fields
  - Click on Save button
  - Verify message
  */
    ('#43172: Edit category with Code more than 50 characters', async t => {
        const create101 = new ManageDossierCategory()
        const create102 = new ManageDossierCategory()
        const edit10 = new ManageDossierCategory()

        const basicCategory101 = Selector('span').withText(create101.nameValue)
        const category102 = Selector('span').withText(create102.nameValue)
        const editCategory102 = Selector('span').withText(edit10.nameValue)

        //Create basic Category
        await dossierCat.createBasicCategory(create101.codeValue, create101.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory101.exists).ok()
        //Create category
        await t.click(basicCategory101)
        await dossierCat.createCategory(create102.codeValue, create102.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(category102.exists).ok()
        //Edit category
        await dossierCat.editCategory('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', edit10.nameValue)
        await t .click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.codeMaxLength_DE)
        //Delete category
        await t.click(editCategory102)
        await func.deleteInDetail()
        //Assert 
        await t.expect(category102.exists).notOk()
        //Delete basic category
        await t.click(basicCategory101)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory101.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43173: Edit category with blank Name
      - Open Edit Category form
      - Leave Name field blank
      - Click on Save button
      - Verify message
      */
    ('#43173: Edit category with blank Name', async t => {
        const create11_1 = new ManageDossierCategory()
        const create11_2 = new ManageDossierCategory()
        const edit11 = new ManageDossierCategory()

        const basicCategory11_1 = Selector('span').withText(create11_1.nameValue)
        const category11_2 = Selector('span').withText(create11_2.nameValue)
        const editCategory11_2 = Selector('span').withText(edit11.codeValue)

        //Create basic Category
        await dossierCat.createBasicCategory(create11_1.codeValue, create11_1.nameValue)
        await t .click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory11_1.exists).ok()
        //Create category
        await t.click(basicCategory11_1)
        await dossierCat.createCategory(create11_2.codeValue, create11_2.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(category11_2.exists).ok()
        //Edit Dossier Category
        await t.click(category11_2)
        await dossierCat.editCategory(edit11.codeValue, ' ')
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.nameFieldRequired_DE)
        //Delete category
        await t.click(editCategory11_2)
        await func.deleteInDetail()
        //Assert 
        await t.expect(editCategory11_2.exists).notOk()
        //Delete basic category
        await t.click(basicCategory11_1)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory11_1.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43174: Edit category with Name more than 254 characters
      - Open Edit Category form
      - Input value in fields
      - Click on Save button
      - Verify message
      */
    ('#43174: Edit category with Name more than 254 characters', async t => {
        const create12_1 = new ManageDossierCategory()
        const create12_2 = new ManageDossierCategory()
        const edit12 = new ManageDossierCategory()

        const basicCategory12_1 = Selector('span').withText(create12_1.nameValue)
        const category12_2 = Selector('span').withText(create12_2.nameValue)
        const editCategory12_2 = Selector('span').withText(edit12.codeValue)

        //Create basic Category
        await dossierCat.createBasicCategory(create12_1.codeValue, create12_1.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory12_1.exists).ok()
        //Create category
        await t.click(basicCategory12_1)
        await dossierCat.createCategory(create12_2.codeValue, create12_2.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(category12_2.exists).ok()
        //Edit Dossier Category
        await t.click(category12_2)
        await dossierCat.editCategory(edit12.codeValue, 'Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text')
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.nameMaxLength_DE)
        //Delete category
        await t.click(editCategory12_2)
        await func.deleteInDetail()
        //Assert 
        await t.expect(editCategory12_2.exists).notOk()
        //Delete basic category
        await t.click(basicCategory12_1)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory12_1.exists).notOk()
    })