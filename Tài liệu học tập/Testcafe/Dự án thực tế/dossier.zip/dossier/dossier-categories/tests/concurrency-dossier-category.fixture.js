﻿import { Selector, t } from "testcafe"
import Configuration from "../../../../commons/configuration"
import LoginPage from "../../../authentication/functions/login-page"
import ActionsSelector from "../../../../commons/actions-selector"
import MessageSelector from "../../../../commons/messages-selector"
import CommonFunction from "../../../../commons/common-function"

import DossierCategorySelector from "../selectors/dossier-category.selector"
import ManageDossierCategory from "../functions/manage-dossier-category"

const config = new Configuration()
const login = new LoginPage()
const action = new ActionsSelector()
const message = new MessageSelector()
const func = new CommonFunction()

const selector = new DossierCategorySelector()
const dossierCat = new ManageDossierCategory()

fixture`Dossier - Dossier Categoy: Concurrency`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(selector.dossierMenu)
        await t.click(selector.dossierCategoryMenu)
    })

test.meta({ type: 'base' })
    /*Scenario: #42324/42336: Check concurrency when users edit basic category with Override option'
      - Open browser, login with user 1, edit a basic category
      - Open new browser, login with user 2, edit the same basic category with user 1, click Save
      - Back to user 1, click Save
      - Click Override
       */
    ('#42324/42336: Check concurrency when users edit basic category with Override option', async t => {
        const window1 = await t.getCurrentWindow()
        const window2 = await t.openWindow(config.UrlAdmin)
        const create1 = new ManageDossierCategory()
        const edit11 = new ManageDossierCategory()
        const edit12 = new ManageDossierCategory()

        const basicCategory1 = Selector('span').withText(create1.nameValue)
        const editBasicCategory11 = Selector('span').withText(edit11.codeValue)
        const editBasicCategory12 = Selector('span').withText(edit12.codeValue)

        //Create basic category at window 1
        await t.switchToWindow(window1)
        await dossierCat.createBasicCategory(create1.codeValue, create1.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory1.exists).ok()
        // Edit basic category at window 1
        await t.click(basicCategory1)
        await dossierCat.editBasicCategory(edit11.codeValue, edit11.nameValue)
        //Edit basic category at window 2
        await t.switchToWindow(window2)
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(selector.dossierMenu)
        await t.click(selector.dossierCategoryMenu)
        await t.click(basicCategory1)
        await dossierCat.editBasicCategory(edit12.codeValue, edit12.nameValue)
        await t.click(action.saveOnlyBtn)
        //switch to window 1
        await t.switchToWindow(window1)
        await t.click(action.saveOnlyBtn)
        await t.wait(3000)
        //Assert message
        await t.expect(message.errorMessage.innerText).contains(message.dataConflict_DE)
        //Assert informantion
        await t.expect(message.errorMessage.innerText).contains('Dossier-Kategorie')
        //await t.expect(selector.errorMessage.innerText).contains('Daten übersetzen')
        //Override information
        await t.click(action.overrideBtn)
        await t.wait(3000)
        //Assert
        await t.click(selector.definitionNode)
        //  await t.expect(editBasicCategory11.exists).ok()
        await t.click(editBasicCategory11)
        await t
            .expect(selector.codeBaseBox.value).contains(edit11.codeValue)
            .expect(selector.nameBaseBox.value).contains(edit11.nameValue)
        //Delete data
        await func.deleteInDetail()
        await t.expect(editBasicCategory11.exists).notOk()
    })
   
test.meta({ type: 'base' })
    /*Scenario: #42324/42337: Check concurrency when users edit basic category with Refresh option '
      - Open browser, login with user 1, edit a basic category
      - Open new browser, login with user 2, edit the same basic category with user 1, click Save
      - Back to user 1, click Save
      - Click Refresh
       */
    ('#42324/42337: Check concurrency when both users edit the same basic category with Refresh option', async t => {
        const window1 = await t.getCurrentWindow()
        const window2 = await t.openWindow(config.UrlAdmin)
        const create2 = new ManageDossierCategory()
        const edit21 = new ManageDossierCategory()
        const edit22 = new ManageDossierCategory()

        const basicCategory2 = Selector('span').withText(create2.nameValue)
        const editBasicCategory21 = Selector('span').withText(edit21.codeValue)
        const editBasicCategory22 = Selector('span').withText(edit22.codeValue)

        //Create basic category at window 1
        await t.switchToWindow(window1)
        await dossierCat.createBasicCategory(create2.codeValue, create2.nameValue)
        await t
           
            .click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory2.exists).ok()
        // Edit basic category at window 1
        await t.click(basicCategory2)
        await dossierCat.editBasicCategory(edit21.codeValue, edit21.nameValue)
        //Edit basic category at window 2
        await t.switchToWindow(window2)
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(selector.dossierMenu)
        await t.click(selector.dossierCategoryMenu)
        await t.click(basicCategory2)
        await dossierCat.editBasicCategory(edit22.codeValue, edit22.nameValue)
        await t .click(action.saveOnlyBtn)
        //switch to window 1
        await t.switchToWindow(window1)
        await t.click(action.saveOnlyBtn)
        await t.wait(3000)
        //Assert message
        await t.expect(message.errorMessage.innerText).contains(message.dataConflict_DE)
        //Assert informantion
        await t.expect(message.errorMessage.innerText).contains('Dossier-Kategorie')
        await t.click(action.refreshBtn)
        await t.wait(2000)
        //Assert  
        await t.click(selector.definitionNode)
        //  await t.expect(editBasicCategory11.exists).ok()
        await t.click(editBasicCategory22)
        await t.expect(selector.codeBaseBox.value).contains(edit22.codeValue)
        await t.expect(selector.nameBaseBox.value).contains(edit22.nameValue)
        //Delete data
        await t.click(editBasicCategory22)
        await func.deleteInDetail()
        await t.expect(editBasicCategory22.exists).notOk()
    })

test.meta({ type: 'base' })
    /*Scenario: #42324/42338: Check concurrency when users edit basic category with Cancel option'
      - Open browser, login with user 1, edit a basic category
      - Open new browser, login with user 2, edit the same basic category with user 1, click Save
      - Back to user 1, click Save
      - Click Cancel
       */
    ('#42324/42337: Check concurrency when both users edit the same basic category with Cancel option', async t => {
        const window1 = await t.getCurrentWindow()
        const window2 = await t.openWindow(config.UrlAdmin)
        const create3 = new ManageDossierCategory()
        const edit31 = new ManageDossierCategory()
        const edit32 = new ManageDossierCategory()

        const basicCategory3 = Selector('span').withText(create3.nameValue)
        const editBasicCategory31 = Selector('span').withText(edit31.codeValue)
        const editBasicCategory32 = Selector('span').withText(edit32.codeValue)

        //Create basic category at window 1
        await t.switchToWindow(window1)
        await dossierCat.createBasicCategory(create3.codeValue, create3.nameValue)
        await t.click(action.saveOnlyBtn)
        // Edit basic category at window 1
        await t.click(basicCategory3)
        await dossierCat.editBasicCategory(edit31.codeValue, edit31.nameValue)

        //Edit basic category at window 2
        await t.switchToWindow(window2)
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(selector.dossierMenu)
        await t.click(selector.dossierCategoryMenu)
        await t.click(basicCategory3)
        await dossierCat.editBasicCategory(edit32.codeValue, edit32.nameValue)
        await t.click(action.saveOnlyBtn)
        //switch to window 1
        await t.switchToWindow(window1)
        await t.click(action.saveOnlyBtn)
        await t.wait(3000)
        //Assert message
        await t.expect(message.errorMessage.innerText).contains(message.dataConflict_DE)
        //Assert information
        await t.expect(message.errorMessage.innerText).contains('Dossier-Kategorie')
        await t.click(action.cancel1Btn)
        await t.expect(selector.codeBaseBox.value).contains(edit31.codeValue)
        await t.expect(selector.nameBaseBox.value).contains(edit31.nameValue)
        //Assert
        await t.click(selector.definitionNode)
        await t.click(editBasicCategory31)
        await t
            .expect(selector.codeBaseBox.value).contains(edit31.codeValue)
            .expect(selector.nameBaseBox.value).contains(edit31.nameValue)
        //Delete data
        await t.click(editBasicCategory31)
        await func.deleteInDetail()
        await t.expect(editBasicCategory31.exists).notOk()
    })

test.meta({ type: 'base' })
    /*Scenario: #42332: Check concurrency when users delete the same basic category'
       - Open browser, login with user 1, delete a basic category
       - Open new browser, login with user 2, delete the same basic category with user 1, click Save
       - Back to user 1, click Save
        */
    ('#42332: Check concurrency when both users delete the same basic category', async t => {
        const window1 = await t.getCurrentWindow()
        const window2 = await t.openWindow(config.UrlAdmin)
        const create4 = new ManageDossierCategory()
        const basicCategory4 = Selector('span').withText(create4.nameValue)

        //Create basic category at window 1
        await t.switchToWindow(window1)
        await dossierCat.createBasicCategory(create4.codeValue, create4.nameValue)
        await t.click(action.saveOnlyBtn)
        // Delete basic category at window 1
        await t.click(basicCategory4)
        await t.click(action.deleteDetailBtn)
        //Delete basic category at window 2
        await t.switchToWindow(window2)
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(selector.dossierMenu)
        await t.click(selector.dossierCategoryMenu)
        await t.click(basicCategory4)
        await func.deleteInDetail()
        //switch to window 1
        await t.switchToWindow(window1)
        await t
            .click(action.confirmDeleteBtn)
            .wait(2000)
        //Assert
        await t.expect(basicCategory4.exists).notOk()    
    })

test.meta({ type: 'base' })
    /*Scenario:  #42326: Check concurrency when user 1 delete and user 2 edit the same basic category'
   - Open browser, login with user 1, delete a basic category
   - Open new browser, login with user 2, edit the same basic category with user 1
   - Back to user 1, click Save
   - Back to user 2, click Save
*/
    ('#42326: Check concurrency when user 1 delete and user 2 edit the same basic category', async t => {
        const window1 = await t.getCurrentWindow()
        const window2 = await t.openWindow(config.UrlAdmin)
        const create5 = new ManageDossierCategory()
        const edit52 = new ManageDossierCategory()
        const basicCategory5 = Selector('span').withText(create5.nameValue)

        //Create basic category at initial Window
        await t.switchToWindow(window1)
        await dossierCat.createBasicCategory(create5.codeValue, create5.nameValue)
        await t .click(action.saveOnlyBtn)
        //Open detail view at initial Window
        await t.click(basicCategory5)
        await t.click(action.deleteDetailBtn)
        //Open second browser
        await t.switchToWindow(window2)
        await t.maximizeWindow()
        await t.wait(2000)
        await login.login(config.UserName, config.Password)
        await t.click(selector.dossierMenu)
        await t.click(selector.dossierCategoryMenu)
        //Open detail view at second Window and edit that basic category
        await t.click(basicCategory5)
        await dossierCat.editBasicCategory(edit52.codeValue, edit52.nameValue)

        //Open the first window
        await t.switchToWindow(window1)
        await t
            .click(action.confirmDeleteBtn)
            .wait(2000)
        //Open second browser
        await t.switchToWindow(window2)
        await t.wait(2000)
        await t.click(action.saveOnlyBtn)
        //Assert
        await t.expect(message.errorMessage.innerText).contains(message.cannotSave)
        await t.click(message.closeErrorMessage)
        //Assert
        await t.expect(basicCategory5.exists).notOk()

    })