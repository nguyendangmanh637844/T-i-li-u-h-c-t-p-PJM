﻿import { Selector, t } from "testcafe"
import Configuration from "../../../../commons/configuration"
import LoginPage from "../../../authentication/functions/login-page"
import ActionsSelector from "../../../../commons/actions-selector"
import MessageSelector from "../../../../commons/messages-selector"
import CommonFunction from "../../../../commons/common-function"

import DossierCategorySelector from "../selectors/dossier-category.selector"
import ManageDossierCategory from "../functions/manage-dossier-category"

const config = new Configuration()
const login = new LoginPage()
const action = new ActionsSelector()
const message = new MessageSelector()
const func = new CommonFunction()

const selector = new DossierCategorySelector()
const dossierCat = new ManageDossierCategory()

fixture`Dossier - Dossier Categoy: Copy`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(selector.dossierMenu)
        await t.click(selector.dossierCategoryMenu)
    })

test.meta({ type: 'base' })
    /*Scenario #42983: Copy Basic Category
       - Open Copy Dossier Category form
       - Input valid value in all fields
       - Click on Save and Close button
       - Verify value 
       */
    ('#42983: Copy Basic Category ', async t => {
        const create1 = new ManageDossierCategory()
        const copy1 = new ManageDossierCategory()
        const basicCategory1 = Selector('span').withText(create1.codeValue)
        const copyBasicCategory1 = Selector('span').withText(copy1.codeValue)

        //Create Basic Category
        await dossierCat.createBasicCategory(create1.codeValue, create1.nameValue)
        await t.click(action.saveOnlyBtn)
        //copy
        await t.click(basicCategory1)
        await dossierCat.copyBasicCategory(copy1.codeValue, copy1.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(copyBasicCategory1.exists).ok()
        //Delete Copy Basic Category
        await t.click(copyBasicCategory1)
        await func.deleteInDetail()
        //Assert 
        await t.expect(copyBasicCategory1.exists).notOk()
        //Delete  Basic Category
        await t.click(basicCategory1)
        await func.deleteInDetail()
        //Assert 
        await t.expect(basicCategory1.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #42985: copy basic ctegory with blank Code
       - Open copy Dossier Category form
       - Leave Code field blank
       - Click on Save and Close button
       - Verify message
       */
    ('#42985: copy basic ctegory with blank Code', async t => {
        const create2 = new ManageDossierCategory()
        const copy2 = new ManageDossierCategory()
        const basicCategory2 = Selector('span').withText(create2.nameValue)
        const copyBasicCategory2 = Selector('span').withText(copy2.nameValue)

        //Create basic category
        await dossierCat.createBasicCategory(create2.codeValue, create2.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory2.exists).ok()
        //copy
        await t.click(basicCategory2)
        await dossierCat.copyBasicCategory(' ', copy2.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t
            .expect(message.vldMessage.innerText).contains(message.fieldRequired_DE)
        //Delete Dossier Category
        await t.click(copyBasicCategory2)
        await func.deleteInDetail()
        //Assert 
        await t.expect(copyBasicCategory2.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #42986: copy basic category with duplicate Code
      - Open copy Dossier Category form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#42986: copy basic category with duplicate Code', async t => {
        const create31 = new ManageDossierCategory()
        const create32 = new ManageDossierCategory()
        const copy31 = new ManageDossierCategory()

        const basicCategory31 = Selector('span').withText(create31.nameValue)
        const basicCategory32 = Selector('span').withText(create32.nameValue)
        const copyBasicCategory31 = Selector('span').withText(copy31.nameValue)

        //Create basic category
        await dossierCat.createBasicCategory(create31.codeValue, create31.nameValue)
        await t .click(action.saveOnlyBtn).wait(2000)
        await dossierCat.createBasicCategory(create32.codeValue, create32.nameValue)
        await t .click(action.saveOnlyBtn).wait(2000)
        //copy the first  Category
        await t.click(basicCategory31)
        await dossierCat.copyBasicCategory(copy31.codeValue, copy31.nameValue)
        await t.click(action.saveOnlyBtn).wait(2000)
        //copy the second Dossier Category
        await t.click(basicCategory32)
        await dossierCat.copyBasicCategory(copy31.codeValue, copy31.nameValue)
        await t.click(action.saveOnlyBtn).wait(2000)
            
        //Assert 
        await t
            .expect(message.errorMessage.innerText).contains('Dieses Kurzzeichen existiert bereits')
            .click(message.closeErrorMessage)
        //Delete the first Basic Category
        await t.click(copyBasicCategory31)
        await func.deleteInDetail()
        //Assert
      //  await t.expect(copyBasicCategory31.exists).notOk()
           //Delete the second Basic Category
        await t.click(basicCategory31)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory32.exists).ok()
    })

test.meta({ type: 'advance' })
    /*Scenario #42987: copy basic category with Code more than 50 characters
      - Open copy Dossier Category form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */

    ('#42987: Create basic category with Code more than 50 characters', async t => {
        const create4 = new ManageDossierCategory()
        const copy4 = new ManageDossierCategory()
        const basicCategory4 = Selector('span').withText(create4.nameValue)
        const copyBasicCategory4 = Selector('span').withText(copy4.nameValue)

        //Create basic category
        await dossierCat.createBasicCategory(create4.codeValue, create4.nameValue)
        await t.click(action.saveOnlyBtn)
        //copy Dossier Category
        await t.click(basicCategory4)
        await dossierCat.copyBasicCategory('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', copy4.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t
            .expect(message.vldMessage.innerText).contains(message.max50Characters_DE)
        //Delete Dossier Category
        await t.click(copyBasicCategory4)
        await func.deleteInDetail()
        //Assert 
        await t.expect(copyBasicCategory4.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #42988: copy basic category with blank Name
      - Open copy Dossier Category form
      - Leave Name field blank
      - Click on Save and Close button
      - Verify message
      */

    ('#42988: copy basic category with blank Name', async t => {
        const create5 = new ManageDossierCategory()
        const copy5 = new ManageDossierCategory()
        const basicCategory5 = Selector('span').withText(create5.nameValue)
        const copyBasicCategory5 = Selector('span').withText(copy5.codeValue)

        //Create basic category
        await dossierCat.createBasicCategory(create5.codeValue, create5.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory5.exists).ok()
        //copy Dossier Category
        await t.click(basicCategory5)
        await dossierCat.copyBasicCategory(copy5.codeValue, ' ')
        await t.click(action.saveOnlyBtn)      
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.fieldRequired_DE)
        //Delete Dossier Category
        await t.click(copyBasicCategory5)
        await func.deleteInDetail()
        await t.expect(copyBasicCategory5.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #42989: copy basic category with Name more than 254 characters
      - Open copy Dossier Category form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#42989: copy basic category with Name more than 254 characters', async t => {
        const create6 = new ManageDossierCategory()
        const copy6 = new ManageDossierCategory()
        const basicCategory6 = Selector('span').withText(create6.nameValue)
        const copyBasicCategory6 = Selector('span').withText(copy6.codeValue)

        //Create basic category
        await dossierCat.createBasicCategory(create6.codeValue, create6.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert
        await t.expect(basicCategory6.exists).ok()
        //copy Dossier Category
        await t.click(basicCategory6)
        await dossierCat.copyBasicCategory(copy6.codeValue, 'Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text')
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.max254Characters_DE)
        //Delete Dossier Category
        await t.click(copyBasicCategory6)
        await func.deleteInDetail()
        //Assert 
        await t.expect(copyBasicCategory6.exists).notOk()
    })

test.meta({ type: 'base' })
    /*Scenario #43003: copy Category
       - Open copy Dossier Category form
       - Input valid value in all fields
       - Click on Save and Close button
       - Verify value 
       */
    ('#43003: copy Category ', async t => {
        const create71 = new ManageDossierCategory()
        const create72 = new ManageDossierCategory()
        const copy7 = new ManageDossierCategory()

        const basicCategory71 = Selector('span').withText(create71.nameValue)
        const category72 = Selector('span').withText(create72.nameValue)
        const copyCategory7 = Selector('span').withText(copy7.nameValue)

        //Create Basic Category
        await dossierCat.createBasicCategory(create71.codeValue, create71.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(basicCategory71.exists).ok()
        //Create category inside
        await t.click(basicCategory71)
        await dossierCat.createCategory(create72.codeValue, create72.nameValue)
        await t .click(action.saveOnlyBtn)
        //Copy catagory
        await t.click(category72)
        await dossierCat.copyCategory(copy7.codeValue, copy7.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(copyCategory7.exists).ok()      
        //Delete category
        await t.click(copyCategory7)
        await func.deleteInDetail()
        //Assert 
        await t.expect(copyCategory7.exists).notOk()
        //Delete category
        await t.click(category72)
        await func.deleteInDetail()
        //Assert 
        await t.expect(category72.exists).notOk()
       //Delete basic category
        await t.click(basicCategory71)
        await func.deleteInDetail()
        //Assert 
        await t.expect(basicCategory71.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43004: copy ctegory with blank Code
       - Open copy Dossier Category form
       - Leave Code field blank
       - Click on Save and Close button
       - Verify message
       */
    ('#43004: Create ctegory with blank Code', async t => {
        const create81 = new ManageDossierCategory()
        const create82 = new ManageDossierCategory()
        const copy8 = new ManageDossierCategory()

        const basicCategory81 = Selector('span').withText(create81.nameValue)
        const category82 = Selector('span').withText(create82.nameValue)
        //Create basic category
        await dossierCat.createBasicCategory(create81.codeValue, create81.nameValue)
        await t .click(action.saveOnlyBtn)
        //Create category
        await t.click(basicCategory81)
        await dossierCat.createCategory(create82.codeValue, create82.nameValue)
        await t.click(action.saveOnlyBtn)
        //copy category
        await t.click(category82)
        await dossierCat.copyCategory(' ', copy8.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.codeFieldRequired_DE)
        //Delete category
        await t.click(category82)
        await func.deleteInDetail()
        //Assert 
        await t.expect(category82.exists).notOk()
        //Delete basic category
        await t.click(basicCategory81)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory81.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43005: copy category with duplicate Code
      - Open copy Dossier Category form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#43005: copy category with duplicate Code', async t => {
        const create91 = new ManageDossierCategory()
        const create92 = new ManageDossierCategory()
        const create93 = new ManageDossierCategory()
        const copy91 = new ManageDossierCategory()

        const basicCategory91 = Selector('span').withText(create91.nameValue)
        const category92 = Selector('span').withText(create92.nameValue)
        const category93 = Selector('span').withText(create93.nameValue)
        const copyCategory91 = Selector('span').withText(copy91.nameValue)

        //Create basic Category
        await dossierCat.createBasicCategory(create91.codeValue, create91.nameValue)
        await t.click(action.saveOnlyBtn)
        //Create the first category
        await t.click(basicCategory91)
        await dossierCat.createCategory(create92.codeValue, create92.nameValue)
        await t.click(action.saveOnlyBtn)
        //Create the second Dossier Category
        await t.click(basicCategory91)
        await dossierCat.createCategory(create93.codeValue, create93.nameValue)
        await t.click(action.saveOnlyBtn)
        //copy the first category
        await t.click(category92)
        await dossierCat.copyCategory(copy91.codeValue, copy91.nameValue)
        //copy the second category
        await t.click(category93)
        await dossierCat.copyCategory(copy91.codeValue, copy91.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t
            .expect(message.errorMessage.innerText).contains('Vor dem Verlassen dieses Elements bitte Änderungen speichern')
            .click(message.closeErrorMessage)
        //Delete copy category
        await t.click(copyCategory91)
        await func.deleteInDetail()
        //Assert
        await t.expect(copyCategory91.exists).notOk()
        //Delete category
        await t.click(category93)
        await func.deleteInDetail()
        //Assert
        await t.expect(category93.exists).notOk()
        //Delete basic category
        await t.click(basicCategory91)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory91.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43006: copy category with Code more than 50 characters
      - Open copy Dossier Category form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */

    ('#43006: copy category with Code more than 50 characters', async t => {
        const create101 = new ManageDossierCategory()
        const create102 = new ManageDossierCategory()
        const copy10 = new ManageDossierCategory()

        const basicCategory101 = Selector('span').withText(create101.nameValue)
        const category102 = Selector('span').withText(create102.nameValue)

        //Create basic Category
        await dossierCat.createBasicCategory(create101.codeValue, create101.nameValue)
        await t.click(action.saveOnlyBtn)
        //Create category
        await t.click(basicCategory101)
        await dossierCat.createCategory(create102.codeValue, create102.nameValue)
        await t.click(action.saveOnlyBtn)
        //copy category
        await t.click(category102)
        await dossierCat.copyCategory('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', copy10.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.codeMaxLength_DE)
        //Delete category
        await t.click(category102)
        await func.deleteInDetail()
        //Assert 
        await t.expect(category102.exists).notOk()
        //Delete basic category
        await t.click(basicCategory101)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory101.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43007: copy category with blank Name
      - Open copy Dossier Category form
      - Leave Name field blank
      - Click on Save and Close button
      - Verify message
      */

    ('#43007: copy category with blank Name', async t => {
        const create11_1 = new ManageDossierCategory()
        const create11_2 = new ManageDossierCategory()
        const copy11 = new ManageDossierCategory()

        const basicCategory11_1 = Selector('span').withText(create11_1.nameValue)
        const category11_2 = Selector('span').withText(create11_2.nameValue)

        //Create basic Category
        await dossierCat.createBasicCategory(create11_1.codeValue, create11_1.nameValue)
        await t.click(action.saveOnlyBtn)
        //Create category
        await t.click(basicCategory11_1)
        await dossierCat.createCategory(create11_2.codeValue, create11_2.nameValue)
        await t.click(action.saveOnlyBtn)
        //copy Dossier Category
        await t.click(category11_2)
        await dossierCat.copyCategory(copy11.codeValue, ' ')
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.nameFieldRequired_DE)
        //Delete category
        await t.click(category11_2)
                .click(action.alertConfirmBtn)
        await func.deleteInDetail()
        //Assert 
        await t.expect(category11_2.exists).ok()
        //Delete basic category
        await t.click(basicCategory11_1)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory11_1.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43008: copy category with Name more than 254 characters
      - Open copy Dossier Category form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#43008: copy category with Name more than 254 characters', async t => {
        const create12_1 = new ManageDossierCategory()
        const create12_2 = new ManageDossierCategory()
        const copy12 = new ManageDossierCategory()

        const basicCategory12_1 = Selector('span').withText(create12_1.nameValue)
        const category12_2 = Selector('span').withText(create12_2.nameValue)

        //Create basic Category
        await dossierCat.createBasicCategory(create12_1.codeValue, create12_1.nameValue)
        await t .click(action.saveOnlyBtn)
        //Create category
        await t.click(basicCategory12_1)
        await dossierCat.createCategory(create12_2.codeValue, create12_2.nameValue)
        await t .click(action.saveOnlyBtn)
        //copy Dossier Category
        await t.click(category12_2)
        await dossierCat.copyCategory(copy12.codeValue, 'Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text')
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.nameMaxLength_DE)
        //Delete category
        await t.click(category12_2)
                .click(action.alertConfirmBtn)
        await func.deleteInDetail()
        //Assert 
        await t.expect(category12_2.exists).ok()
        //Delete basic category
        await t.click(basicCategory12_1)
        await func.deleteInDetail()
        //Assert
        await t.expect(basicCategory12_1.exists).notOk()
    })