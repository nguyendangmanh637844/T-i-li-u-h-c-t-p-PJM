import { Selector, t } from "testcafe"
import Configuration from "../../../../commons/configuration"
import LoginPage from "../../../authentication/functions/login-page"
import ActionsSelector from "../../../../commons/actions-selector"
import MessageSelector from "../../../../commons/messages-selector"
import CommonFunction from "../../../../commons/common-function"
import DossierCategorySelector from "../selectors/dossier-category.selector"
import ManageDossierCategory from "../functions/manage-dossier-category"
import TranslateIndex from "../../../../commons/translate-selector"

const config = new Configuration()
const login = new LoginPage()
const action = new ActionsSelector()
const message = new MessageSelector()
const func = new CommonFunction()
const selector = new DossierCategorySelector()
const dossierCat = new ManageDossierCategory()
const language = new TranslateIndex()

fixture`Dossier - Dossier Categoy: Translate`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(selector.dossierMenu)
        await t.click(selector.dossierCategoryMenu)
    })

test.meta({ type: 'base' })
    /*Scenario #43326/43327: Check translate data after creating basic category
       - Create new Basic Catgory
       - Open Translate form
       - Change language
       - Verify data
       */
    ('#43326/43327: Check translate data after creating basic category', async t => {
        const create1 = new ManageDossierCategory()
        //Choose language
        await t.click(language.languageToggle)
        await t.click(language.languageDEDrop)

        //Create Basic Category
        await dossierCat.createBasicCategory(create1.codeValue, create1.nameValue)
        await t.typeText(selector.descriptionBaseBox, 'Test create Basic category')
        await t.click(action.saveOnlyBtn)
        //Open translate
        const basicCategory1 = Selector('span').withText(create1.nameValue)
        await t.click(basicCategory1)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains(create1.nameValue)
            .expect(selector.nameENBox.value).contains(create1.nameValue)
            .expect(selector.nameFRBox.value).contains(create1.nameValue)
            .expect(selector.descriptionDEBox.value).contains('Test create Basic category')
            .expect(selector.descriptionENBox.value).contains('Test create Basic category')
            .expect(selector.descriptionFRBox.value).contains('Test create Basic category')
            .click(action.cancelBtn)
        // Change language to English
        await t.click(language.languageToggle)
        await t.click(language.languageENDrop)
        await t.wait(15000)
        await t.click(basicCategory1)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains(create1.nameValue)
            .expect(selector.nameENBox.value).contains(create1.nameValue)
            .expect(selector.nameFRBox.value).contains(create1.nameValue)
            .expect(selector.descriptionDEBox.value).contains('Test create Basic category')
            .expect(selector.descriptionENBox.value).contains('Test create Basic category')
            .expect(selector.descriptionFRBox.value).contains('Test create Basic category')
            .click(action.cancelBtn)
        // Change language to French
        await t.click(language.languageToggle)
        await t.click(language.languageFRDrop)
        await t.wait(15000)
        await t.click(basicCategory1)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains(create1.nameValue)
            .expect(selector.nameENBox.value).contains(create1.nameValue)
            .expect(selector.nameFRBox.value).contains(create1.nameValue)
            .expect(selector.descriptionDEBox.value).contains('Test create Basic category')
            .expect(selector.descriptionENBox.value).contains('Test create Basic category')
            .expect(selector.descriptionFRBox.value).contains('Test create Basic category')
            .click(action.cancelBtn)
        //Delete basic category
        await t.click(basicCategory1)
        await func.deleteInDetail()
        await t.expect(basicCategory1.exists).notOk()
    })

test.meta({ type: 'base' })
    /*Scenario #43328/43329: Check translate data after inputting value in Translate form
       - Create Basic Catgory
       - Open Translate form
       - Input value
       - Change language
       - Verify data
       */
    
    ('#43328/43329: Check translate data after inputting value in Translate form', async t => {
        const create2 = new ManageDossierCategory()
        //Choose language
        await t.click(language.languageToggle)
        await t.click(language.languageDEDrop)

        //Open Create Basic Category
        await t.click(selector.definitionNode)
        await t.click(selector.addNewBtn)
        // Input data in translate form
        await dossierCat.translateBasicCategory()
        //Assert
        await t
            .expect(selector.nameBaseBox.value).contains('Basic Category DE')
            .expect(selector.descriptionBaseBox.value).contains('Test Basic Category DE')
        //Input value in code field
        await t.typeText(selector.codeBaseBox, create2.codeValue)
       
        await t.click(action.saveOnlyBtn)
        // Change language to English
        await t.click(language.languageToggle)
        await t.click(language.languageENDrop)
        await t.wait(15000)
        const basicCategory2 = Selector('span').withText(create2.codeValue)
        await t.click(basicCategory2)
        //Assert
        await t
            .expect(selector.nameBaseBox.value).contains('Basic Category EN')
            .expect(selector.descriptionBaseBox.value).contains('Test Basic Category EN')
        // Change language to French
        await t.click(language.languageToggle)
        await t.click(language.languageFRDrop)
        await t.wait(5000)
        await t.click(basicCategory2)
        //Assert
        await t
            .expect(selector.nameBaseBox.value).contains('Basic Category FR')
            .expect(selector.descriptionBaseBox.value).contains('Test Basic Category FR')
    })

test.meta({ type: 'base' })
    /*Scenario #43330/43331: Check translate data after updating basic category
       - Update Basic Catgory
       - Open Translate form
       - Change language
       - Verify data
       */
    ('#43326/43327: Check translate data after creating basic category', async t => {
        const create3 = new ManageDossierCategory()
        const edit3 = new ManageDossierCategory()
        //Choose DE language
        await t.click(language.languageToggle)
        await t.click(language.languageDEDrop)

        //Create Basic Category
        await dossierCat.createBasicCategory(create3.codeValue, create3.nameValue)
        await t.typeText(selector.descriptionBaseBox, 'Test create Basic category')
       
        await t.click(action.saveOnlyBtn)
        //Open translate
        const basicCategory3 = Selector('span').withText(create3.nameValue)
        await t.click(basicCategory3)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains(create3.nameValue)
            .expect(selector.nameENBox.value).contains(create3.nameValue)
            .expect(selector.nameFRBox.value).contains(create3.nameValue)
            .expect(selector.descriptionDEBox.value).contains('Test create Basic category')
            .expect(selector.descriptionENBox.value).contains('Test create Basic category')
            .expect(selector.descriptionFRBox.value).contains('Test create Basic category')
            .click(action.cancelBtn)
        //Update Basic Category
        await t.click(basicCategory3)
        await dossierCat.editBasicCategory(edit3.codeValue, 'Update basic category')
        await t
            .click(selector.descriptionBaseBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.descriptionBaseBox,'Test update basic category')
            .click(action.saveOnlyBtn)
        const editBasicCategory3 = Selector('span').withText(edit3.codeValue)
        await t.click(editBasicCategory3)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains('Update basic category')
            .expect(selector.nameENBox.value).contains(create3.nameValue)
            .expect(selector.nameFRBox.value).contains(create3.nameValue)
            .expect(selector.descriptionDEBox.value).contains('Test update basic category')
            .expect(selector.descriptionENBox.value).contains('Test create Basic category')
            .expect(selector.descriptionFRBox.value).contains('Test create Basic category')
            .click(action.cancelBtn)
                // Change language to English
        await t.click(language.languageToggle)
        await t.click(language.languageENDrop)
        await t.wait(5000)
        await t.click(editBasicCategory3)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains('Update basic category')
            .expect(selector.nameENBox.value).contains(create3.nameValue)
            .expect(selector.nameFRBox.value).contains(create3.nameValue)
            .expect(selector.descriptionDEBox.value).contains('Test update basic category')
            .expect(selector.descriptionENBox.value).contains('Test create Basic category')
            .expect(selector.descriptionFRBox.value).contains('Test create Basic category')
            .click(action.cancelBtn)
        // Change language to French
        await t.click(language.languageToggle)
        await t.click(language.languageFRDrop)
        await t.wait(15000)
        await t.click(editBasicCategory3)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains('Update basic category')
            .expect(selector.nameENBox.value).contains(create3.nameValue)
            .expect(selector.nameFRBox.value).contains(create3.nameValue)
            .expect(selector.descriptionDEBox.value).contains('Test update basic category')
            .expect(selector.descriptionENBox.value).contains('Test create Basic category')
            .expect(selector.descriptionFRBox.value).contains('Test create Basic category')
            .click(action.cancelBtn)
    })

test.meta({ type: 'base' })
    /*Scenario #43341/43342: Check translate data after creating category
       - Create Catgory
       - Open Translate form
       - Change language
       - Verify data
       */
    ('#43341/43342: Check translate data after creating category', async t => {
        const create41 = new ManageDossierCategory()
        const create42 = new ManageDossierCategory()

        //Choose language
        await t.click(language.languageToggle)
        await t.click(language.languageDEDrop)

        //Create Basic Category
        await dossierCat.createBasicCategory(create41.codeValue, create41.nameValue)
        await t.click(action.saveOnlyBtn)
        //Create category
        const basicCategory4 = Selector('span').withText(create41.nameValue)
        await t.click(basicCategory4)
        await dossierCat.createCategory(create42.codeValue, create42.nameValue)
        await t.click(action.saveOnlyBtn)
        //Open translate
        await t.wait(15000)
        await t.doubleClick(basicCategory4)
        const category4 = Selector('span').withText(create42.nameValue)
        await t.click(category4)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains(create42.nameValue)
            .expect(selector.nameENBox.value).contains(create42.nameValue)
            .expect(selector.nameFRBox.value).contains(create42.nameValue)
            .click(action.cancelBtn)

        // Change language to English
        await t.click(language.languageToggle)
        await t.click(language.languageENDrop)
        await t.wait(5000)
        await t.doubleClick(basicCategory4)
        await t.click(category4)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains(create42.nameValue)
            .expect(selector.nameENBox.value).contains(create42.nameValue)
            .expect(selector.nameFRBox.value).contains(create42.nameValue)
            .click(action.cancelBtn)
           
        // Change language to French
        await t.click(language.languageToggle)
        await t.click(language.languageFRDrop)
        await t.wait(15000)
        await t.doubleClick(basicCategory4)
        await t.click(category4)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains(create42.nameValue)
            .expect(selector.nameENBox.value).contains(create42.nameValue)
            .expect(selector.nameFRBox.value).contains(create42.nameValue)
            .click(action.cancelBtn)
    })

test.meta({ type: 'base' })
    /*Scenario #43343/43344: Check translate data after inputting value in Translate form
       - Create Catgory
       - Open Translate form
       - Input value
       - Change language
       - Verify data
       */
    ('#43343/43344: Check translate data after inputting value in Translate form', async t => {
        const create51 = new ManageDossierCategory()
        const create52 = new ManageDossierCategory()

        //Choose language
        await t.click(language.languageToggle)
        await t.click(language.languageDEDrop)

        //Create Basic Category
        await dossierCat.createBasicCategory(create51.codeValue, create51.nameValue)
        await t.click(action.saveOnlyBtn)
        //Open Create Category
        const basicCategory5 = Selector('span').withText(create51.nameValue)
        await t.click(basicCategory5)
        await t.click(selector.addNewBtn)
        // Input data in translate form
        await dossierCat.translateCategory()
        //Assert
        await t.expect(selector.nameBox.value).contains('Category DE')
        //Input value in code field
        await t.typeText(selector.codeBox, create52.codeValue)
        await t.click(action.saveOnlyBtn)
        // Change language to English
        await t.click(language.languageToggle)
        await t.click(language.languageENDrop)
        await t.wait(15000)
        await t.doubleClick(basicCategory5)
        const category5 = Selector('span').withText(create52.codeValue)
        await t.click(category5)
        //Assert
        await t .expect(selector.nameBox.value).contains('Category EN')       
        // Change language to French
        await t.click(language.languageToggle)
        await t.click(language.languageFRDrop)
        await t.wait(15000)
        await t.doubleClick(basicCategory5)
        await t.click(category5)
        //Assert
        await t.expect(selector.nameBox.value).contains('Category FR')       
    })

test.meta({ type: 'base' })
    /*Scenario #43345/43346: Check translate data after updating category
       - Update Catgory
       - Open Translate form
       - Change language
       - Verify data
       */
    ('#43345/43346: Check translate data after updating category', async t => {
        const create61 = new ManageDossierCategory()
        const create62 = new ManageDossierCategory()
        const edit6 = new ManageDossierCategory()

        //Choose DE language
        await t.click(language.languageToggle)
        await t.click(language.languageDEDrop)

        //Create Basic Category
        await dossierCat.createBasicCategory(create61.codeValue, create61.nameValue)
        await t.click(action.saveOnlyBtn)
        //Create category
        const basicCategory6 = Selector('span').withText(create61.nameValue)
        await t.click(basicCategory6)
        await dossierCat.createCategory(create62.codeValue, create62.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.wait(15000)
        //Open translate
        await t.doubleClick(basicCategory6)
        const category6 = Selector('span').withText(create62.nameValue)
        await t.click(category6)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains(create62.nameValue)
            .expect(selector.nameENBox.value).contains(create62.nameValue)
            .expect(selector.nameFRBox.value).contains(create62.nameValue)
            .click(action.cancelBtn)
        //Update Category
        await dossierCat.editCategory(edit6.codeValue, 'Update category')
        await t.click(action.saveOnlyBtn)
        //Open translate
        const editCategory6 = Selector('span').withText(edit6.codeValue)
        await t.click(editCategory6)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains('Update category')
            .expect(selector.nameENBox.value).contains(create62.nameValue)
            .expect(selector.nameFRBox.value).contains(create62.nameValue)
            .click(action.cancelBtn)
        // Change language to English
        await t.click(language.languageToggle)
        await t.click(language.languageENDrop)
        await t.wait(15000)
        await t
            .doubleClick(basicCategory6)
            .click(editCategory6)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains('Update category')
            .expect(selector.nameENBox.value).contains(create62.nameValue)
            .expect(selector.nameFRBox.value).contains(create62.nameValue)
            .click(action.cancelBtn)
         
        // Change language to French
        await t.click(language.languageToggle)
        await t.click(language.languageFRDrop)
        await t.wait(15000)
        await t
            .doubleClick(basicCategory6)
            .click(editCategory6)
        await t.click(action.translateBtn)
        //Assert
        await t
            .expect(selector.nameDEBox.value).contains('Update category')
            .expect(selector.nameENBox.value).contains(create62.nameValue)
            .expect(selector.nameFRBox.value).contains(create62.nameValue)
            .click(action.cancelBtn)    
    })
