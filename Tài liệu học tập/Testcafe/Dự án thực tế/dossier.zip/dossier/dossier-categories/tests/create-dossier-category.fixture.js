﻿import { Selector, t } from "testcafe"
import Configuration from "../../../../commons/configuration"
import LoginPage from "../../../authentication/functions/login-page"
import ActionsSelector from "../../../../commons/actions-selector"
import MessageSelector from "../../../../commons/messages-selector"
import CommonFunction from "../../../../commons/common-function"

import DossierCategorySelector from "../selectors/dossier-category.selector"
import ManageDossierCategory from "../functions/manage-dossier-category"

const config = new Configuration()
const login = new LoginPage()
const action = new ActionsSelector()
const message = new MessageSelector()
const func = new CommonFunction()

const selector = new DossierCategorySelector()
const dossierCat = new ManageDossierCategory()

fixture`Dossier - Dossier Categoy: Create`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(selector.dossierMenu)
        await t.click(selector.dossierCategoryMenu)
    })

test.meta({ type: 'base' })
    /*Scenario #43117: Create basic category 
       - Open Create Basic Category form
       - Input valid value in all fields
       - Click on Save button
       - Verify value 
       */
    ('#43117: Create basic category', async t => {
        const create1 = new ManageDossierCategory()
        const basiccategory1 = Selector('span').withText(create1.codeValue)

        //Create basic category
        await dossierCat.createBasicCategory(create1.codeValue, create1.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.wait(2000)
        //Assert 
        await t.expect(basiccategory1.exists).ok()
        await t.expect(selector.codeBaseBox.value).contains(create1.codeValue)
        await t.expect(selector.nameBaseBox.value).contains(create1.nameValue)
        //Delete Basic Category
        //  await t.click(basiccategory1)
        await t.wait(3000)
        await func.deleteInDetail()
        await t.expect(basiccategory1.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43118: Create basic category with blank Code
       - Open Create Basic Category form
       - Leave Code field blank
       - Click on Save button
       - Verify message
       */
    ('#43118: Create basic ctegory with blank Code', async t => {
        const create2 = new ManageDossierCategory()

        //Create basic category
        await dossierCat.createBasicCategory(' ', create2.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t
            .expect(message.vldMessage.innerText).contains(message.fieldRequired_DE)
    })

test.meta({ type: 'advance' })
    /*Scenario #43119: Create basic category with duplicate Code
      - Open Create Basic Category form
      - Input value in fields
      - Click on Save button
      - Verify message
      */

    ('#43119: Create basic category with duplicate Code', async t => {
        const create3 = new ManageDossierCategory()
        const basiccategory3 = Selector('span').withText(create3.nameValue)

        //Create the first Basic Category
        await dossierCat.createBasicCategory(create3.codeValue, create3.nameValue)
        await t.click(action.saveOnlyBtn).wait(2000)
        //Create the second Basic Category
        await dossierCat.createBasicCategory(create3.codeValue, create3.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t
            .expect(message.errorMessage.innerText).contains('Dieses Kurzzeichen existiert bereits')
            .click(message.closeErrorMessage)
        //Delete Basic Category
        await t.click(basiccategory3)
        await func.deleteInDetail()
        await t.click(basiccategory3)
        await func.deleteInDetail()
        await t.expect(basiccategory3.exists).notOk()  
    })

test.meta({ type: 'advance' })
    /*Scenario #43120: Create basic category with Code more than 50 characters
      - Open Create Basic Category form
      - Input value in fields
      - Click on Save button
      - Verify message
      */
   
    ('#43120: Create basic category with Code more than 50 characters', async t => {
        const create4 = new ManageDossierCategory()

        //Create Dossier Category
        await dossierCat.createBasicCategory('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', create4.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.max50Characters_DE)
    })

test.meta({ type: 'advance' })
    /*Scenario #43121: Create basic category with blank Name
      - Open Create Basic Category form
      - Leave Name field blank
      - Click on Save button
      - Verify message
      */
    ('#43121: Create basic category with blank Name', async t => {
        const create5 = new ManageDossierCategory()
        //Create Basic Category
        await dossierCat.createBasicCategory(create5.codeValue, ' ')
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.fieldRequired_DE)
    })

test.meta({ type: 'advance' })
    /*Scenario #43122: Create basic category with Name more than 254 characters
      - Open Create Basic Category form
      - Input value in fields
      - Click on Save button
      - Verify message
      */
    ('#43122: Create basic category with Name more than 254 characters', async t => {
        const create6 = new ManageDossierCategory()
        //Create Dossier Category
        await dossierCat.createBasicCategory(create6.codeValue, 'Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text')
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.max254Characters_DE)
            
    })

test.meta({ type: 'base' })
    /*Scenario #43133: Create Category 
       - Open Create Category form
       - Input valid value in all fields
       - Click on Save button
       - Verify value 
       */
   
    ('#43133: Create Category ', async t => {
        const create71 = new ManageDossierCategory()
        const create72 = new ManageDossierCategory()
        const basicCategory7 = Selector('span').withText(create71.nameValue)
        const category7 = Selector('span').withText(create72.nameValue)
        //Create Basic Category
        await dossierCat.createBasicCategory(create71.codeValue, create71.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.wait(2000)
        await t.expect(basicCategory7.exists).ok()
        await t.click(basicCategory7)
        await dossierCat.createCategory(create72.codeValue, create72.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(category7.exists).ok()
        //Delete category
        await t.click(category7)
        await func.deleteInDetail()
        await t.expect(category7.exists).notOk()
        //Delete basic category
        await t.click(basicCategory7)
        await func.deleteInDetail()
        await t.expect(basicCategory7.exists).notOk()
    })

test.meta({ type: 'advance' })
    /*Scenario #43134: Create ctegory with blank Code
       - Open Create Category form
       - Leave Code field blank
       - Click on Save and Close button
       - Verify message
       */

    ('#43134: Create ctegory with blank Code', async t => {
        const create81 = new ManageDossierCategory()
        const create82 = new ManageDossierCategory()
        const basicCategory8 = Selector('span').withText(create81.nameValue)

        //Create basic category
        await dossierCat.createBasicCategory(create81.codeValue, create81.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.click(basicCategory8)
        await dossierCat.createCategory(' ', create82.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.codeFieldRequired_DE)
        await t.wait(2000)
        //Delete basic category
        await t.click(basicCategory8)
        await func.deleteInDetail()
        await t.expect(basicCategory8.exists).notOk()

    })

test.meta({ type: 'advance' })
    /*Scenario #43135: Create category with duplicate Code
      - Open Create Category form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#43135: Create category with duplicate Code', async t => {
        const create91 = new ManageDossierCategory()
        const create92 = new ManageDossierCategory()
        const basicCategory9 = Selector('span').withText(create91.nameValue)
        const category9 = Selector('span').withText(create92.nameValue)

        //Create basic Category
        await dossierCat.createBasicCategory(create91.codeValue, create91.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.expect(basicCategory9.exists).ok()
        //create the first category
        await t.click(basicCategory9)
        await dossierCat.createCategory(create92.codeValue, create92.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.expect(category9.exists).ok()
        //Create the second Dossier Category
        await t.click(basicCategory9)
        await dossierCat.createCategory(create92.codeValue, create92.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t
            .expect(message.errorMessage.innerText).contains('Dieses Kurzzeichen existiert bereits')
            .click(message.closeErrorMessage)
        //Delete category
        await t.click(category9)
        await func.deleteInDetail()
        await t.click(category9)
        await func.deleteInDetail()
        await t.expect(category9.exists).notOk()
       
    })

test.meta({ type: 'advance' })
/*Scenario #43136: Create category with Code more than 50 characters
  - Open Create Category form
  - Input value in fields
  - Click on Save and Close button
  - Verify message
  */

    ('#43136: Create category with Code more than 50 characters', async t => {
        const create101 = new ManageDossierCategory()
        const create102 = new ManageDossierCategory()
        const basicCategory10 = Selector('span').withText(create101.nameValue)

        //Create basic Category
        await dossierCat.createBasicCategory(create101.codeValue, create101.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.expect(basicCategory10.exists).ok()
        //Create category
        await t.click(basicCategory10)
        await dossierCat.createCategory('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', create102.nameValue)
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.codeMaxLength_DE)
        await t.click(basicCategory10)
        await func.deleteInDetail()
        await t.expect(basicCategory10.exists).notOk()
        
    })

test.meta({ type: 'advance' })
    /*Scenario #43137: Create category with blank Name
      - Open Create Category form
      - Leave Name field blank
      - Click on Save and Close button
      - Verify message
      */

    ('#43137: Create category with blank Name', async t => {
        const create11_1 = new ManageDossierCategory()
        const create11_2 = new ManageDossierCategory()
        const basicCategory11 = Selector('span').withText(create11_1.nameValue)
        //Create basic Category
        await dossierCat.createBasicCategory(create11_1.codeValue, create11_1.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.expect(basicCategory11.exists).ok()
        //Create Dossier Category
        await t.click(basicCategory11)
        await dossierCat.createCategory(create11_2.codeValue, ' ')
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.nameFieldRequired_DE)
        await t.click(basicCategory11)
        await func.deleteInDetail()
        await t.expect(basicCategory11.exists).notOk()
        
    })

test.meta({ type: 'advance' })
    /*Scenario ##43138: Create category with Name more than 254 characters
      - Open Create Category form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#43138: Create category with Name more than 254 characters', async t => {
        const create12_1 = new ManageDossierCategory()
        const create12_2 = new ManageDossierCategory()
        const basicCategory12 = Selector('span').withText(create12_1.nameValue)

        //Create basic Category
        await dossierCat.createBasicCategory(create12_1.codeValue, create12_1.nameValue)
        await t.click(action.saveOnlyBtn)
        await t.expect(basicCategory12.exists).ok()
        //Create Dossier Category
        await t.click(basicCategory12)
        await dossierCat.createCategory(create12_2.codeValue, 'Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text Test Category Text')
        await t.click(action.saveOnlyBtn)
        //Assert 
        await t.expect(message.vldMessage.innerText).contains(message.nameMaxLength_DE)
        await t.click(basicCategory12)
        await func.deleteInDetail()
        await t.expect(basicCategory12.exists).notOk()

    })