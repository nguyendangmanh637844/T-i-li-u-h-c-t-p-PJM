﻿import { Selector } from "testcafe"

export default class DossierCategorySelector {
    constructor() {

        //Menu bar
        this.dossierMenu = Selector('a').withText("Dossier")
        this.dossierCategoryMenu = Selector('a').withText("Dossier-Kategorien")

        //Button
        this.addNewBtn = Selector('#btn-saveAndClose')
        this.definitionNode = Selector('span').withText("Definitionen")

        //Textbox fields
        this.codeBaseBox = Selector('#tb-base-code')
        this.nameBaseBox = Selector('#tb-base-name')
        this.descriptionBaseBox = Selector('#tb-base-description')

        this.codeBox = Selector('#tb-code')
        this.nameBox = Selector('#tb-name')

        //Translate
        this.nameDEBox = Selector('#NameNls-de')
        this.nameENBox = Selector('#NameNls-en')
        this.nameFRBox = Selector('#NameNls-fr')
        this.descriptionDEBox = Selector('#DescriptionNls-de')
        this.descriptionENBox = Selector('#DescriptionNls-en')
        this.descriptionFRBox = Selector('#DescriptionNls-fr')
    }
}