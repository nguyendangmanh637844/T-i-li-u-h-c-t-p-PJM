import { Selector, t } from "testcafe"
import DossierCategorySelector from "../selectors/dossier-category.selector"
import Utils from "../../../../commons/utils"
import ActionsSelector from "../../../../commons/actions-selector"

const selector = new DossierCategorySelector()
const randomData = new Utils();
const action = new ActionsSelector()

export default class ManageDossierCategory{
    constructor() {
        this.codeValue = randomData.getText('DC_Code', 15)
        this.nameValue = randomData.getText('DC_Name', 15)
    }

    async createBasicCategory(code, name) {
        await t
            .click(selector.definitionNode)
            .click(selector.addNewBtn)
            .typeText(selector.codeBaseBox, code)
            .typeText(selector.nameBaseBox, name)
    }

    async createCategory(code, name) {
        await t
            .click(selector.addNewBtn)
            .typeText(selector.codeBox, code)
            .typeText(selector.nameBox, name)
    }

    async editBasicCategory(code, name) {
        await t
            .click(selector.codeBaseBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.codeBaseBox, code)
            .click(selector.nameBaseBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.nameBaseBox, name)
    }
    async editCategory(code, name) {
        await t
            .click(selector.codeBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.codeBox, code)
            .click(selector.nameBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.nameBox, name)
    }

    async copyBasicCategory(code, name) {
        await t
            .wait(2000)
            .click(action.copyBtn)
            .click(selector.codeBaseBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.codeBaseBox, code)
            .click(selector.nameBaseBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.nameBaseBox, name)
    }
    async copyCategory(code, name) {
        await t
            .click(action.copyBtn)
            .click(selector.codeBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.codeBox, code)
            .click(selector.nameBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.nameBox, name)
    }

    async deleteCategory() {
        await t
            .click(selector.deleteBtn)
            .click(selector.confirmDeleteBtn)
            .click(selector.saveBtn)
    }
    
    async translateBasicCategory() {
        await t
            .click(action.translateBtn)
            .typeText(selector.nameDEBox, 'Basic Category DE')
            .typeText(selector.nameENBox, 'Basic Category EN')
            .typeText(selector.nameFRBox, 'Basic Category FR')
            .typeText(selector.descriptionDEBox, 'Test Basic Category DE')
            .typeText(selector.descriptionENBox, 'Test Basic Category EN')
            .typeText(selector.descriptionFRBox, 'Test Basic Category FR')
            .click(action.OKBtn)
    }

    async updateTranslateBasicCategory() {
        await t
            .click(action.translateBtn)
            .click(selector.nameDEBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.nameDEBox, 'Update basic category DE')
            .click(selector.nameENBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.nameENBox, 'Update basic category EN')
            .click(selector.nameFRBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.nameFRBox, 'Update basic category FR')
            .click(selector.descriptionDEBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.descriptionDEBox, 'Test update basic category DE')
            .click(selector.descriptionENBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.descriptionENBox, 'Test update basic category EN')
            .click(selector.descriptionFRBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.descriptionFRBox, 'Test update basic category FR')
            .click(action.OKBtn)
    }

    async translateCategory() {
        await t
            .click(action.translateBtn)
            .typeText(selector.nameDEBox, 'Category DE')
            .typeText(selector.nameENBox, 'Category EN')
            .typeText(selector.nameFRBox, 'Category FR')
            .click(action.OKBtn)
    }

    async updateTranslateCategory() {
        await t
            .click(action.translateBtn)
            .click(selector.nameDEBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.nameDEBox, 'Update category DE')
            .click(selector.nameENBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.nameENBox, 'Update category EN')
            .click(selector.nameFRBox)
            .pressKey('ctrl+a delete')
            .typeText(selector.nameFRBox, 'Update category FR')
            .click(action.OKBtn)
    }

}
