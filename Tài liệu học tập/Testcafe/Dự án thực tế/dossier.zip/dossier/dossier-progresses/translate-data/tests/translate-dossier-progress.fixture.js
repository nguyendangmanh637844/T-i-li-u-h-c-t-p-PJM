﻿import { Selector, t } from "testcafe"
import Configuration from "../../../../../commons/configuration"
import LoginPage from "../../../../authentication/functions/login-page"
import DossierProgressIndexSelector from "../../manage-dossier-progress/selectors/dossier-progress.index.selector"
import DossierProgressDetailSelector from "../../manage-dossier-progress/selectors/dossier-progress.detail.selector"
import ManageDossierProgress from "../../manage-dossier-progress/functions/manage-dossier-progress"

import TranslateDossierProgressDetails from "../selectors/translate-dossier-progress.detail.selector"
import TranslateIndex from "../../../../../commons/translate-selector"
import TranslateData from "../functions/translate-dossier-progress"

const config = new Configuration()
const login = new LoginPage()
const detailsSelector = new DossierProgressDetailSelector()
const indexSelector = new DossierProgressIndexSelector()
const dosPro = new ManageDossierProgress()

const translateDetail = new TranslateDossierProgressDetails()
const translateIndex = new TranslateIndex()
const translate = new TranslateData()


fixture`Dossier - Dossier Progress: Translate`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.dossierMenu)
        await t.click(indexSelector.dossierProgressMenu)
    })

test.meta({ type: 'advance' })
    /*Scenario: #39191: Check translated data when input normal data at DE language'
       - Create new Dossier Progress
       - Open form to edit it
       - Click on Translate button
       - Verify value in Tranlate form
       */
    ('#39191: Check translated data when input normal data at DE language', async t => {
        const create1 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create1.codeValue, create1.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Open detail view Dossier Progress
        await dosPro.filterDossierProgress(create1.codeValue)
        await t.click(indexSelector.editBtn)
        //Open translate data detail view
        await t.click(detailsSelector.translateBtn)
        await t.wait(2000)
        //Assertion
        await t
            .expect(translateDetail.nameDEBox.value).contains(create1.nameValue)
            .expect(translateDetail.nameENBox.value).contains(create1.nameValue)
            .expect(translateDetail.nameFRBox.value).contains(create1.nameValue)
            .click(translateDetail.cancelBtn)
            .click(detailsSelector.backBtn)
        //Delete data
        await dosPro.filterDossierProgress(create1.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')

    })

test.meta({ type: 'advance' })
    /*Scenario: #39198: Check translated data when input normal data at EN language'
      - Switch language to English, create new Dossier Progress 
      - Open form to edit it
      - Click on Translate button
      - Verify value in Tranlate form
      */

    ('#39198: Check translated data when input normal data at EN language', async t => {
        const create2 = new ManageDossierProgress()

        //Switch language to DE
        await t.click(translateIndex.languageToggle)
        await t.click(translateIndex.languageENDrop)
        await t.wait(3000)
        //Create Dossier Progress
        await dosPro.createDossierProgress(create2.codeValue, create2.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Open detail view Dossier Progress
        await dosPro.filterDossierProgress(create2.codeValue)
        await t.click(indexSelector.editBtn)
        //Open translate data detail view
        await t.click(detailsSelector.translateBtn)
        await t.wait(2000)
        //Assertion
        await t
            .expect(translateDetail.nameDEBox.value).contains(create2.nameValue)
            .expect(translateDetail.nameENBox.value).contains(create2.nameValue)
            .expect(translateDetail.nameFRBox.value).contains(create2.nameValue)
            .click(translateDetail.cancelBtn)
            .click(detailsSelector.backBtn)
        //Delete data
        await dosPro.filterDossierProgress(create2.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('No data to display')
    })

test.meta({ type: 'advance' })
    /*Scenario: #39197: Check translated data when input normal data at FR language'
     - Switch language to French, create new Dossier Progress
     - Open form to edit it
     - Click on Translate button
     - Verify value in Tranlate form
     */

    ('#39197: Check translated data when input normal data at FR language', async t => {
        const create3 = new ManageDossierProgress()

        //Switch language to FR 
        await t.wait(3000)
        //Create Dossier Progress
        await dosPro.createDossierProgress(create3.codeValue, create3.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Open detail view VAT Code
        await dosPro.filterDossierProgress(create3.codeValue)
        await t.click(indexSelector.editBtn)
        //Open translate data detail view
        await t.click(detailsSelector.translateBtn)
        await t.wait(2000)
        //Assertion
        await t
            .expect(translateDetail.nameDEBox.value).contains(create3.nameValue)
            .expect(translateDetail.nameENBox.value).contains(create3.nameValue)
            .expect(translateDetail.nameFRBox.value).contains(create3.nameValue)
            .click(translateDetail.cancelBtn)
            .click(detailsSelector.backBtn)
        //Delete data
        await dosPro.filterDossierProgress(create3.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Aucune donnée à afficher')
    })

test.meta({ type: 'base' })
    /*Scenario: #39192/39194/39195: Check translated data when entering form data translation first in default language'
      - Open form to create new Dossier Progress
      - Open Translate form, fill value
      - Save create Dossier Progress
      - Change language to English, French 
      - Verify value in list view
      */

    ('#39192/39194/39195: Check translated data when entering form data translation first in default language', async t => {
        const create4 = new ManageDossierProgress()
        //Create Dossier Progress
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.codeBox, create4.codeValue)
        //Create translated data
        await translate.createTranslate()
        //Expected
        await t
            .expect(detailsSelector.nameBox.value).contains('Name DE')
        //Save Dossier Progress
        await t.typeText(detailsSelector.sortBox, '1')
        await t.click(detailsSelector.saveCloseBtn)
        await dosPro.filterDossierProgress(create4.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create4.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name DE')
        //Check data after swicth default to EN language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageENDrop)
            .wait(3000)
        await dosPro.filterDossierProgress(create4.codeValue)
        //Assert after swicth default to EN language
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create4.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name EN')
        //Check data after swicth default to FR language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageFRDrop)
            .wait(5000)
        await dosPro.filterDossierProgress(create4.codeValue)
        //Assert after swicth default to FR language
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create4.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name FR')
        //Delete data
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Aucune donnée à afficher')
    })

test.meta({ type: 'advance' })
    /*Scenario: #39199/39200/39201: Check translated data when entering form data translation first in EN language'
      - Change language to English, open form to create new Dossier Progress
      - Open Translate form, fill value, save
      - Save create Dossier Progress
      - Change language to German, French
      - Verify value in list view
      */

    ('#39199/39200/39201: Check translated data when entering form data translation first in EN language', async t => {
        const create5 = new ManageDossierProgress()
        //Swicth to EN language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageENDrop)
            .wait(3000)
        //Create Dossier Progress
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.codeBox, create5.codeValue)
        //Create translated data
        await translate.createTranslate()
        //Expected
        await t
            .expect(detailsSelector.nameBox.value).contains('Name EN')
        //Save Dossier Progress
        await t.typeText(detailsSelector.sortBox, '1')
        await t.click(detailsSelector.saveCloseBtn)
        await dosPro.filterDossierProgress(create5.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create5.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name EN')
        //Check data after swicth default to DE language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageDEDrop)
            .wait(3000)
        await dosPro.filterDossierProgress(create5.codeValue)
        //Assert after swicth default to DE language
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create5.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name DE')
        //Check data after swicth default to FR language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageFRDrop)
            .wait(5000)
        await dosPro.filterDossierProgress(create5.codeValue)
        //Assert after swicth default to FR language
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create5.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name FR')
        //Delete data
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Aucune donnée à afficher')
    })

test.meta({ type: 'advance' })
    /*Scenario: #39202/39203/39204: Check translated data when entering form data translation first in FR language'
      - Change language to French, open form to create new Dossier Progress
      - Open Translate form, fill value, save
      - Save create Dossier Progress
      - Change language to German, English
      - Verify value in list view
      */

    ('#39202/39203/39204: Check translated data when entering form data translation first in FR language', async t => {
        const create6 = new ManageDossierProgress()
        //Swicth to EN language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageFRDrop)
            .wait(3000)
        //Create Dossier Progress
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.codeBox, create6.codeValue)
        //Create translated data
        await translate.createTranslate()
        //Expected
        await t
            .expect(detailsSelector.nameBox.value).contains('Name FR')
        //Save Dossier Progress
        await t.typeText(detailsSelector.sortBox, '1')
        await t.click(detailsSelector.saveCloseBtn)
        await dosPro.filterDossierProgress(create6.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create6.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name FR')
        //Check data after swicth default to DE language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageDEDrop)
            .wait(3000)
        await dosPro.filterDossierProgress(create6.codeValue)
        //Assert after swicth default to EN language
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create6.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name DE')
        //Check data after swicth default to EN language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageENDrop)
            .wait(5000)
        await dosPro.filterDossierProgress(create6.codeValue)
        //Assert after swicth default to FR language
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create6.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name EN')
        //Delete data
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('No data to display')
    })

test.meta({ type: 'advance' })
    /*Scenario: #39211: Check translated data when edit Dossier Progress at default language'
      - Change language to German, create new Dossier Progress
      - Edit this Dossier Progress above, save
      - Open Translate form
      - Verìy data
      */
    ('#39211: Check translated data when edit Dossier Progress at default language', async t => {
        const create7 = new ManageDossierProgress()
        //Create Dossier Progress
        await dosPro.createDossierProgress(create7.codeValue, create7.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Edit Dossier Progress
        await dosPro.filterDossierProgress(create7.codeValue)
        await dosPro.editDossierProgress(create7.codeValue, 'Name update DE')
        await t.click(detailsSelector.saveCloseBtn)
        await t.wait(5000)
        //Assert
        await dosPro.filterDossierProgress(create7.codeValue)
        await t
            .click(indexSelector.editBtn)
            .click(detailsSelector.translateBtn)
            .wait(2000)
            .expect(translateDetail.nameDEBox.value).contains('Name update DE')
            .expect(translateDetail.nameENBox.value).contains(create7.nameValue)
            .expect(translateDetail.nameFRBox.value).contains(create7.nameValue)
            .click(translateDetail.cancelBtn)
            .click(detailsSelector.backBtn)
        //Delete data
        await dosPro.filterDossierProgress(create7.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')

    })


test.meta({ type: 'advance' })
    /*Scenario: #39212: Check translated data when edit Dossier Progress at EN language'
      - Create new Dossier Progress
      - Change language to English
      - Edit this Dossier Progress above, save
      - Open Translate form
      - Verìy data
      */
    ('#39212: Check translated data when edit Dossier Progress at EN language', async t => {
        const create8 = new ManageDossierProgress()
        //Create Dossier Progress
        await dosPro.createDossierProgress(create8.codeValue, create8.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Swicth language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageENDrop)
            .wait(4000)
        //Edit Dossier Progress
        await dosPro.filterDossierProgress(create8.codeValue)
        await dosPro.editDossierProgress(create8.codeValue, 'Name update EN')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert
        await dosPro.filterDossierProgress(create8.codeValue)
        await t
            .click(indexSelector.editBtn)
            .click(detailsSelector.translateBtn)
            .expect(translateDetail.nameENBox.value).contains('Name update EN')
            .expect(translateDetail.nameDEBox.value).contains(create8.nameValue)
            .expect(translateDetail.nameFRBox.value).contains(create8.nameValue)
            .click(translateDetail.cancelBtn)
            .click(detailsSelector.backBtn)
        //Delete data

        await dosPro.filterDossierProgress(create8.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('No data to display')
    })

test.meta({ type: 'advance' })
    /*Scenario: #39213: Check translated data when edit Dossier Progress at FE language'
      - Create new Dossier Progress
      - Change language to French
      - Edit this Dossier Progress above, save
      - Open Translate form
      - Verìy data
      */
    ('#39213: Check translated data when edit Dossier Progress at FE language', async t => {
        const create9 = new ManageDossierProgress()
        //Create Dossier Progress
        await dosPro.createDossierProgress(create9.codeValue, create9.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Swicth language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageFRDrop)
            .wait(4000)
        //Edit Dossier Progress
        await dosPro.filterDossierProgress(create9.codeValue)
        await dosPro.editDossierProgress(create9.codeValue, 'Name update FE')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert
        await dosPro.filterDossierProgress(create9.codeValue)
        await t
            .click(indexSelector.editBtn)
            .click(detailsSelector.translateBtn)
            .expect(translateDetail.nameFRBox.value).contains('Name update FE')
            .expect(translateDetail.nameENBox.value).contains(create9.nameValue)
            .expect(translateDetail.nameDEBox.value).contains(create9.nameValue)
            .click(translateDetail.cancelBtn)
            .click(detailsSelector.backBtn)
        //Delete data
        await dosPro.filterDossierProgress(create9.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Aucune donnée à afficher')
    })
   
test.meta({ type: 'base' })
    /*Scenario: #39214/39215/39216: Check translated data when edit form data translation at default language'
      - Create new Dossier Progress
      - Create Translate Data
      - Save create Dossier Progress
      - Edit Translate Data
      - Switch language to English, French
      - Verìy data in list view , detail view
      */
    ('#39214/39215/39216: Check translated data when edit form data translation at default language', async t => {
        const create10 = new ManageDossierProgress()
        //Create Dossier Progress
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.codeBox, create10.codeValue)
        //Create translated data
        await translate.createTranslate()
        await t.typeText(detailsSelector.sortBox, '1')
        await t.click(detailsSelector.saveCloseBtn)
        //Edit translate data
        await dosPro.filterDossierProgress(create10.codeValue)
        await t.click(indexSelector.editBtn)
        await translate.editTranslate()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert  after edit translate data
        await dosPro.filterDossierProgress(create10.codeValue)
        await t.click(indexSelector.editBtn)
        await t
            //Assert in view detail
            .expect(detailsSelector.nameBox.value).contains('Name update DE')
            .click(detailsSelector.backBtn)
            //Assert in view table
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name update DE')
        //Check when switch to EN language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageENDrop)
            .wait(3000)
        //Assert after switch to EN language
        await dosPro.filterDossierProgress(create10.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name update EN')
        //Check when switch to FR language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageFRDrop)
            .wait(3000)
        //Assert after switch to FR language
        await dosPro.filterDossierProgress(create10.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name update FR')
        //Delete data
        await t.click(indexSelector.clearFilterBtn)
        await dosPro.filterDossierProgress(create10.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Aucune donnée à afficher')
    })

test.meta({ type: 'advance' })
    /*Scenario: #39217/39217/39217: Check translated data when edit form data translation at EN language'
     - Change language to English, create new Dossier Progress
     - Create Translate Data
     - Save create Dossier Progress
     - Edit Translate Data
     - Switch language to German, French
     - Verìy data in list view , detail view
     */
    ('#39217/39217/39217: Check translated data when edit form data translation at EN language', async t => {
        const create11 = new ManageDossierProgress()

        //Switch to EN language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageENDrop)
            .wait(3000)

        //Create Dossier Progress
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.codeBox, create11.codeValue)
        //Create translated data
        await translate.createTranslate()
        await t.typeText(detailsSelector.sortBox, '1')
        await t.click(detailsSelector.saveCloseBtn)
        //Edit translate data
        await dosPro.filterDossierProgress(create11.codeValue)
        await t.click(indexSelector.editBtn)
        await translate.editTranslate()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert  after edit translate data
        await dosPro.filterDossierProgress(create11.codeValue)
        await t.click(indexSelector.editBtn)
        await t
            //Assert in view detail
            .expect(detailsSelector.nameBox.value).contains('Name update EN')
            .click(detailsSelector.backBtn)
            //Assert in view table
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name update EN')
        //Check when switch to DN language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageDEDrop)
            .wait(3000)
        //Assert after switch to EN language
        await dosPro.filterDossierProgress(create11.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name update DE')
        //Check when switch to FR language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageFRDrop)
            .wait(3000)
        //Assert after switch to FR language
        await dosPro.filterDossierProgress(create11.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name update FR')
        //Delete data
        await t.click(indexSelector.clearFilterBtn)
        await dosPro.filterDossierProgress(create11.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Aucune donnée à afficher')
    })

test.meta({ type: 'advance' })
    /*Scenario: 39218/39219/39220: Check translated data when edit form data translation at FE language'
      - Change language to French, create new Dossier Progress
      - Create Translate Data
      - Save create Dossier Progress
      - Edit Translate Data
      - Switch language to German, English
      - Verìy data in list view , detail view
      */
    ('#39218/39219/39220: Check translated data when edit form data translation at FE language', async t => {

        const create12 = new ManageDossierProgress()

        //Switch to FE language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageFRDrop)
            .wait(3000)
        //Create Dossier Progress
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.codeBox, create12.codeValue)
        //Create translated data
        await translate.createTranslate()
        await t.typeText(detailsSelector.sortBox, '1')
        await t.click(detailsSelector.saveCloseBtn)
        //Edit translate data
        await dosPro.filterDossierProgress(create12.codeValue)
        await t.click(indexSelector.editBtn)
        await translate.editTranslate()
        await t.click(detailsSelector.saveCloseBtn)
        //Assert  after edit translate data
        await dosPro.filterDossierProgress(create12.codeValue)
        await t.click(indexSelector.editBtn)
        await t
            //Assert in view detail
            .expect(detailsSelector.nameBox.value).contains('Name update FR')
            .click(detailsSelector.backBtn)
            //Assert in view tabl
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name update FR')
        //Check when switch to DE language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageDEDrop)
            .wait(3000)
        //Assert after switch to DE language
        await dosPro.filterDossierProgress(create12.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name update DE')
        //Check when switch to EN language
        await t
            .click(translateIndex.languageToggle)
            .click(translateIndex.languageENDrop)
            .wait(3000)
        //Assert after switch to FR language
        await dosPro.filterDossierProgress(create12.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains('Name update EN')
        //Delete data
        await t.click(indexSelector.clearFilterBtn)
        await dosPro.filterDossierProgress(create12.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('No data to display')
    })

