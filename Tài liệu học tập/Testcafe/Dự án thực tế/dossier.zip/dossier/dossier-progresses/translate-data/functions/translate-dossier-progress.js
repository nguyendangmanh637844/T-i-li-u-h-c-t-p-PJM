import { Selector, t } from "testcafe"
import DossierProgressDetailSelector from "../../manage-dossier-progress/selectors/dossier-progress.detail.selector"
import TranslateDossierProgressDetails from "../selectors/translate-dossier-progress.detail.selector"

const pageDetailDocPro = new DossierProgressDetailSelector()
const translate = new TranslateDossierProgressDetails()

export default class TranslateData {
    async createTranslate() {
        await t
            .click(pageDetailDocPro.translateBtn)
            .typeText(translate.nameDEBox, 'Name DE')
            .typeText(translate.nameENBox, 'Name EN')
            .typeText(translate.nameFRBox, 'Name FR')
            .click(translate.saveBtn)
    }

    async editTranslate() {
        await t
            .click(pageDetailDocPro.translateBtn)
            .click(translate.nameDEBox)
            .pressKey('ctrl+a delete')
            .typeText(translate.nameDEBox, 'Name update DE')
            .click(translate.nameENBox)
            .pressKey('ctrl+a delete')
            .typeText(translate.nameENBox, 'Name update EN')
            .click(translate.nameFRBox)
            .pressKey('ctrl+a delete')
            .typeText(translate.nameFRBox, 'Name update FR')
            .click(translate.saveBtn)
    }
}
