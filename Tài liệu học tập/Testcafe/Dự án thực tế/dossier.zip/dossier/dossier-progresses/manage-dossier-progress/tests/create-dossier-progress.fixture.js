﻿import { Selector, t } from "testcafe"
import Configuration from "../../../../../commons/configuration"
import LoginPage from "../../../../authentication/functions/login-page"
import DossierProgressIndexSelector from "../selectors/dossier-progress.index.selector"
import DossierProgressDetailSelector from "../selectors/dossier-progress.detail.selector"
import ManageDossierProgress from "../functions/manage-dossier-progress"

const config = new Configuration()
const login = new LoginPage()
const indexSelector = new DossierProgressIndexSelector()
const detailsSelector = new DossierProgressDetailSelector()
const dosPro = new ManageDossierProgress()

fixture`Dossier - Dossier Progress: Create Dossier Progress`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.dossierMenu)
        await t.click(indexSelector.dossierProgressMenu)

    })

test.meta({ type: 'base' })
    /*Scenario #42121: Create Dossier Progress with Save and Close button
       - Open Create Dossier Progress form
       - Input valid value in all fields
       - Click on Save and Close button
       - Verify value 
       */
    ('#42121: Create Dossier Progress with Save and Close button', async t => {
        const create1 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create1.codeValue, create1.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        await dosPro.filterDossierProgress(create1.codeValue)
        //Assert 
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create1.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains(create1.nameValue)
        //Delete Dossier Progress
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    /*Scenario #42122: Create Dossier Progress with Save and New button
       - Open Create Dossier Progress form
       - Input valid value in all fields
       - Click on Save and New button
       - Verify value
       */
    ('#42122: Create Dossier Progress with Save and New button', async t => {
        const create2 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create2.codeValue, create2.nameValue)
        await t.click(detailsSelector.saveDropDownBtn)
        await t.click(detailsSelector.saveNewBtn)
        await t.click(detailsSelector.backBtn)
        //Assert 
        await dosPro.filterDossierProgress(create2.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(create2.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains(create2.nameValue)
        //Delete Dossier Progress
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })


test.meta({ type: 'advance' })
    /*Scenario #42123: Create Dossier Progress with blank Code
       - Open Create Dossier Progress form
       - Leave Code field blank
       - Click on Save and Close button
       - Verify message
       */
    ('#42123: Create Dossier Progresse with blank Code', async t => {

        //Create Dossier Progress
        await dosPro.createDossierProgress(' ', 'text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to VAT Code list
        await t.click(detailsSelector.backBtn)
    })

test.meta({ type: 'advance' })
    /*Scenario #42124: Create Dossier Progress with duplicate Code
      - Open Create Dossier Progress form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#42124: Create Dossier Progress with duplicate Code', async t => {
        const create4 = new ManageDossierProgress()
        //Create the first Dossier Progress
        await dosPro.createDossierProgress(create4.codeValue, create4.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Create the second Dossier Progress
        await dosPro.createDossierProgress(create4.codeValue, create4.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Dieses Kurzzeichen existiert bereits')
            .click(detailsSelector.closeErrorMessage)
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete Dossier Progress
        await dosPro.filterDossierProgress(create4.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    /*Scenario #42125: Create Dossier Progress with Code more than 50 characters
      - Open Create Dossier Progress form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#42125: Create Dossier Progress with Code more than 50 characters', async t => {

        //Create Dossier Progress
        await dosPro.createDossierProgress('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', 'Text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 50 Zeichen')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
    })

test.meta({ type: 'advance' })
    /*Scenario #42126: Create Dossier Progress with blank Name
      - Open Create Dossier Progress form
      - Leave Name field blank
      - Click on Save and Close button
      - Verify message
      */
    ('#42126: Create Dossier Progress with blank Name', async t => {

        //Create Dossier Progress
        await dosPro.createDossierProgress('Dossier Progress', ' ')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
    })

test.meta({ type: 'advance' })
    /*Scenario #42127: Create Dossier Progress with Name more than 254 characters
      - Open Create Dossier Progress form
      - Input value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#42127: Create Dossier Progress with Name more than 254 characters', async t => {

        //Create Dossier Progress
        await dosPro.createDossierProgress('Dossier Progress', 'Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 254 Zeichen')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
    })