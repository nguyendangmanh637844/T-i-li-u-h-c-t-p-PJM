﻿import { Selector, t } from "testcafe"
import Configuration from "../../../../../commons/configuration"
import LoginPage from "../../../../authentication/functions/login-page"
import DossierProgressIndexSelector from "../selectors/dossier-progress.index.selector"
import DossierProgressDetailSelector from "../selectors/dossier-progress.detail.selector"
import ManageDossierProgress from "../functions/manage-dossier-progress"

const config = new Configuration()
const login = new LoginPage()
const indexSelector = new DossierProgressIndexSelector()
const detailsSelector = new DossierProgressDetailSelector()
const dosPro = new ManageDossierProgress()

fixture`Dossier - Dossier Progress: Edit Dossier Progress`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.dossierMenu)
        await t.click(indexSelector.dossierProgressMenu)

    })

test.meta({ type: 'base' })
    /*Scenario #42141: Edit Dossier Progress with Save and Close button
      - Create new Dossier Progress
      - Open form to edit it
      - Input value in fields
      - Click on Save and Close button
      - Verify value
      */
    ('#42141: Edit Dossier Progress with Save and Close button', async t => {
        const create1 = new ManageDossierProgress()
        const edit1 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create1.codeValue, create1.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Edit Dossier Progress
        await dosPro.filterDossierProgress(create1.codeValue)
        await dosPro.editDossierProgress(edit1.codeValue, edit1.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await dosPro.filterDossierProgress(edit1.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(edit1.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains(edit1.nameValue)
        //Delete Dossier Progress
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    /*Scenario #42142: Edit Dossier Progress with Save and New button
      - Create new Dossier Progress
      - Open form to edit it
      - Input value in fields
      - Click on Save and New button
      - Verify value
      */
    ('#42142: Edit Dossier Progress with Save and New button', async t => {
        const create2 = new ManageDossierProgress()
        const edit2 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create2.codeValue, create2.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Edit Dossier Progress
        await dosPro.filterDossierProgress(create2.codeValue)
        await dosPro.editDossierProgress(edit2.codeValue, edit2.nameValue)
        await t.click(detailsSelector.saveDropDownBtn)
        await t.click(detailsSelector.saveNewBtn)
        await t.click(detailsSelector.backBtn);
        //Assert 
        await dosPro.filterDossierProgress(edit2.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(edit2.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains(edit2.nameValue)
        //Delete Dossier Progress
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    /*Scenario ##42143: Edit Dossier Progresse with blank Code
      - Create new Dossier Progress
      - Open form to edit it
      - Leave Code field blank
      - Click on Save and Close button
      - Verify message
      */
    ('#42143: Edit Dossier Progresse with blank Code', async t => {
        const create3 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create3.codeValue, create3.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Edit Dossier Progress
        await dosPro.filterDossierProgress(create3.codeValue)
        await dosPro.editDossierProgress(' ', 'text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete Dossier Progress
        await dosPro.filterDossierProgress(create3.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    /*Scenario #42144: Edit Dossier Progress with duplicate Code
      - Create new Dossier Progress
      - Open form to edit it
      - Fill value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#42144: Edit Dossier Progress with duplicate Code', async t => {
        const create41 = new ManageDossierProgress()
        const create42 = new ManageDossierProgress()

        //Create the first Dossier Progress
        await dosPro.createDossierProgress(create41.codeValue, create41.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Create the second Dossier Progress
        await dosPro.createDossierProgress(create42.codeValue, create42.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Edit the first Dossier Progress
        await dosPro.filterDossierProgress(create41.codeValue)
        await dosPro.editDossierProgress(create42.codeValue, create42.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Assert
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Dieses Kurzzeichen existiert bereits')
            .click(detailsSelector.closeErrorMessage)
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete the first Dossier Progress
        await dosPro.filterDossierProgress(create41.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
        //Delete the second Dossier Progress
        await t.click(indexSelector.clearFilterBtn)
        await dosPro.filterDossierProgress(create42.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')

    })

test.meta({ type: 'advance' })
    /*Scenario #42145: Edit Dossier Progress with Code more than 50 characters
      - Create new Dossier Progress
      - Open form to edit it
      - Fill value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#42145: Edit Dossier Progress with Code more than 50 characters', async t => {
        const create5 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create5.codeValue, create5.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Edit Dossier Progress
        await dosPro.filterDossierProgress(create5.codeValue)
        await dosPro.editDossierProgress('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', 'Text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 50 Zeichen')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete Dossier Progress
        await dosPro.filterDossierProgress(create5.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')

    })

test.meta({ type: 'advance' })
    /*Scenario #42146: Edit Dossier Progress with blank Name
      - Create new Dossier Progress
      - Open form to edit it
      - Leave Name field blank
      - Click on Save and Close button
      - Verify message
      */
    ('#42146: Edit Dossier Progress with blank Name', async t => {
        const create6 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create6.codeValue, create6.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Edit Dossier Progress
        await dosPro.filterDossierProgress(create6.codeValue)
        await dosPro.editDossierProgress('Dossier Progress', ' ')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete Dossier Progress
        await dosPro.filterDossierProgress(create6.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    /*Scenario #42147: Edit Dossier Progress with Name more than 254 characters
      - Create new Dossier Progress
      - Open form to edit it
      - Fill value in fields
      - Click on Save and Close button
      - Verify message
      */
    ('#42147: Edit Dossier Progress with Name more than 254 characters', async t => {
        const create7 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create7.codeValue, create7.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Edit Dossier Progress
        await dosPro.filterDossierProgress(create7.codeValue)
        await dosPro.editDossierProgress('Dossier Progress', 'Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text Test Doc Group Text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 254 Zeichen')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete Dossier Progress
        await dosPro.filterDossierProgress(create7.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })