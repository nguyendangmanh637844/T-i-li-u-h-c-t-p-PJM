﻿import { Selector, t } from "testcafe"
import Configuration from "../../../../../commons/configuration"
import LoginPage from "../../../../authentication/functions/login-page"
import DossierProgressIndexSelector from "../selectors/dossier-progress.index.selector"
import DossierProgressDetailSelector from "../selectors/dossier-progress.detail.selector"
import ManageDossierProgress from "../functions/manage-dossier-progress"

const config = new Configuration()
const login = new LoginPage()
const indexSelector = new DossierProgressIndexSelector()
const detailsSelector = new DossierProgressDetailSelector()
const dosPro = new ManageDossierProgress()

fixture`Dossier - Dossier Progress: Concurrency`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.dossierMenu)
        await t.click(indexSelector.dossierProgressMenu)

    })

test.meta({ type: 'base' })
    /*Scenario: #42324/42336: Check concurrency when users edit Dossier Progress with Override option'
      - Open browser, login with user 1, edit a Dossier Progress
      - Open new browser, login with user 2, edit the same Dossier Progress with user 1, click Save
      - Back to user 1, click Save
      - Click Override
       */

    ('#42324/42336: Check concurrency when users edit Dossier Progress with Override option', async t => {
        const window1 = await t.getCurrentWindow()
        const window2 = await t.openWindow(config.UrlAdmin)
        const create1 = new ManageDossierProgress()
        const edit11 = new ManageDossierProgress()
        const edit12 = new ManageDossierProgress()

        //Create Dossier Progress at window 1
        await t.switchToWindow(window1)
        await dosPro.createDossierProgress(create1.codeValue, create1.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Edit Dossier Progress at window 1
        await dosPro.filterDossierProgress(create1.codeValue)
        await dosPro.editDossierProgress(edit11.codeValue, edit11.nameValue)
        //Edit Dossier Progress at window 2
        await t.switchToWindow(window2)
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.dossierMenu)
        await t.click(indexSelector.dossierProgressMenu)
        await dosPro.filterDossierProgress(create1.codeValue)
        await dosPro.editDossierProgress(edit12.codeValue, edit12.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //switch to window 1
        await t.switchToWindow(window1)
        await t.click(detailsSelector.saveCloseBtn)
        await t.wait(3000)
        //Assert message
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Widersprüchliche Informationen')
        //Assert informantion
        await t.expect(detailsSelector.errorMessage.innerText).contains('Dossier-Fortschritt')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Daten haben sich geändert')

        //Override information
        await t.click(detailsSelector.overrideBtn)
        //Assert
        await dosPro.filterDossierProgress(edit11.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(edit11.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains(edit11.nameValue)
        //Delete data
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    /*Scenario: #42324/42337: Check concurrency when users edit Dossier Progress with Refresh option'
      - Open browser, login with user 1, edit a Dossier Progress
      - Open new browser, login with user 2, edit the same Dossier Progress with user 1, click Save
      - Back to user 1, click Save
      - Click Refresh
       */
    ('#42324/42337: Check concurrency when both users edit the same Dossier Progress with Refresh option', async t => {
        const window1 = await t.getCurrentWindow()
        const window2 = await t.openWindow(config.UrlAdmin)
        const create2 = new ManageDossierProgress()
        const edit21 = new ManageDossierProgress()
        const edit22 = new ManageDossierProgress()

        //Create Dossier Progress at window 1
        await t.switchToWindow(window1)
        await dosPro.createDossierProgress(create2.codeValue, create2.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Edit Dossier Progress at window 1
        await dosPro.filterDossierProgress(create2.codeValue)
        await dosPro.editDossierProgress(edit21.codeValue, edit21.nameValue)

        //Edit Dossier Progress at window 2
        await t.switchToWindow(window2)
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.dossierMenu)
        await t.click(indexSelector.dossierProgressMenu)
        await dosPro.filterDossierProgress(create2.codeValue)
        await dosPro.editDossierProgress(edit22.codeValue, edit22.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //switch to window 1
        await t.switchToWindow(window1)
        await t.click(detailsSelector.saveCloseBtn)
        await t.wait(3000)
        //Assert message
       await t.expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Widersprüchliche Informationen')
        //Assert informantion
        await t.expect(detailsSelector.errorMessage.innerText).contains('Dossier-Fortschritt')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Daten haben sich geändert')
        await t.wait(3000)
        await t.click(detailsSelector.refreshBtn)
        await t.wait(2000)
        await t.expect(detailsSelector.codeBox.value).contains(edit22.codeValue)
        await t.expect(detailsSelector.nameBox.value).contains(edit22.nameValue)
        await t.click(detailsSelector.backBtn)
        //Assert
        await dosPro.filterDossierProgress(edit22.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(edit22.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains(edit22.nameValue)
        //Delete data
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    /*Scenario: #42324/42338: Check concurrency when users edit Dossier Progress with Cancel option'
      - Open browser, login with user 1, edit a Dossier Progress
      - Open new browser, login with user 2, edit the same Dossier Progress with user 1, click Save
      - Back to user 1, click Save
      - Click Cancel
       */
    ('#42324/42337: Check concurrency when both users edit the same Dossier Progress with Cancel option', async t => {
        const window1 = await t.getCurrentWindow()
        const window2 = await t.openWindow(config.UrlAdmin)
        const create3 = new ManageDossierProgress()
        const edit31 = new ManageDossierProgress()
        const edit32 = new ManageDossierProgress()

        //Create Dossier Progress at window 1
        await t.switchToWindow(window1)
        await dosPro.createDossierProgress(create3.codeValue, create3.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Edit Dossier Progress at window 1
        await dosPro.filterDossierProgress(create3.codeValue)
        await dosPro.editDossierProgress(edit31.codeValue, edit31.nameValue)

        //Edit Dossier Progress at window 2
        await t.switchToWindow(window2)
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.dossierMenu)
        await t.click(indexSelector.dossierProgressMenu)
        await dosPro.filterDossierProgress(create3.codeValue)
        await dosPro.editDossierProgress(edit32.codeValue, edit32.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //switch to window 1
        await t.switchToWindow(window1)
        await t.click(detailsSelector.saveCloseBtn)
        await t.wait(3000)
        //Assert message
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Datensatz, den Sie bearbeiten wollten, wurde vor Ihnen von einem anderen Benutzer geändert.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Der Editiervorgang wurde abgebrochen und die aktuellen Werte in der Datenbank wurden angezeigt.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Wenn Sie diesen Datensatz dennoch bearbeiten möchten, klicken Sie erneut auf die Schaltfläche Überschreiben.')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Widersprüchliche Informationen')
        //Assert informantion
        await t.expect(detailsSelector.errorMessage.innerText).contains('Dossier-Fortschritt')
        await t.expect(detailsSelector.errorMessage.innerText).contains('Daten haben sich geändert')

        await t.click(detailsSelector.cancelBtn)
        await t.expect(detailsSelector.codeBox.value).contains(edit31.codeValue)
        await t.expect(detailsSelector.nameBox.value).contains(edit31.nameValue)
        await t.click(detailsSelector.backBtn)
        //Assert
        await dosPro.filterDossierProgress(edit32.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(edit32.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains(edit32.nameValue)
        //Delete data
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    /*Scenario: #42332: Check concurrency when users delete the same Dossier Progress'
       - Open browser, login with user 1, delete a Dossier Progress
       - Open new browser, login with user 2, delete the same Dossier Progress with user 1, click Save
       - Back to user 1, click Save
        */
    ('#42332: Check concurrency when both users delete the same Dossier Progress', async t => {
        const window1 = await t.getCurrentWindow()
        const window2 = await t.openWindow(config.UrlAdmin)
        const create4 = new ManageDossierProgress()

        //Create Dossier Progress at window 1
        await t.switchToWindow(window1)
        await dosPro.createDossierProgress(create4.codeValue, create4.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Delete VAT Code at window 1
        await dosPro.filterDossierProgress(create4.codeValue)
        await t.click(indexSelector.deleteBtn)

        //Delete Dossier Progress at window 2
        await t.switchToWindow(window2)
        await t.maximizeWindow()
        await t.wait(7000)
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.dossierMenu)
        await t.click(indexSelector.dossierProgressMenu)
        await dosPro.filterDossierProgress(create4.codeValue)
        await dosPro.deleteDossierProgress()
        //switch to window 1
        await t.switchToWindow(window1)
        await t.click(indexSelector.confirmDeleteBtn)
            .wait(2000)
            .expect(detailsSelector.errorMessage.innerText).contains('Kann nicht gelöscht werden. Der Datensatz wurde von einem anderen Benutzer gelöscht.')
            .click(detailsSelector.closeErrorMessage)
        //Assert
        await dosPro.filterDossierProgress(create4.codeValue)
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    /*Scenario:  #42326: Check concurrency when user 1 delete and user 2 edit the same Dossier Progress'
   - Open browser, login with user 1, delete a Dossier Progress
   - Open new browser, login with user 2, edit the same Dossier Progress with user 1
   - Back to user 1, click Save
   - Back to user 2, click Save
*/
    ('#42326: Check concurrency when user 1 delete and user 2 edit the same Dossier Progress', async t => {
        const window1 = await t.getCurrentWindow()
        const window2 = await t.openWindow(config.UrlAdmin)
        const create5 = new ManageDossierProgress()
        const edit52 = new ManageDossierProgress()

        //Create Dossier Progress at initial Window
        await t.switchToWindow(window1)
        await dosPro.createDossierProgress(create5.codeValue, create5.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Open detail view at initial Window
        await dosPro.filterDossierProgress(create5.codeValue)
        await t.click(indexSelector.deleteBtn)
        //Open second browser
        await t.switchToWindow(window2)
        await t.maximizeWindow()
        await t.wait(5000)
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.dossierMenu)
        await t.click(indexSelector.dossierProgressMenu)
        //Open detail view at second Window and edit that Dossier Progress
        await dosPro.filterDossierProgress(create5.codeValue)
        await dosPro.editDossierProgress(edit52.codeValue, edit52.nameValue)

        //Open the first window
        await t.switchToWindow(window1)
        await t
            .click(indexSelector.confirmDeleteBtn)
            .wait(2000)

        //Open second browser
        await t.switchToWindow(window2)
        await t.click(detailsSelector.saveCloseBtn)
        //Assert
        await t.expect(detailsSelector.errorMessage.innerText).contains('Speichern nicht möglich. Die Datensatz wurde von einem anderen Benutzer gelöscht.')
        await t.click(detailsSelector.closeErrorMessage)
        //Assert
        await dosPro.filterDossierProgress(create5.codeValue)
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')

    })