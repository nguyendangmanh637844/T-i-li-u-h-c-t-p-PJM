﻿import { Selector, t } from "testcafe"
import Configuration from "../../../../../commons/configuration"
import LoginPage from "../../../../authentication/functions/login-page"
import DossierProgressIndexSelector from "../selectors/dossier-progress.index.selector"
import DossierProgressDetailSelector from "../selectors/dossier-progress.detail.selector"
import ManageDossierProgress from "../functions/manage-dossier-progress"

const config = new Configuration()
const login = new LoginPage()
const indexSelector = new DossierProgressIndexSelector()
const detailsSelector = new DossierProgressDetailSelector()
const dosPro = new ManageDossierProgress()

fixture`Dossier - Dossier Progress: Copy Dossier Progress`
    .page(config.UrlAdmin)
    .beforeEach(async t => {
        await config.configBeforeEach()
        await login.login(config.UserName, config.Password)
        await t.click(indexSelector.dossierMenu)
        await t.click(indexSelector.dossierProgressMenu)

    })

test.meta({ type: 'base' })
    /*Scenario #42215: Copy Dossier Progress with Save and Close button
      - Create new Dossier Progress
      - Open form to copy it
      - Input value in fields
      - Click on Save and Close button
      - Verify value
      */
    ('#42215: Copy Dossier Progress with Save and Close button', async t => {
        const create1 = new ManageDossierProgress()
        const copy1 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create1.codeValue, create1.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Copy Dossier Progress
        await dosPro.filterDossierProgress(create1.codeValue)
        await dosPro.copyDossierProgress(copy1.codeValue, copy1.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await dosPro.filterDossierProgress(copy1.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(copy1.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains(copy1.nameValue)
        //Delete Dossier Progress
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'base' })
    /*Scenario #42216: Copy Dossier Progress with Save and New button
     - Create new Dossier Progress
     - Open form to copy it
     - Input value in fields
     - Click on Save and New button
     - Verify value
     */
    ('#42216: Copy Dossier Progress with Save and New button', async t => {
        const create2 = new ManageDossierProgress()
        const copy2 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create2.codeValue, create2.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Copy Dossier Progress
        await dosPro.filterDossierProgress(create2.codeValue)
        await dosPro.copyDossierProgress(copy2.codeValue, copy2.nameValue)
        await t.click(detailsSelector.saveDropDownBtn)
        await t.click(detailsSelector.saveNewBtn)
        await t.click(detailsSelector.backBtn);
        //Assert 
        await dosPro.filterDossierProgress(copy2.codeValue)
        await t
            .expect(indexSelector.dossierProgresTable.innerText).contains(copy2.codeValue)
            .expect(indexSelector.dossierProgresTable.innerText).contains(copy2.nameValue)
        //Delete Dossier Progress
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    /*Scenario #42217: Copy Dossier Progresse with blank Code
          - Create new Dossier Progress
          - Open form to copy it
          - Leave Code field blank
          - Click on Save and Close button
          - Verify value
      */
    ('#42217: Copy Dossier Progresse with blank Code', async t => {
        const create3 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create3.codeValue, create3.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Copy Dossier Progress
        await dosPro.filterDossierProgress(create3.codeValue)
        await dosPro.copyDossierProgress(' ', 'text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete Dossier Progress
        await dosPro.filterDossierProgress(create3.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    /*Scenario #42218: Copy Dossier Progress with duplicate Code
         - Create new Dossier Progress
         - Open form to copy it
         - Input value in fields
         - Click on Save and Close button
         - Verify value
     */
    ('#42218: Copy Dossier Progress with duplicate Code', async t => {
        const create41 = new ManageDossierProgress()
        const create42 = new ManageDossierProgress()

        //Create the first Dossier Progress
        await dosPro.createDossierProgress(create41.codeValue, create41.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Create the second Dossier Progress
        await dosPro.createDossierProgress(create42.codeValue, create42.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Copy the first Dossier Progress
        await dosPro.filterDossierProgress(create41.codeValue)
        await dosPro.copyDossierProgress(create42.codeValue, create42.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Assert
        await t
            .expect(detailsSelector.errorMessage.innerText).contains('Dieses Kurzzeichen existiert bereits')
            .click(detailsSelector.closeErrorMessage)
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete the first Dossier Progress
        await dosPro.filterDossierProgress(create41.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
        //Delete the second Dossier Progress
        await t.click(indexSelector.clearFilterBtn)
        await dosPro.filterDossierProgress(create42.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')

    })

test.meta({ type: 'advance' })
    /*Scenario #42219: Copy Dossier Progress with Code more than 50 characters
         - Create new Dossier Progress
         - Open form to copy it
         - Fill value in fields
         - Click on Save and Close button
         - Verify value
     */
    ('#42219: Copy Dossier Progress with Code more than 50 characters', async t => {
        const create5 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create5.codeValue, create5.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        // Copy Dossier Progress
        await dosPro.filterDossierProgress(create5.codeValue)
        await dosPro.copyDossierProgress('Test new code Test new codeTest new codeTest new codeTest new codeTest new code', 'Text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 50 Zeichen')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete Dossier Progress
        await dosPro.filterDossierProgress(create5.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')

    })

test.meta({ type: 'advance' })
    /*Scenario #42220: Copy Dossier Progress with blank Name
         - Create new Dossier Progress
         - Open form to copy it
         - Leave Name field blank
         - Click on Save and Close button
         - Verify value
     */
    ('#42220: Copy Dossier Progress with blank Name', async t => {
        const create6 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create6.codeValue, create6.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Copy Dossier Progress
        await dosPro.filterDossierProgress(create6.codeValue)
        await dosPro.copyDossierProgress('Dossier Progress', ' ')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Dieses Feld ist erforderlich')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete Dossier Progress
        await dosPro.filterDossierProgress(create6.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })

test.meta({ type: 'advance' })
    /*Scenario #42221: Copy Dossier Progress with Name more than 254 characters
         - Create new Dossier Progress
         - Open form to copy it
         - Fill value in fields
         - Click on Save and Close button
         - Verify value
     */
    ('#42221: Copy Dossier Progress with Name more than 254 characters', async t => {
        const create7 = new ManageDossierProgress()

        //Create Dossier Progress
        await dosPro.createDossierProgress(create7.codeValue, create7.nameValue)
        await t.click(detailsSelector.saveCloseBtn)
        //Copy Dossier Progress
        await dosPro.filterDossierProgress(create7.codeValue)
        await dosPro.copyDossierProgress('Dossier Progress', 'Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text Test Payment Text')
        await t.click(detailsSelector.saveCloseBtn)
        //Assert 
        await t
            .expect(detailsSelector.vldMessage.innerText).contains('Die maximale Länge beträgt 254 Zeichen')
        //Back to Dossier Progress list
        await t.click(detailsSelector.backBtn)
        //Delete Dossier Progress
        await dosPro.filterDossierProgress(create7.codeValue)
        await dosPro.deleteDossierProgress()
        await t.expect(indexSelector.dossierProgresTable.innerText).contains('Keine Daten zum Anzeigen')
    })