import { Selector, t } from "testcafe"
import DossierProgressIndexSelector from "../selectors/dossier-progress.index.selector"
import DossierProgressDetailSelector from "../selectors/dossier-progress.detail.selector"
import Utils from "../../../../../commons/utils"

const indexSelector = new DossierProgressIndexSelector()
const detailsSelector = new DossierProgressDetailSelector()
const randomData = new Utils();


export default class ManageDossierProgress {
    constructor() {
        this.codeValue = randomData.getText('DP_Code', 15)
        this.nameValue = randomData.getText('DP_Name', 15)

    }
    async filterDossierProgress(code) {
        await t
            .click(indexSelector.filterBox)
            .pressKey('ctrl+a delete')
            .typeText(indexSelector.filterBox, code)
            .pressKey('enter')
    }

    async createDossierProgress(code, name) {
        await t
            .click(indexSelector.addBtn)
            .typeText(detailsSelector.codeBox, code)
            .typeText(detailsSelector.nameBox, name)
    }

    async editDossierProgress(code, name) {
        await t
            .click(indexSelector.editBtn)
            .click(detailsSelector.codeBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.codeBox, code)
            .click(detailsSelector.nameBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.nameBox, name)
    }

    async copyDossierProgress(code, name) {
        await t
            .click(indexSelector.editBtn)
            .click(detailsSelector.copyBtn)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.codeBox, code)
            .click(detailsSelector.nameBox)
            .pressKey('ctrl+a delete')
            .typeText(detailsSelector.nameBox, name)
    }

    async deleteDossierProgress() {
        await t
            .click(indexSelector.deleteBtn)
            .click(indexSelector.confirmDeleteBtn)
    }

}
