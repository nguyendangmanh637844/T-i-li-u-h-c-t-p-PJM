
import { Selector } from "testcafe";

export default class PageLogoutSelector {
    constructor() {
        this.userProfileBtn = Selector(".dropdown-toggle.nav-link.pt-1")
        this.logoutDropdown = Selector('a').withText('Ausloggen')
    }
}
