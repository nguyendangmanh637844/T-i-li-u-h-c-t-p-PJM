import { Selector, t } from "testcafe";
import Configuration from "../../../commons/configuration";
import LoginPage from "../../authentication/functions/login-page";
import PageCustomizeTermsSelector from "../selectors/page.customize-term.selector";
import CustomizeTerm from "../functions/customize-term";

const config = new Configuration();
const objectLogin = new LoginPage();

const custom_term = new PageCustomizeTermsSelector();
const customTerm = new CustomizeTerm();

fixture`Customize terms`.page(config.UrlAdmin).beforeEach(async (t) => {
  await config.configBeforeEach();
  await t.wait(3000);
});

test.meta({ type: "base" })(
  "#32435: Check update term successfully",
  async (t) => {
    let rowIndex = 2;
    custom_term.valueTermBox = Selector(
      "tbody tr:nth-of-type(" + rowIndex + ") td:nth-of-type(2) input"
    );
    custom_term.resetBtn = Selector('tr:nth-of-type('+rowIndex+') #btn-revert');
    //Login
    await objectLogin.login(config.UserName, config.Password);
    //Select term to edit
    await customTerm.selectTerm(rowIndex);
    //InitialValue of selected term
    let initialValue = await custom_term.valueTermBox.value;
    //Update value for selected term
    await customTerm.updateTerm("update_term");
    //Verify new value of term displayed
    await t.expect(custom_term.valueTermBox.value).eql("update_term");
    await t
      .click(custom_term.resetBtn)
      .expect(custom_term.valueTermBox.value)
      .eql(initialValue);
  }
);

test.meta({ type: "advance" })(
  "#32436: Check update term with blank value",
  async (t) => {
    let rowIndex = 2;
    custom_term.valueTermBox = Selector(
      "tbody tr:nth-of-type(" + rowIndex + ") td:nth-of-type(2) input"
    );
    custom_term.resetBtn = Selector('tr:nth-of-type('+rowIndex+') #btn-revert');
    //Login
    await objectLogin.login(config.UserName, config.Password);
    //Select term to edit
    await customTerm.selectTerm(rowIndex);
    //InitialValue of selected term
    let initialValue = await custom_term.valueTermBox.value;
    //Update value for selected term
    await customTerm.updateTerm(" ");
    //Verify new value of term displayed
    await t.expect(custom_term.valueTermBox.value).eql(" ");
    await t
      .click(custom_term.resetBtn)
      .expect(custom_term.valueTermBox.value)
      .eql(initialValue);
  }
);

test.meta({ type: "advance" })(
  "#32437: Check update term with value more than 254 characters",
  async (t) => {
    let rowIndex = 2;
    custom_term.valueTermBox = Selector(
      "tbody tr:nth-of-type(" + rowIndex + ") td:nth-of-type(2) input"
    );
    custom_term.resetBtn = Selector('tr:nth-of-type('+rowIndex+') #btn-revert');
    //Login
    await objectLogin.login(config.UserName, config.Password);
    //Select term to edit
    await customTerm.selectTerm(rowIndex);
    //Update value for selected term
    await customTerm.updateTerm(
      "Customize term with valid value Customize term with valid value Customize term with valid value Customize term with valid value Customize term with valid value  Customize term with valid value Customize term with valid value  Customize term with valid value  Customize term with valid value"
    );
    //Verify message appear
    await t.expect(custom_term.alerMsg.innerText).contains("254 Zeichen");
  }
);

test.meta({ type: "base" })("#32435: Check cancel update term", async (t) => {
  let rowIndex = 2;
    custom_term.valueTermBox = Selector(
      "tbody tr:nth-of-type(" + rowIndex + ") td:nth-of-type(2) input"
    );
    custom_term.resetBtn = Selector('tr:nth-of-type('+rowIndex+') #btn-revert');
    custom_term.editBtn = Selector("tr:nth-of-type(" + rowIndex + ") #btn-edit");
  //Login
  await objectLogin.login(config.UserName, config.Password);
  //Select term to edit
  await customTerm.selectTerm(rowIndex);
  //InitialValue of selected term
  let initialValue = await custom_term.valueTermBox.value;
  //Update value for selected term
  await customTerm.updateTerm("update_term");
  //Cancel update term
  await t
    .click(custom_term.editBtn)
    .typeText(custom_term.valueTermBox, "CheckCancel")
    .click(custom_term.cancelBtn)
    .wait(3000);
  //Verify new value of term displayed
  await t.expect(custom_term.valueTermBox.value).eql("update_term");
  await t
    .click(custom_term.resetBtn)
    .expect(custom_term.valueTermBox.value)
    .eql(initialValue);
});
