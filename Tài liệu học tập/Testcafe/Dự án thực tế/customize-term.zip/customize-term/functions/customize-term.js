import { Selector, t } from "testcafe";
import PageCustomizeTermsSelector from "../selectors/page.customize-term.selector";

const custom_term = new PageCustomizeTermsSelector();
class CustomizeTerm {
  async selectTerm(rowIndex) {
    custom_term.editBtn = Selector("tr:nth-of-type(" + rowIndex + ") #btn-edit");
    custom_term.valueTermBox = Selector(
      "tbody tr:nth-of-type(" + rowIndex + ") td:nth-of-type(2) input"
    );
    await t.click(custom_term.customizeTermMenu);
    await t.click(custom_term.editBtn);
  }

  async updateTerm(value) {
    await t
      .pressKey("ctrl+a delete")
      .typeText(custom_term.valueTermBox, value)
      .click(custom_term.updateBtn)
      .wait(3000);
  }
}
export default CustomizeTerm;
