import { Selector } from "testcafe";

export default class PageIndexSelector {
    constructor() {
        //Begin menu bar
        this.manageSettingContextMenu = Selector('a').withExactText('Kontext einstellen');
        //begin-manage account screenn
        this.addBtn = Selector('#btn-addNew');
        this.searchBox = Selector(".dxbs-grid-filter-row .dxbs-grid-table-border-bottom:nth-of-type(1) .dxbs-form-control");
        this.editBnt = Selector('#btn-edit');
        this.deleteBtn = Selector('#btn-delete');
        this.confirmDeleteBtn = Selector('#btn-confirm-yes');
        this.cancelDeleteBtn = Selector('#btn-confirm-no');
        //end-manage accounts screen 

        //begin-manage-customer screen
        this.settingContextTable = Selector('.dxbs-scroll-viewer-content')
        //end-manage-customer screen

        //begin-label layout
        this.userProfileBtn = Selector('.navbar-nav .dropdown:nth-of-type(2)');
        this.userSettingBtn = Selector('a').withAttribute('class', 'dropdown-item btn');
        this.labelDropdown = Selector('select').withAttribute('class', 'form-control-sm w-100');
        this.regularLabel = Selector('option').withAttribute('value', 'Regular');
        this.floatingLabel = Selector('option').withAttribute('value', 'Floating');
        this.automaticLabel = Selector('option').withAttribute('value', 'Automatic');
        this.closeLabelBtn = Selector('#btn-close-alert');
        //end-label layout
    }
};