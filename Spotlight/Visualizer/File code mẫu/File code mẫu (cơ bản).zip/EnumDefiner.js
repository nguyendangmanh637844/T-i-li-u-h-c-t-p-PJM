//default Skins
const DEFAULT_SKIN = {
  ListBox: "listBoxBorder",
  Button: "skinDefaultButton",
  Link: "btnLink",
  TextBox: "texBoxSkin",
  TextArea: "textAreaSkinDefault",
  SuccessToast: "sknflxSuccessToast1F844D",
  ErrorToast: "sknFlxErrorToastBgE61919",
  WarningToast: "sknFlxWarningToastBgCF9C37",
  BoldLabel: "titleInfor",
  FlexScrollContainer: "skinScrollContainer",
  InforPopup: "sknflxebb54cOp100",
  WarningPopup: "skinFlxWarningPopup",
};
const TOAST_MODE = {
  Success: 1,
  Error: 2,
  Warning: 3
};
const ORIENTATION = {
  Vertical: 1,
  Horizontal: 2
};
const FUND_TRANSFER_STATUS = {
  Open: "OPEN",
  AmlChecked: "AML_CHECKED",
  OnHold: "ONHOLD",
  Rejected: "REJECTED",
  Accepted: "ACCEPTED",
  Comfirmed: "CONFIRMED",
  Completed: "COMPLETED",
  NotCompleted: "NOT_COMPLETED",
  Closed: "CLOSED",
  All: "ALL",
  Expired: "OVERTIME",
};
const PAYMENT_MODEL = {
  Centralized1: "CENTRALIZED1",
  Centralized2: "CENTRALIZED2",
  Decentralized: "DECENTRALIZED"
};
const PAYMENT_MODEL_NAME = {
  CENTRALIZED1: "Tập trung",
  CENTRALIZED2: "Tập trung",
  DECENTRALIZED: "Phi tập trung",
};
const DOCUMENT_TYPE = {
  CustomerUpload: "CUSTOMER_UPLOAD",
  StaffUpload: "STAFF_UPLOAD"
};
const CHECK_RESULT = {
  ValidRecords: "VALID_RECORDS",
  SupplementalRecords: "SUPPLEMENTAL_RECORDS",
  RejectedRecords: "REJECTED_RECORDS"
};
const APPROVAL_STATUS = {
  Approved: "APPROVED",
  NotApproved: "NOT_APPROVED"
};
const CHECK_PCRT = {
  NOT_VIOLATION: "Không vi phạm",
  VIOLATION: "Vi phạm",
  PROVIDE_MORE_INFORMATION: "Ch\u1EDD cung cấp thêm thông tin"
};
const BANK_OF_CHINA = [
  "BANK OF CHINA ABU DHABI BRANCH",
  "BANK OF CHINA (DUBAI) BRANCH",
  "BANK OF CHINA LIMITED LUANDA BRANCH",
  "BANK OF CHINA LIMITED SUCURSAL BUENOS AIRES",
  "BANK OF CHINA (CENTRAL AND EASTERN EUROPE) LIMITED VIENNA BRANCH",
  "BANK OF CHINA (AUSTRALIA) LIMITED",
  "BANK OF CHINA LIMITED, SYDNEY BRANCH",
  "BANK OF CHINA",
  "BANK OF CHINA (EUROPE) S.A. BRUSSELS BRANCH",
  "BANK OF CHINA (HONG KONG) LIMITED, BRUNEI BRANCH",
  "BANK OF CHINA BRASIL S.A.",
  "BANK OF CHINA TORONTO BRANCH",
  "BANK OF CHINA (CANADA)",
  "BANK OF CHINA LIMITED, GENEVA BRANCH",
  "BANK OF CHINA, AGENCIA EN CHILE",
  "BANK OF CHINA GUANGDONG BRANCH",
  "BANK OF CHINA GUANGZHOU BRANCH",
  "BANK OF CHINA (CEE) LTD. PRAGUE BRANCH",
  "BANK OF CHINA, PARIS BRANCH",
  "BANK OF CHINA (UK) LIMITED",
  "BANK OF CHINA (EUROPE) S.A. ATHENS BRANCH",
  "BANK OF CHINA (HONG KONG) LIMITED",
  "BANK OF CHINA LIMITED HONG KONG BR",
  "BANK OF CHINA (CEE) LTD.",
  "BANK OF CHINA LIMITED HUNGARIAN BRANCH",
  "BANK OF CHINA, JAKARTA BRANCH",
  "BANK OF CHINA (EUROPE) S.A. DUBLIN BRANCH",
  "BANK OF CHINA INDIA BRANCH",
  "BANK OF CHINA,MILAN BRANCH",
  "BANK OF CHINA (HONG KONG) LIMITED PHNOM PENH BRANCH",
  "BANK OF CHINA SEOUL BRANCH",
  "BANK OF CHINA, GRAND CAYMAN BRANCH",
  "BANK OF CHINA KAZAKHSTAN",
  "BANK OF CHINA LIMITED VIENTIANE BRANCH",
  "BANK OF CHINA LIMITED COLOMBO BRANCH",
  "BANK OF CHINA (EUROPE) S.A.",
  "BANK OF CHINA, LUXEMBOURG BRANCH",
  "BANK OF CHINA (HONG KONG) LIMITED YANGON BRANCH",
  "BANK OF CHINA (MACAU) LIMITED",
  "BANK OF CHINA, MACAU BRANCH",
  "BANK OF CHINA (MAURITIUS) LIMITED",
  "BANK OF CHINA MEXICO, SA, INSTITUCION DE BANCO MULTIPLE",
  "BANK OF CHINA (MALAYSIA) BERHAD",
  "BANK OF CHINA (EUROPE) S.A., ROTTERDAM BRANCH",
  "BANK OF CHINA (NEW ZEALAND) LIMITED",
  "BANK OF CHINA LIMITED, AUCKLAND BRANCH",
  "BANK OF CHINA, PANAMA BRANCH",
  "BANK OF CHINA (PERU) S.A.",
  "BANK OF CHINA, MANILA BRANCH",
  "BANK OF CHINA LIMITED KARACHI BRANCH",
  "BANK OF CHINA (EUROPE) S.A. POLAND BRANCH",
  "BANK OF CHINA ( EUROPE) S.A. LISBON BRANCH - SUCURSAL EM PORTUGAL",
  "BANK OF CHINA LIMITED QATAR FINANCIAL CENTRE BRANCH",
  "BANK OF CHINA (CENTRAL AND EASTERN EUROPE) LIMITED BUCHAREST BRANCH",
  "BANK OF CHINA SRBIJA A.D. BEOGRAD",
  "BANK OF CHINA (RUSSIA)",
  "BANK OF CHINA (EUROPE) S.A. STOCKHOLM BRANCH",
  "BANK OF CHINA LIMITED",
  "BANK OF CHINA (THAI) PUBLIC COMPANY LIMITED",
  "BANK OF CHINA TURKEY A.S.",
  "BANK OF CHINA LIMITED TAIPEI BRANCH",
  "BANK OF CHINA (HONG KONG) LIMITED-HO CHI MINH CITY BRANCH",
  "BANK OF CHINA JOHANNESBURG BRANCH",
  "BANK OF CHINA (ZAMBIA) LTD",
  "BANK OF CHINA INTERNATIONAL (UK) LIMITED",
  "BANK OF CHINA INTERNATIONAL LIMITED",
  "BANK OF CHINA INVESTMENT MANAGEMENT"
];

const CHINA_CONTRUCTION_BANK = [
  "CHINA CONSTRUCTION BANK (BRASIL) BANCO MULTIPLO S/A",
  "CHINA CONSTRUCTION BANK (BRASIL) BANCO MULTIPLO S /A",
  "CHINA CONSTRUCTION BANK CORPORATION",
  "CHINA CONSTRUCTION BANK (ASIA) CORPORATION LIMITED",
  "CHINA CONSTRUCTION BANK CORPORATION MACAU BRANCH",
  "CHINA CONSTRUCTION BANK DIFC BRANCH",
  "CHINA CONSTRUCTION BANK CORPORATION SYDNEY BRANCH",
  "CHINA CONSTRUCTION BANK TORONTO BRANCH",
  "CHINA CONSTRUCTION BANK CORPORATION, BEIJING, SWISS BRANCH ZURICH",
  "CHINA CONSTRUCTION BANK, AGENCIA EN CHILE",
  "CHINA CONSTRUCTION BANK",
  "CHINA CONSTRUCTION BANK (EUROPE) S.A. SUCURSAL EN ESPANA",
  "CHINA CONSTRUCTION BANK (EUROPE) S.A., PARIS BRANCH",
  "CHINA CONSTRUCTION BANK CORPORATION LONDON BRANCH",
  "CHINA CONSTRUCTION BANK (LONDON) LIMITED",
  "CHINA CONSTRUCTION BANK (EUROPE) S.A. HUNGARY BRANCH",
  "CHINA CONSTRUCTION BANK (EUROPE) SA - SEDE SECONDARIA IN ITALIA",
  "CHINA CONSTRUCTION BANK CORPORATION TOKYO BRANCH",
  "CHINA CONSTRUCTION BANK SEOUL BRANCH",
  "CHINA CONSTRUCTION BANK CORPORATION ASTANA BRANCH",
  "CHINA CONSTRUCTION BANK (EUROPE) S.A.",
  "CHINA CONSTRUCTION BANK CORPORATION LUXEMBOURG BRANCH",
  "CHINA CONSTRUCTION BANK CORPORATION LABUAN BRANCH",
  "CHINA CONSTRUCTION BANK (MALAYSIA) BERHAD",
  "CHINA CONSTRUCTION BANK (EUROPE) S.A., AMSTERDAM BRANCH",
  "CHINA CONSTRUCTION BANK LTD",
  "CHINA CONSTRUCTION BANK CORPORATION NEW ZEALAND BRANCH",
  "CHINA CONSTRUCTION BANK(EUROPE)WARSAW BRANCH",
  "CHINA CONSTRUCTION BANK CORPORATION, SINGAPORE BRANCH",
  "CHINA CONSTRUCTION BANK CORPORATION LTD. TAIPEI BRANCH",
  "CHINA CONSTRUCTION BANK NEW YORK BRANCH",
  "CHINA CONSTRUCTION BANK CORPORATION HO CHI MINH CITY BRANCH",
  "CHINA CONSTRUCTION BANK CORPORATION JOHANNESBURG BRANCH"
];

const INDUSTRIAL_AND_COMMERCIAL_BANK_OF_CHINA = [
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED-ABU DHABI BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED, DUBAI(DIFC) BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA (ARGENTINA) S.A.U",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA SYDNEY BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA (EUROPE) S.A., BRUSSELS BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA(BRAZIL)",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA (CANADA)",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LTD,BEIJING, ZURICH BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED HAINAN BRANCH(FT)",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED, PRAGUE BRANCH, ODSTEPNY ZAVOD",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LTD.",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA(EUROPE)S.A.,SUCURSAL EN ESPANA",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA (EUROPE) S.A., PARIS BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED LONDON BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA, HONG KONG BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA MUMBAI BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA (EUROPE) S.A. MILAN BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA, TOKYO BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA SEOUL BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED VIENTIANE BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED, LIMITED, LUXEMBOURG BRANCH (RMB CLEARING BANK)",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LTD., LUXEMBOURG BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA (EUROPE) S.A.",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA YANGON BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA, MACAU BRANCH",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA (MACAU) LIMITED",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA MEXICO, S.A.",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA (MALAYSIA) BERHAD.",
  "INDUSTRIAL AND COMMERCIAL BANK OF CHINA (EUROPE) S.A. AMSTERD"
];
const NOSTRO_ACCOUNT_NUMBER = {
  MashreqBank: "223000002125",
  HabibBank: "227000000491",
};
const APPROVAL_LEVEL_STATUS = {
  Resolved: 0,
  Rejected: -1
};
const LEVEL_DEFINITION = {
  DecentralizedUpdateDocument: "DECENTRALIZED_UPDATE_DOCUMENT", //Luồng phi tập chung, cấp cho phép bổ sung hồ sơ
  CentralizedUpdateDocument: "CENTRALIZED_UPDATE_DOCUMENT" //Luồng tập trung, cấp cho phép bổ sung hồ sơ
};
const FIELD_CHANGE = {
  customerAddress: "\u0111ịa chỉ",
  customerAddressEn: "\u0111ịa chỉ (tiếng anh)",
  beneficiaryAddress: "\u0111ịa chỉ ngư\u1EDDi thụ hưởng",
  beneficiaryAddressEn: "\u0111ịa chỉ ngư\u1EDDi thụ hưởng (tiếng anh)",
  beneficiaryBankAddress: "\u0111ịa chỉ ngân hàng thụ hưởng",
  paymentNote: "Nội dung thanh toán",
  paymentNoteEn: "Remitance information",
  resultCheck: "Kết quả kiểm tra",
  problemType: "Lý do",
  otherProblem: "Mô tả lý do chi tiết",
  feedbackDvkd: "Phản hồi của \u0111VKD",
  isException: "Hồ sơ",
  isDocumentsDebt: "Nợ chứng từ",
  attachFiles: "Hồ sơ khác",
  paymentModel: "Mô hình thanh toán",
  pcrtBranch: "Kiểm tra PCRT",
  senderToReceiverInfo: "Sender to Receiver Infor",
  nostroAcountNumber: "Tài khoản Nostro",
  regulatoryReporting: "Regulatory Reporting",
  swiftMt103: "Swift MT 103 sent to",
  assigne: "Ngư\u1EDDi \u0111ược phân công",
  approvalLevel: "Trạng thái phê duyệt",
  feedbackTtTtqt: "Phản hồi của TT TTQT",
  status: "Trạng thái",
  feedbackDvkd: "Phản hồi của DVKD",
  customerNameEn: "Tên khách hàng (Tiếng anh)",
  beneficiaryIdNumber:
    "Số giấy t\u1EDD của du h\u1ECFc sinh/ngư\u1EDDi bệnh/ngư\u1EDDi \u0111i du lịch/thân nhân ở nước ngoài",
  beneficiaryBankIdentifierCode: "Số Routing/UID/Fedwire/SortCode/Khác",
  beneficiaryName: "Tên ngư\u1EDDi thụ hưởng",
  extraCode: "BSB/Transit/Sort code/Khác",
  assignLog: "Ngư\u1EDDi xử lý",
  countryCode: "Quốc gia (theo ngân hàng)",
  cifNumber: "Số CIF",
  customerName: "Tên khách hàng",
  customerType: "Loại khách hàng",
  relationship: "Mối quan hệ của ngư\u1EDDi chuyển ti\u1EC1n với Du h\u1ECFc sinh/Ngư\u1EDDi bệnh/Ngư\u1EDDi \u0111i công tác/Du lịch/Thăm viếng/Thân nhân ở nước ngoài",
  beneficiaryNameEn: "Tên ngư\u1EDDi thụ hư\u1EDDng (Tiếng anh)",
  beneficiaryNameEn: "\u0111ịa chỉ ngư\u1EDDi thụ hưởng (Tiếng anh)",
  beneficiaryAccountNumber: "Số tài khoản",
  beneficiaryBank: "Ngân hàng thụ hưởng",
  swiftCode: "Swift code",
  intermediaryBankCode: "Swiftcode ngân hàng trung gian",
  intermediaryBankName: "Tên ngân hàng trung gian",
  customerId: "Id khách hàng",
  customerPhone: "Số \u0111iện thoại khách hàng",
  manualSwiftCode: "Nhập thủ công",
  foreinCurrency: "Loại ti\u1EC1n tệ",
  foreinAmount: "Số ti\u1EC1n trong hồ sơ \u0111ăng kí",
  confirmationDate: "Ngày xác nhận giao dịch",
  branchName: "Tên chi nhánh",
  paymentNoteEn: "Nội dung thanh toán (Tiếng anh)",
  branchCode: "Mã chi nhánh",
  transferCode: "Mã hồ sơ",
  swiftCodeValid: "Mã swift code có hợp lệ hay không",
  transferPurposeId: "Mã mục \u0111ích",
  documents: "Hồ sơ",
  ft: "Số FT",
  customerType: "Phân loại khách hàng",
  beneficiaryCountryCode: "Mã quốc gia ngư\u1EDDi thụ hưởng",
  customerAccountType: "Loại tài khoản ngư\u1EDDi chuyển",
  customerCountryCode: "Quốc gia của ngư\u1EDDi chuyển",
  customerPostcode: "Mã bưu chính ngư\u1EDDi chuyển",
  customerIdentificationType: "Loại giấy tờ tùy thân",
  channelCode: "Kênh giao dịch",
  localConversionCurrency: "Ngoại tệ chuyển đổi",
  customerCity: "Thành phố ngư\u1EDDi chuyển",
  customerState: "Bang ngư\u1EDDi chuyển",
  customerIdentificationNumber: "Số giấy t\u1EDD tùy thân",
  customerDob: "Ngày sinh của ngư\u1EDDi chuyển",
  routingCodeType: "Loại mã ngân hàng hưởng",
  beneficiaryAccountType: "Loại tài khoản ngư\u1EDDi thụ hưởng",
  beneficiaryBankAccountType: "Loại tài khoản ngân hàng ngư\u1EDDi hưởng",
  beneficiaryCity: "Thành phố ngư\u1EDDi thụ hưởng",
  beneficiaryState: "Bang ngư\u1EDDi thụ hưởng",
  beneficiaryPostcode: "Mã bưu chính ngư\u1EDDi thụ hưởng",
};
const DECENTERLIZED_MONEY_LIMIT = 50000;
const CENTERLIZED_MONEY_LIMIT = 200000;
const ROLE = {
  GDV: "GDV",
  KSV: "KSV",
  CVTTQT: "CVTTQT",
  LDDV: "LDDV",
  C1: "C1",
  C2: "C2",
  ADMIN: "ADMIN"
};
const ROLE_CAN_UPDATE_FIELD = {
  lbKetQuaKiemTra: [ROLE.GDV, ROLE.CVTTQT],
  txtMoTaLyDoChiTiet: [ROLE.GDV, ROLE.KSV, ROLE.CVTTQT],
  txtPhanHoiCuaDVKD: [ROLE.GDV, ROLE.KSV, ROLE.LDDV],
  txtPhanHoiCuaTTTTQT: [ROLE.CVTTQT, ROLE.C1, ROLE.C2]
};
const STATUS_RECORD = [
  [FUND_TRANSFER_STATUS.All, "Tất cả"],
  [FUND_TRANSFER_STATUS.Open, FUND_TRANSFER_STATUS.Open],
  [FUND_TRANSFER_STATUS.OnHold, FUND_TRANSFER_STATUS.OnHold],
  [FUND_TRANSFER_STATUS.Rejected, FUND_TRANSFER_STATUS.Rejected],
  [FUND_TRANSFER_STATUS.Accepted, FUND_TRANSFER_STATUS.Accepted],
  [FUND_TRANSFER_STATUS.Comfirmed, FUND_TRANSFER_STATUS.Comfirmed],
  [FUND_TRANSFER_STATUS.Closed, FUND_TRANSFER_STATUS.Closed],
  [FUND_TRANSFER_STATUS.Completed, FUND_TRANSFER_STATUS.Completed],
  [FUND_TRANSFER_STATUS.NotCompleted, FUND_TRANSFER_STATUS.NotCompleted],
];
const SEPARATOR_SENDER_TO_RECEIVE = "^.^";
const T24_RESTRICT_CHARACTER = `*&%$#@!_?><{}[]“”‘’\\'"^`;
const LIST_STATUS_APPROVAL = {
  Gdv: "Ch\u1EDD GDV cập nhật",
  Ksv: "Ch\u1EDD KSV kiểm soát",
  Lddv: "Ch\u1EDD PD của L\u0110 chi nhánh",
  Cvttqt: "Ch\u1EDD CV TTQT kiểm tra",
  C1: "Ch\u1EDD PD tại TTQT",
  C2: "Ch\u1EDD PD2 tại TTQT"
};
const DEFAULT_COUNTRY_CODE = "";
const STATUS_ADD_DOCUMENT = [
  FUND_TRANSFER_STATUS.Closed,
  FUND_TRANSFER_STATUS.Rejected,
  FUND_TRANSFER_STATUS.Accepted,
  FUND_TRANSFER_STATUS.Comfirmed,
  FUND_TRANSFER_STATUS.Completed
];
const ACTION_STEP_NAME = {
  ganHoSo: "ganHoSo",
  chuyenCapDuyet: "chuyenCapDuyet",
  taiLenHoSo: "taiLenHoSo",
  phanHoi: "phanHoi",
  duyet: "duyet",
  capNhatThuCong: "capNhatThuCong",
  khachHangTao: "khachHangTao",
  khachHangCapNhat: "khachHangCapNhat",
  khachHangXacNhan: "khachHangXacNhan",
  ketQuaChuyenTien: "ketQuaChuyenTien"
};
const MAPPING_ACTION_STEP = {
  ganHoSo: "Gán hồ sơ",
  chuyenCapDuyet: "Chuyển cấp duyệt",
  taiLenHoSo: "Tải lên hồ sơ",
  phanHoi: "Phản hồi",
  duyet: "Duyệt",
  capNhatThuCong: "Cập nhật thủ công",
  khachHangTao: "Khách hàng tạo",
  khachHangCapNhat: "Khách hàng cập nhật",
  khachHangXacNhan: "Khách hàng xác nhận",
  ketQuaChuyenTien: "Kết quả chuyển tiền"
};
const CUSTOMER_TYPES = {
  RESIDENT: "Cư trú",
  NONRESIDENT: "Không cư trú",
  FOREIGNER: "Người nước ngoài",
}
const CHANNEL = {
  NiumLocal: "NIUM_LOCAL",
  NiumSwift: "NIUM_SWIFT",
  Nostro: "NOSTRO",
}