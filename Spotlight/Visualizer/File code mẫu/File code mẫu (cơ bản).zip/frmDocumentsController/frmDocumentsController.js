define({
  dataSearch: { name: "", orderBy: "", isDESC: false },
  documentData: {
    name: "",
    sampleLink: "",
    acceptFileType: "",
    maxFileSize: 0,
  },
  form: {
    txtName: {},
    txtSampleLink: {},
    txtAcceptFileType: {},
    txtMaxFileSize: {},
  },
  heightRow: 30,
  buttonsWidth: 50,
  isNew: true,
  preShowActions() {
    this.view.subHeader.tbxSearchBox.onTextChange = ({ text }) => {
      this.dataSearch.name = text;
      this.dataSearch.orderBy = "";
      this.dataSearch.isDESC = false;
      this.search();
    };
    this.view.mainHeader.btnDropdownList.onClick = () => {
      this.view.lblPopUpMainMessage.text = "Thêm hồ sơ";
      this.isNew = true;
      this.showDetail();
    };
    this.view.lblFontTitle.onClick = () => {
      this.dataSearch.orderBy = "name";
      this.dataSearch.isDESC = !this.dataSearch.isDESC;
      this.search();
    };
    this.view.lblFontCode.onClick = () => {
      this.dataSearch.orderBy = "sample_link";
      this.dataSearch.isDESC = !this.dataSearch.isDESC;
      this.search();
    };
    this.view.CopylblFontTitle0b93ccbd3514544.onClick = () => {
      this.dataSearch.orderBy = "accept_file_type";
      this.dataSearch.isDESC = !this.dataSearch.isDESC;
      this.search();
    };
    this.view.CopylblFontTitle0g77e35c0cb2e4c.onClick = () => {
      this.dataSearch.orderBy = "max_file_size";
      this.dataSearch.isDESC = !this.dataSearch.isDESC;
      this.search();
    };
    this.view.btnPopUpSave.onClick = () => {
      this.save();
    };
    this.view.btnPopUpCancel.onClick = () => {
      this.cancel();
    };
    this.view.fontIconImgCLose.onClick = () => {
      this.cancel();
    };
    this.createUIFormAddEdit();
  },

  postShowActions() {},

  willUpdateUI(model) {
    this.updateLeftMenu(model);
    this.updateUserName();
    this.updateContent(model);
    this.view.forceLayout();
  },
  updateUserName() {
    this.view.dropdownMainHeader.lblUserName.text =
      "Hello, " +
      kony.mvc.MDAApplication.getSharedInstance().appContext.userName;
  },
  updateContent(model) {
    const self = this;
    switch (model.context) {
      case "getDocuments":
        this.setSegmentData(model.data);
        $hideLoading(this.view);
        break;
      case "getDocumentsError":
        if (model.httpStatusCode === 204) this.setSegmentData([]);
        $hideLoading(this.view);
        this.showErrorMessage();
        break;
      case "createDocument":
        this.dataSearch = { name: "", orderBy: "", isDESC: false };
        this.showSuccessMessage();
        this.search();
        break;
      case "createDocumentError":
        this.dataSearch = { name: "", orderBy: "", isDESC: false };
        this.showErrorMessage();
        this.search();
        break;
      case "updateDocument":
        this.dataSearch = { name: "", orderBy: "", isDESC: false };
        this.showSuccessMessage();
        this.search();
        break;
      case "updateDocumentError":
        this.dataSearch = { name: "", orderBy: "", isDESC: false };
        this.showErrorMessage();
        this.search();
        break;
    }
  },
  showSuccessMessage(message = "Success") {
    $showToastMessage(
      this.view.flxToastMessage,
      this.view.toastMessage.flxToastContainer,
      message,
      TOAST_MODE.Success
    );
  },
  showErrorMessage(message = "Error") {
    $showToastMessage(
      this.view.flxToastMessage,
      this.view.toastMessage.flxToastContainer,
      message,
      TOAST_MODE.Error
    );
  },
  // Hàm xử lý
  createUIFormAddEdit() {
    this.view.flxContainer.removeAll();
    const container = $createFlexContainer(this.view.flxContainer, {
      height: this.heightRow * 6 + "px",
      top: this.heightRow + "px",
    });
    this.view.flxContainer.height = container.height;
    this.form.txtName = $createTextArea();
    this.form.txtSampleLink = $createTextBox();
    this.form.txtAcceptFileType = $createTextBox();
    this.form.txtMaxFileSize = $createTextBox({
      inputMode: constants.TEXTBOX_INPUT_MODE_NUMERIC,
    });
    const content = [
      [$createLabel("Tên hồ sơ", { left: "20px" }), this.form.txtName],
      [
        $createLabel("Đường dẫn mẫu", { left: "20px" }),
        this.form.txtSampleLink,
      ],
      [
        $createLabel("Loại tệp chấp nhận", { left: "20px" }),
        this.form.txtAcceptFileType,
      ],
      [
        $createLabel("Kích thước tối đa", { left: "20px" }),
        this.form.txtMaxFileSize,
      ],
    ];
    content.push([]);
    const formAddEdit = $createTable(container, content, {
      heightRow: this.heightRow + "px",
      evenWidth: "60%",
      oddWidth: "40%",
    });
  },
  search() {
    this.presenter.getDocuments(this.dataSearch);
  },
  setSegmentData(documents) {
    this.view.flxPopupContainer.isVisible = false;
    if (documents.length > 0) {
      this.view.segDocuments.isVisible = true;
      this.view.lblNoData.isVisible = false;
      var data = [];
      if (typeof documents !== "undefined") {
        data = documents.map((row) => {
          return {
            documentName: row.name,
            sampleLink: row.sampleLink,
            acceptFileType: row.acceptFileType,
            maxFileSize: row.maxFileSize,
            lblSeparator: "-",
            template: "flxDocuments",
            fonticonActive: {
              isVisible: true,
              text: "",
              onClick: () => {
                this.view.lblPopUpMainMessage.text = "Sửa hồ sơ";
                this.isNew = false;
                this.documentData = row;
                this.showDetail(row);
              },
            },
          };
        });
      }
      var dataMap = {
        documentName: "documentName",
        sampleLink: "sampleLink",
        acceptFileType: "acceptFileType",
        maxFileSize: "maxFileSize",
        lblSeparator: "lblSeparator",
        flxDocuments: "flxDocuments",
        fonticonActive: "fonticonActive",
      };
      this.view.segDocuments.widgetDataMap = dataMap;
      this.view.segDocuments.setData(data);
    } else {
      this.view.segDocuments.isVisible = false;
      this.view.lblNoData.isVisible = true;
    }
  },
  showDetail(data = null) {
    this.view.flxPopupContainer.isVisible = true;
    if (data) {
      this.setData(data);
    } else {
      const defaultData = {
        name: "",
        sampleLink: "",
        acceptFileType: "",
        maxFileSize: 0,
      };
      this.setData(defaultData);
    }
  },
  setData(data) {
    this.form.txtName.text = data.name;
    this.form.txtSampleLink.text = data.sampleLink;
    this.form.txtAcceptFileType.text = data.acceptFileType;
    this.form.txtMaxFileSize.text = data.maxFileSize;
  },
  cancel() {
    this.view.flxPopupContainer.isVisible = false;
    // this.dataSearch = { name: "", orderBy: "", isDESC: false };
    // this.documentData = {
    //   name: "",
    //   sampleLink: "",
    //   acceptFileType: "",
    //   maxFileSize: 0,
    // };
    // this.isNew = true;
    // this.search();
  },
  save() {
    const body = {
      name: this.form.txtName.text,
      sampleLink: this.form.txtSampleLink.text,
      acceptFileType: this.form.txtAcceptFileType.text,
      maxFileSize: this.form.txtMaxFileSize.text,
    };
    $showLoading(this.view);
    if (this.isNew) {
      this.presenter.createDocument(body);
    } else {
      const payload = { ...this.documentData, ...body };
      $validatePayload(payload);
      this.presenter.updateDocument(payload);
    }
  },
});
