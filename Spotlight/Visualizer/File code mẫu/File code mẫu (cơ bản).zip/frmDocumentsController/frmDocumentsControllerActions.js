define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for frmDocuments **/
    AS_Form_a50d093701df455284e0250f11dd913c: function AS_Form_a50d093701df455284e0250f11dd913c(eventobject) {
        var self = this;
        this.postShowActions();
    },
    /** preShow defined for frmDocuments **/
    AS_Form_ad94787526de4269b34557cd45cea94e: function AS_Form_ad94787526de4269b34557cd45cea94e(eventobject) {
        var self = this;
        this.preShowActions();
    }
});