define(["ErrorInterceptor", "ErrorIsNetworkDown", "Promisify"], function (
  ErrorInterceptor,
  isNetworkDown,
  Promisify
) {
  function Documents_PresentationController() {
    kony.mvc.Presentation.BasePresenter.call(this);
    this.context = {};
    this.model = {};
  }

  inheritsFrom(
    Documents_PresentationController,
    kony.mvc.Presentation.BasePresenter
  );

  Documents_PresentationController.prototype.initializePresentationController =
    function () {
      var self = this;
      ErrorInterceptor.wrap(this, "businessController").match(function (on) {
        return [
          on(isNetworkDown).do(function () {
            self.presentUserInterface("frmDocuments", {
              NetworkDownMessage: {},
            });
          }),
        ];
      });
    };
  //Documents
  Documents_PresentationController.prototype.getDocuments = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getDocuments";
      self.model.data = response.data;
      self.presentUserInterface("frmDocuments", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getDocumentsError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.presentUserInterface("frmDocuments", self.model);
    }
    this.businessController.getDocuments(
      param,
      successCallback,
      failureCallback
    );
  };
  Documents_PresentationController.prototype.createDocument = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "createDocument";
      self.model.data = response.data;
      self.presentUserInterface("frmDocuments", self.model);
    }

    function failureCallback(error) {
      self.model.context = "createDocumentError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.presentUserInterface("frmDocuments", self.model);
    }
    this.businessController.createDocument(
      param,
      successCallback,
      failureCallback
    );
  };
  Documents_PresentationController.prototype.updateDocument = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "updateDocument";
      self.model.data = response.data;
      self.presentUserInterface("frmDocuments", self.model);
    }

    function failureCallback(error) {
      self.model.context = "updateDocumentError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.presentUserInterface("frmDocuments", self.model);
    }
    this.businessController.updateDocument(
      param,
      successCallback,
      failureCallback
    );
  };
  return Documents_PresentationController;
});
