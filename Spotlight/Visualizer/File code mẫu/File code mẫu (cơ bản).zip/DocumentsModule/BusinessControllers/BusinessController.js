define([],function () {

    function DocumentsModule_BusinessController(){
        kony.mvc.Business.Delegator.call(this);
    }

    inheritsFrom(DocumentsModule_BusinessController, kony.mvc.Business.Delegator);
    
    DocumentsModule_BusinessController.prototype.initializeBusinessController = function(){
    };
    DocumentsModule_BusinessController.prototype.getDocuments = function (
        options,
        onSuccess,
        onError
      ) {
        kony.mvc.MDAApplication.getSharedInstance()
          .getModuleManager()
          .getModule("DocumentsManager")
          .businessController.getDocuments(options, onSuccess, onError);
      };
      DocumentsModule_BusinessController.prototype.createDocument = function (
        options,
        onSuccess,
        onError
      ) {
        kony.mvc.MDAApplication.getSharedInstance()
          .getModuleManager()
          .getModule("DocumentsManager")
          .businessController.createDocument(options, onSuccess, onError);
      };
      DocumentsModule_BusinessController.prototype.updateDocument = function (
        options,
        onSuccess,
        onError
      ) {
        kony.mvc.MDAApplication.getSharedInstance()
          .getModuleManager()
          .getModule("DocumentsManager")
          .businessController.updateDocument(options, onSuccess, onError);
      };
    return DocumentsModule_BusinessController;
});