function $createTable(
  form,
  contentArray,
  options = {
    widthColumn: null,
    heightRow: null,
    oddSkin: null,
    evenSkin: null,
    oddWidth: null,
    evenWidth: null,
    oddHeight: null,
    evenHeight: null,
  }
) {
  const numRows = contentArray.length;
  const numColumns = Math.max(...contentArray.map((arr) => arr.length));
  const defaultWidth = Math.floor(100 / numColumns) + "%";
  const defaultHeight = Math.floor(100 / numRows) + "%";
  const table = $createScrollFlexContainer(null, {
    top: "0",
    left: "0",
    width: "100%",
    height: "100%",
    layoutType: kony.flex.FREE_FORM,
    justifyContent: kony.flex.START,
    alignItems: kony.flex.START,
  });
  var topCell = 0;
  var leftCell = 0;
  var preWidth = [];
  var preHeight = [];
  var cells = [];
  for (var i = 0; i < numRows; i++) {
    const height =
      options.heightRow ||
      (i % 2 === 0
        ? options.oddHeight || defaultHeight
        : options.evenHeight || defaultHeight);
    topcell =
      i === 0
        ? 0
        : (topCell =
          topCell === 0
            ? preHeight.pop()
            : $addUnit(topCell, preHeight.pop()));
    preHeight.push(height);
    for (var j = 0; j < numColumns; j++) {
      const cellContent = contentArray[i][j] || null;
      const width =
        options.widthColumn ||
        (j % 2 === 0
          ? options.oddWidth || defaultWidth
          : options.evenWidth || defaultWidth);

      leftCell =
        j === 0
          ? 0
          : leftCell === 0
            ? preWidth.pop()
            : $addUnit(leftCell, preWidth.pop());
      preWidth.push(width);
      // console.error(`[${i}][${j}] top: ${topCell}, left: ${leftCell}`);
      const cell = $createScrollFlexContainer(null, {
        top: topCell,
        left: leftCell,
        width: width,
        height: height,
        skin: j % 2 === 0 ? options.oddSkin : options.evenSkin,
      });
      if (cellContent !== null) {
        cell.add(cellContent);
      }
      cells.push(cell);
      table.add(cell);
    }
  }
  form.add(table);
  return cells;
}
function $createListTable(
  form,
  leftColumOptions = {
    title: null,
    titleSkin: null,
    titleLeft: null,
    titleRight: null,
    titleTop: null,
    titleBottom: null,
    titleCenterX: null,
    titleCenterY: null,
    height: null,
    skin: null,
    width: null,
  },
  rightColumOptions = {
    data: [],
    rowHeight: null,
    columnHeight: null,
    width: null,
    skin: null,
  }
) {
  //Left column
  var leftContainer = new kony.ui.FlexContainer({
    width: leftColumOptions.width || "50%",
    height: leftColumOptions.height || rightColumOptions.columnHeight || "100%",
    skin: leftColumOptions.skin,
    top: "0",
  });
  const label = $createLabel(leftColumOptions.title, {
    skin: leftColumOptions.titleSkin,
    left: leftColumOptions.titleLeft,
    right: leftColumOptions.titleRight,
    centerX: leftColumOptions.titleCenterX,
    centerY: leftColumOptions.titleCenterY,
    top: leftColumOptions.titleTop,
    bottom: leftColumOptions.titleBottom,
  });
  leftContainer.add(label);
  form.add(leftContainer);

  //Right column
  var totalHeight = null;
  var rightContainer = new kony.ui.FlexScrollContainer({
    width: rightColumOptions.width || "50%",
    height: rightColumOptions.columnHeight || "100%",
    left: leftColumOptions.width || "50%",
    skin: rightColumOptions.skin,
    top: "0",
    clipBounds: true,
    layoutType: kony.flex.FREE_FORM,
    scrollingEnabled: true,
  });
  for (let i = 0; i < rightColumOptions.data.length; i++) {
    const heightCell =
      rightColumOptions.rowHeight ||
      Math.floor(100 / rightColumOptions.data.length) + "%";
    var topFlx = $multiUnit(heightCell, i);
    var flxCell = new kony.ui.FlexContainer({
      width: rightColumOptions.width || "100%",
      height: heightCell,
      skin: rightColumOptions.skin,
      top: topFlx,
    });
    flxCell.add(rightColumOptions.data[i]);
    if (i === rightColumOptions.data.length - 1) {
      totalHeight = $addUnit(flxCell.height, flxCell.top);
    }
    rightContainer.add(flxCell);
  }
  if ($isGreaterThan(totalHeight, rightContainer.height)) {
    rightContainer.skin += " " + DEFAULT_SKIN.FlexScrollContainer;
  }
  form.add(rightContainer);
}
function $createLabel(
  labelText = "",
  options = {
    toolTip: null,
    skin: null,
    isBold: null,
    left: null,
    right: null,
    top: null,
    bottom: null,
    centerX: null,
    centerY: null,
  }
) {
  const label = new kony.ui.Label(
    {
      text: labelText,
      centerY: options.centerY || "50%",
      left: options.left || "5px",
      right: options.right,
      top: options.top,
      bottom: options.bottom,
      centerX: options.centerX,
      skin: options.skin,
    },
    {}
  );
  if (options.isBold || false) {
    label.skin = label.skin
      ? `${label.skin} ${DEFAULT_SKIN.BoldLabel}`
      : DEFAULT_SKIN.BoldLabel;
  }
  label.toolTip = options.toolTip || "";
  return label;
}
function $validatePayload(payload) {
  delete payload.lastmodifiedts;
  delete payload.modifiedby;
  delete payload.createdts;
  delete payload.createdby;
}
function $createFlexContainer(
  parentFlx = null,
  options = {
    width: null,
    height: null,
    top: null,
    bottom: null,
    left: null,
    right: null,
    centerX: null,
    centerY: null,
    skin: null,
    isModelContainer: null,
    onClick: null,
  }
) {
  const flx = new kony.ui.FlexContainer({
    centerY: options.centerY,
    width: options.width || "100%",
    height: options.height || "100%",
    centerX: options.centerX,
    left: options.left,
    right: options.right,
    top: options.top,
    bottom: options.bottom,
    skin: options.skin,
    isModelContainer: options.isModelContainer || false,
    onClick: options.onClick || function () { },
  });
  if (parentFlx) parentFlx.add(flx);
  return flx;
}
function $createScrollFlexContainer(
  parentFlx = null,
  options = {
    width: null,
    height: null,
    top: null,
    bottom: null,
    left: null,
    right: null,
    centerX: null,
    centerY: null,
    skin: null,
    isModelContainer: null,
    onClick: null,
  }
) {
  const flx = new kony.ui.FlexScrollContainer({
    centerY: options.centerY,
    width: options.width || "100%",
    height: options.height || "100%",
    centerX: options.centerX,
    left: options.left,
    right: options.right,
    top: options.top,
    bottom: options.bottom,
    skin: `${options.skin} ${DEFAULT_SKIN.FlexScrollContainer}`.trim(),
    isModelContainer: options.isModelContainer || false,
    onClick: options.onClick || function () { },
  });
  if (parentFlx) parentFlx.add(flx);
  return flx;
}
function $createListBox(
  displayArray,
  keyArray = [],
  options = {
    width: null,
    height: null,
    centerX: null,
    centerY: null,
    left: null,
    right: null,
    top: null,
    bottom: null,
    skin: null,
    multiSelect: null,
    padding: null,
    isEnable: null,
    isVisible: null,
  },
  onSelection = (listBox) => { },
) {
  const listBox = new kony.ui.ListBox(
    {
      centerY: options.centerY || "50%",
      width: options.width || "80%",
      height: options.height || "80%",
      centerX: options.centerX,
      left: options.left,
      right: options.right,
      top: options.top,
      bottom: options.bottom,
      skin: options.skin || DEFAULT_SKIN.ListBox,
      multiSelect: options.multiSelect || false,
      padding: options.padding,
      masterData: [],
    },
    {}
  );
  // Tạo các tùy chọn từ mảng truyền vào
  const masterData = [];
  for (let i = 0; i < displayArray.length; i++) {
    const option = [keyArray[i] || "key_" + i, displayArray[i]];
    masterData.push(option);
  }
  listBox.masterData = masterData;
  listBox.setEnabled(
    $isNullOrEmpty(options.isEnable) ? true : options.isEnable
  );
  listBox.isVisible = $isNullOrEmpty(options.isVisible)
    ? true
    : options.isVisible;
  return listBox;
}
function $createRadioGroup(
  displayArray,
  keyArray = [],
  options = {
    centerX: null,
    centerY: null,
    right: null,
    bottom: null,
    top: null,
    left: null,
    width: null,
    height: null,
    skin: null,
    orientation: ORIENTATION.Horizontal,
    isEnable: null,
    isVisible: null,
  }
) {
  const radioGroup = new kony.ui.RadioButtonGroup(
    {
      top: options.top,
      left: options.left,
      width: options.width || "100%",
      height: options.height || "80%",
      centerX: options.centerX,
      centerY: options.centerY || "50%",
      right: options.right,
      bottom: options.bottom,
      masterData: [],
      skin: options.skin,
    },
    {}
  );
  radioGroup.itemorientation = options.orientation;
  // Tạo các radio button từ mảng truyền vào
  const masterData = [];
  for (let i = 0; i < displayArray.length; i++) {
    const radioOption = [keyArray[i] || "key_" + i, displayArray[i]];
    masterData.push(radioOption);
  }
  radioGroup.masterData = masterData;
  radioGroup.setEnabled(
    $isNullOrEmpty(options.isEnable) ? true : options.isEnable
  );
  radioGroup.isVisible = $isNullOrEmpty(options.isVisible)
    ? true
    : options.isVisible;
  return radioGroup;
}
function $createCheckBoxGroup(
  displayArray,
  keyArray = [],
  options = {
    centerX: null,
    centerY: null,
    right: null,
    bottom: null,
    top: null,
    left: null,
    width: null,
    height: null,
    skin: null,
    orientation: ORIENTATION.Horizontal,
    isEnable: null,
    isVisible: null,
  }
) {
  const checkBoxGroup = new kony.ui.CheckBoxGroup(
    {
      top: options.top,
      left: options.left,
      width: options.width || "100%",
      height: options.height || "80%",
      centerX: options.centerX,
      centerY: options.centerY || "50%",
      right: options.right,
      bottom: options.bottom,
      masterData: [],
      skin: options.skin,
    },
    {}
  );
  checkBoxGroup.itemorientation = options.orientation;
  // Tạo các check box từ mảng truyền vào
  const masterData = [];
  for (let i = 0; i < displayArray.length; i++) {
    const radioOption = [keyArray[i] || "key_" + i, displayArray[i]];
    masterData.push(radioOption);
  }
  checkBoxGroup.masterData = masterData;
  checkBoxGroup.setEnabled(
    $isNullOrEmpty(options.isEnable) ? true : options.isEnable
  );
  checkBoxGroup.isVisible = $isNullOrEmpty(options.isVisible)
    ? true
    : options.isVisible;
  return checkBoxGroup;
}
function $createButton(
  text,
  onClick = null,
  options = {
    top: null,
    left: null,
    centerX: null,
    centerY: null,
    right: null,
    bottom: null,
    width: null,
    height: null,
    skin: null,
    contentAlignment: null,
    isLink: false,
    padding: null,
    maxWidth: null,
    maxHeight: null,
    minWidth: null,
    minHeight: null,
    isEnable: null,
    isVisible: null,
  }
) {
  const button = new kony.ui.Button(
    {
      top: options.top,
      left: options.left,
      centerX: options.centerX,
      centerY: options.centerY || "50%",
      right: options.right,
      bottom: options.bottom,
      width: options.width || "80%",
      height: options.height || "80%",
      text: text,
      skin: options.skin || DEFAULT_SKIN.Button,
      onClick: onClick || function () { },
      contentAlignment: options.contentAlignment,
      padding: options.padding || [2, 2, 2, 2],
      maxWidth: options.maxWidth,
      maxHeight: options.maxHeight,
      minWidth: options.minWidth,
      minHeight: options.minHeight,
    },
    {}
  );
  // constants.CONTENT_ALIGN_TOP_LEFT
  // constants.CONTENT_ALIGN_TOP_CENTER
  // constants.CONTENT_ALIGN_TOP_RIGHT
  // constants.CONTENT_ALIGN_MIDDLE_LEFT
  // constants.CONTENT_ALIGN_CENTER
  // constants.CONTENT_ALIGN_MIDDLE_RIGHT
  // constants.CONTENT_ALIGN_BOTTOM_LEFT
  // constants.CONTENT_ALIGN_BOTTOM_CENTER
  // constants.CONTENT_ALIGN_BOTTOM_RIGHT
  if (options.maxWidth || options.minWidth) button.width = null;
  if (options.maxHeight || options.minHeight) button.height = null;
  if (options.isLink) {
    button.skin = DEFAULT_SKIN.Link;
    button.width = null;
    return button;
  }
  button.contentAlignment = constants.CONTENT_ALIGN_TOP_CENTER;
  button.setEnabled($isNullOrEmpty(options.isEnable) ? true : options.isEnable);
  button.isVisible = $isNullOrEmpty(options.isVisible)
    ? true
    : options.isVisible;
  return button;
}
function $createTextBox(
  options = {
    placeHolder: null,
    text: null,
    top: null,
    left: null,
    right: null,
    bottom: null,
    centerY: null,
    centerX: null,
    width: null,
    height: null,
    skin: null,
    padding: null,
    maxLength: null,
    isAllowSpecialCharacter: null,
    secureTextEntry: null, // kí tự cho mật khẩu
    inputMode: null, //constants.TEXTBOX_INPUT_MODE_NUMERIC, constants.TEXTBOX_INPUT_MODE_DATETIME
    textContentType: null, //TEXTBOX_TEXT_CONTENT_TYPE_USERNAME, TEXTBOX_TEXT_CONTENT_TYPE_PASSWORD, TEXTBOX_TEXT_CONTENT_TYPE_OTP
    textCopyable: null, //Cho phép enable cut, copy
    restrictCharactersSet: null, //Set các kí tự sẽ bị ngăn chặn
    isEnable: null,
    isVisible: null,
    isAllowAccents: null, //cho phép nhập dấu tiếng Việt
  },
  onTextChange = (textbox) => { },
) {
  const textBox = new kony.ui.TextBox2(
    {
      top: options.top,
      left: options.left,
      centerX: options.centerX,
      centerY: options.centerY || "50%",
      right: options.right,
      bottom: options.bottom,
      width: options.width || "80%",
      height: options.height || "80%",
      padding: options.padding || [2, 2, 2, 2],
      skin: options.skin || DEFAULT_SKIN.TextBox,
      text: options.text || "",
      maxTextLength: options.maxLength,
      inputMode: options.inputMode || constants.TEXTBOX_INPUT_MODE_ANY,
      textContentType:
        options.textContentType || constants.TEXTBOX_TEXT_CONTENT_TYPE_DEFAULT,
      textCopyable: options.textCopyable || false,
      restrictCharactersSet: options.restrictCharactersSet,
    },
    {}
  );
  textBox.placeholder = options.placeHolder || "";
  if (
    !($isNullOrEmpty(options.isAllowSpecialCharacter)
      ? true
      : options.isAllowSpecialCharacter)
  ) {
    textBox.restrictCharactersSet = "~`!@#$%^&*()-_=+[]{}\\|;:'\",<.>/?";
  }
  textBox.setEnabled(
    $isNullOrEmpty(options.isEnable) ? true : options.isEnable
  );
  textBox.isVisible = $isNullOrEmpty(options.isVisible)
    ? true
    : options.isVisible;
  if (typeof onTextChange === "function") {
    textBox.onTextChange = (txt) => {
      if (
        !($isNullOrEmpty(options.isAllowAccents) ? true : options.isAllowAccents)
      ) {
        const text = $trim(txt.text);
        if ($isContainsVietnamese(text)) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh.");
          return;
        }
      }
      onTextChange(txt);
    };
  }
  return textBox;
}
function $isContainsVietnamese(text) {
  var vietnameseRegex = /[\u00C0-\u1EF9\u1EFA-\u1EFF]/; // Biểu thức chính quy để kiểm tra ký tự tiếng Việt

  return vietnameseRegex.test(text);
}
function $i18n(key) {
  if ($isNullOrEmpty(key)) return "";
  return kony.i18n.getLocalizedString(key) || "";
}
function $createSearchBoxForTextBox(
  textbox, // truyền vào text box muốn tạo search box
  cssProperties = {
    right: 0,
    width: "100%",
    top: 0,
    left: 0,
    bottom: 0,
    maxHeight: "100%",
  }, // truyền vào các thuộc tính css cho ul
  filterList, // Danh sách dữ liệu filter
  displayColumns = [], // các trường hiển thị ra
  valueColumn, // trường giá trị khi click vào
  tagertElement, // add ô text box vào vị trí DOM nào
  callback = (elementClick) => { },
  soLuongBanGhiHienThi = 10,
) {
  const textboxHTMLList = document.querySelectorAll(
    '[id*="' + textbox.id + '"]'
  );
  const textboxHTML = textboxHTMLList[0];
  const ulID = $generateElementId(30);
  textboxHTML.addEventListener("input", function () {
    var input = textboxHTML.value.toLowerCase();
    if ($isNullOrEmpty(input)) {
      var oldUl = document.getElementById(ulID);
      if (oldUl) {
        oldUl.remove();
      }
      return;
    }
    var filteredSuggestions = filterList.filter(function (obj) {
      for (var i = 0; i < displayColumns.length; i++) {
        var field = displayColumns[i];
        if (
          obj[field] &&
          obj[field].toString().toLowerCase().includes(input.toLowerCase())
        ) {
          return true;
        }
      }
      return false;
    });

    // Xóa các gợi ý cũ
    var oldUl = document.getElementById(ulID);
    if (oldUl) {
      oldUl.remove();
    }
    if (filteredSuggestions.length === 0) return;
    // Tạo phần tử ul mới
    var ul = document.createElement("ul");
    ul.id = ulID;
    // Tạo các phần tử li mới cho các gợi ý
    filteredSuggestions
      .slice(0, soLuongBanGhiHienThi)
      .forEach(function (suggestion) {
        var li = document.createElement("li");
        // Sự kiện khi hover vào
        li.addEventListener("mouseover", function () {
          this.style.backgroundColor = "#0075ff";
          this.style.cursor = "pointer";
          this.style.color = "white";
        });
        // Sự kiện khi di chuột ra
        li.addEventListener("mouseout", function () {
          this.style.backgroundColor = "white";
          this.style.cursor = "default";
          this.style.color = "black";
        });
        li.style.padding = "5px";
        var displayText = $isNullOrEmpty(displayColumns)
          ? ""
          : displayColumns.map((column) => suggestion[column]).join(" - ");
        li.textContent = displayText;
        li.textValue = $isNullOrEmpty(valueColumn)
          ? ""
          : suggestion[valueColumn];
        li.addEventListener("click", function () {
          textbox.text = li.textValue;
          if (typeof callback === "function") {
            const obj = filterList.filter(value => value[valueColumn] === li.textValue);
            if (obj.length !== 1) options.label.text = "";
            callback(obj[0]);
          };
          var oldUl = document.getElementById(ulID);
          if (oldUl) {
            oldUl.remove();
          }
        });
        ul.appendChild(li);
      });
    for (var property in cssProperties) {
      if (cssProperties.hasOwnProperty(property)) {
        ul.style[property] = cssProperties[property];
      }
    }
    if ($isNullOrEmpty(cssProperties.backgroundColor))
      ul.style.backgroundColor = "white";
    if ($isNullOrEmpty(cssProperties.overflowY)) ul.style.overflowY = "auto";
    if ($isNullOrEmpty(cssProperties.maxHeight)) ul.style.maxHeight = "200px";
    if ($isNullOrEmpty(cssProperties.position)) ul.style.position = "relative";
    if ($isNullOrEmpty(cssProperties.zIndex)) ul.style.zIndex = "100";
    if ($isNullOrEmpty(cssProperties.zIndex))
      ul.style.border = "1px solid #454545";
    ul.style.cursor = "pointer";
    // Gắn ul vào DOM
    const parent = document.querySelectorAll(
      '[id*="' + tagertElement.id + '"]'
    );
    parent[0].appendChild(ul);
  });
}
function $createTextArea(
  options = {
    placeHolder: null,
    text: null,
    top: null,
    left: null,
    right: null,
    bottom: null,
    centerY: null,
    centerX: null,
    width: null,
    height: null,
    skin: null,
    padding: null,
    maxLength: null,
    isAllowSpecialCharacter: null,
    secureTextEntry: null, // kí tự cho mật khẩu
    inputMode: null, //constants.TEXTBOX_INPUT_MODE_NUMERIC, constants.TEXTBOX_INPUT_MODE_DATETIME
    textContentType: null, //TEXTBOX_TEXT_CONTENT_TYPE_USERNAME, TEXTBOX_TEXT_CONTENT_TYPE_PASSWORD, TEXTBOX_TEXT_CONTENT_TYPE_OTP
    textCopyable: null, //Cho phép enable cut, copy
    restrictCharactersSet: null, //Set các kí tự sẽ bị ngăn chặn
    isEnable: null,
    isVisible: null,
    isAllowAccents: null,
  }
) {
  const textBox = new kony.ui.TextArea2(
    {
      top: options.top,
      left: options.left,
      centerX: options.centerX,
      centerY: options.centerY || "50%",
      right: options.right,
      bottom: options.bottom,
      width: options.width || "80%",
      height: options.height || "80%",
      padding: options.padding || [1, 1, 1, 1],
      skin: options.skin || DEFAULT_SKIN.TextArea,
      text: options.text || "",
      maxTextLength: options.maxLength,
      inputMode: options.inputMode || constants.TEXTBOX_INPUT_MODE_ANY,
      textContentType:
        options.textContentType || constants.TEXTBOX_TEXT_CONTENT_TYPE_DEFAULT,
      textCopyable: options.textCopyable || false,
      restrictCharactersSet: options.restrictCharactersSet,
    },
    {}
  );
  textBox.placeholder = options.placeHolder || "";
  if (
    !($isNullOrEmpty(options.isAllowSpecialCharacter)
      ? true
      : options.isAllowSpecialCharacter)
  ) {
    textBox.restrictCharactersSet = "~`!@#$%^&*()-_=+[]{}\\|;:'\",<.>/?";
  }
  textBox.setEnabled(
    $isNullOrEmpty(options.isEnable) ? true : options.isEnable
  );
  textBox.isVisible = $isNullOrEmpty(options.isVisible)
    ? true
    : options.isVisible;
  const isAddEvent = !($isNullOrEmpty(options.isAllowAccents)
    ? true
    : options.isAllowAccents);
  if (isAddEvent) {
    textBox.onKeyUp = ({ text }) => {
      text = $removeAccents(text);
    };
  }
  return textBox;
}
function $showToastMessage(
  flxToastMessage,
  flxToastContainer,
  toastText,
  mode = TOAST_MODE.Success,
  duration = 2 // đơn vị giây
) {
  if (mode === TOAST_MODE.Success) {
    flxToastContainer.skin = DEFAULT_SKIN.SuccessToast;
    flxToastContainer.fontIconImgLeft.text = "\ue944";
  }
  if (mode === TOAST_MODE.Error) {
    flxToastContainer.skin = DEFAULT_SKIN.ErrorToast;
    flxToastContainer.fontIconImgLeft.text = "\ue94b";
  }
  if (mode === TOAST_MODE.Warning) {
    flxToastContainer.skin = DEFAULT_SKIN.WarningToast;
    flxToastContainer.fontIconImgLeft.text = "\ue94b";
  }
  flxToastContainer.lbltoastMessage.text = toastText;
  flxToastContainer.flxRightImage.onClick = function () {
    $hideToastMessage(flxToastMessage);
  };
  flxToastMessage.setVisibility(true);
  var animationDefinition = {
    0: {
      bottom: "-70px",
    },
    100: {
      bottom: "0px",
    },
  };
  var animationConfiguration = {
    duration: 0.5,
    fillMode: kony.anim.FILL_MODE_FORWARDS,
  };
  const closeToast = function () {
    $hideToastMessage(flxToastMessage);
  };
  var callbacks = {
    animationEnd: function () {
      kony.timer.schedule("toastMessageTimer", closeToast, duration, false);
    },
  };
  var animationDef = kony.ui.createAnimation(animationDefinition);
  flxToastMessage.animate(animationDef, animationConfiguration, callbacks);
}
function $hideToastMessage(flxToastMessage) {
  var animationDefinition = {
    0: {
      bottom: "0px",
    },
    100: {
      bottom: "-70px",
    },
  };
  var animationConfiguration = {
    duration: 0.5,
    fillMode: kony.anim.FILL_MODE_FORWARDS,
  };
  var callbacks = {
    animationEnd: function () {
      flxToastMessage.setVisibility(false);
    },
  };
  var animationDef = kony.ui.createAnimation(animationDefinition);
  flxToastMessage.animate(animationDef, animationConfiguration, callbacks);
}
function $dockHeaderForDataGrid(element) {
  element.style.position = "sticky";
  element.style.top = "-1px";
  element.style.height = "50px";
}
function $removeAccents(inputString) {
  var str = inputString.toString();
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/gi, "a");
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/gi, "e");
  str = str.replace(/ì|í|ị|ỉ|ĩ/gi, "i");
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/gi, "o");
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/gi, "u");
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/gi, "y");
  str = str.replace(/đ/gi, "d");
  return str;
}
function $showLoading(view) {
  kony.adminConsole.utils.showProgressBar(view);
}
function $hideLoading(view) {
  kony.adminConsole.utils.hideProgressBar(view);
}
function $setStyle(element, cssProperties) {
  if (!element.id) {
    console.error("element truyền vào không có id.");
    return;
  }
  var elements = document.querySelectorAll('[id*="' + element.id + '"]');
  if (elements.length !== 1) return;
  for (var property in cssProperties) {
    if (cssProperties.hasOwnProperty(property)) {
      if (cssProperties[property].includes("!important")) {
        elements[0].style.setProperty(property, cssProperties[property].replace("!important", "").trim(), "important");
      }
      else {
        elements[0].style[property] = cssProperties[property];
      }
    }
  }
}
function $generateRandomNumber(min, max) {
  // Kiểm tra tính hợp lệ của khoảng
  if (min >= max) {
    throw new Error("Khoảng không hợp lệ. Vui lòng đảm bảo min < max.");
  }
  // Tính toán số tự nhiên ngẫu nhiên trong khoảng
  const randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
  return randomNumber;
}
function $isEmptyObject(obj) {
  return Object.keys(obj).length === 0;
}
function $convertToDDMMYYYY(dateString) {
  if (dateString === "") return "";
  const date = new Date(dateString);

  const day = ("0" + date.getDate()).slice(-2);
  const month = ("0" + (date.getMonth() + 1)).slice(-2);
  const year = date.getFullYear();

  const formattedDate = `${day}/${month}/${year}`;
  return formattedDate;
}
function $convertToYYYYMMDD(dateString) {
  if (dateString === "") return "";
  const date = new Date(dateString);

  const day = ("0" + date.getDate()).slice(-2);
  const month = ("0" + (date.getMonth() + 1)).slice(-2);
  const year = date.getFullYear();

  const formattedDate = `${year}/${month}/${day}`;
  return formattedDate;
}
function $convertToHmsDDMMYYYY(dateTimeString) {
  if (dateTimeString === "") return "";
  const dateTime = new Date(dateTimeString);

  const year = dateTime.getFullYear();
  const month = String(dateTime.getMonth() + 1).padStart(2, "0");
  const day = String(dateTime.getDate()).padStart(2, "0");

  const hours = String(dateTime.getHours()).padStart(2, "0");
  const minutes = String(dateTime.getMinutes()).padStart(2, "0");
  const seconds = String(dateTime.getSeconds()).padStart(2, "0");

  const formattedDateTime = `${hours}:${minutes}:${seconds} ${day}/${month}/${year}`;
  return formattedDateTime;
}
function $downloadFileFromUrl(url) {
  let request = new XMLHttpRequest();
  request.open("GET", url, true);
  request.responseType = "blob";

  request.onload = function () {
    if (request.status === 200) {
      let file_name = url.split("/").pop();
      let blob = request.response;
      let link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = file_name;
      link.click();
    } else {
      console.log("Không thể tải xuống ảnh");
    }
  };

  request.send();
}
function $findDifferentFields(obj1, obj2, isObjReturn = false) {
  const differentFields = isObjReturn ? {} : [];

  // Kiểm tra và so sánh các giá trị của key trong obj1 và obj2
  for (let key in obj1) {
    if (obj1.hasOwnProperty(key)) {
      if (
        obj2.hasOwnProperty(key) &&
        ($isNonEmptyValue(obj1[key]) || $isNonEmptyValue(obj2[key])) &&
        obj1[key] !== obj2[key]
      ) {
        const oldValue = $convertToBoolean(obj1[key]);
        const newValue = $convertToBoolean(obj2[key]);
        if (oldValue !== newValue) {
          if (isObjReturn) {
            differentFields[key] = newValue;
          } else {
            differentFields.push({
              field: key,
              oldValue: oldValue,
              newValue: newValue,
            });
          }
        }
      }
    }
  }

  // Kiểm tra các key trong obj2 không tồn tại trong obj1
  for (let key in obj2) {
    if (
      obj2.hasOwnProperty(key) &&
      !obj1.hasOwnProperty(key) &&
      $isNonEmptyValue(obj2[key])
    ) {
      const newValue = $convertToBoolean(obj2[key]);
      if (isObjReturn) {
        differentFields[key] = newValue;
      } else {
        differentFields.push({
          field: key,
          oldValue: null,
          newValue: newValue,
        });
      }
    }
  }

  return differentFields;
}
function $createImage(
  source,
  options = {
    top: null,
    left: null,
    centerX: null,
    centerY: null,
    right: null,
    bottom: null,
    width: null,
    height: null,
    skin: null,
    padding: null,
    maxWidth: null,
    maxHeight: null,
    minWidth: null,
    minHeight: null,
  }
) {
  const image = new kony.ui.Image2(
    {
      src: source,
      top: options.top,
      left: options.left,
      centerX: options.centerX,
      centerY: options.centerY || "50%",
      right: options.right,
      bottom: options.bottom,
      width: options.width || "80%",
      height: options.height || "80%",
      skin: options.skin || DEFAULT_SKIN.Image,
      padding: options.padding || [2, 2, 2, 2],
      maxWidth: options.maxWidth,
      maxHeight: options.maxHeight,
      minWidth: options.minWidth,
      minHeight: options.minHeight,
    },
    {}
  );
  return image;
}
function $isNonEmptyValue(value) {
  return value !== null && value !== undefined && value !== "";
}
function $isNullOrEmpty(value) {
  return value === null || value === undefined || value === "";
}
function $convertToBoolean(value) {
  if (value === "true") {
    return true;
  } else if (value === "false") {
    return false;
  } else {
    return value;
  }
}
function $getFileExtension(filename) {
  var extension = filename.split(".").pop();
  return extension;
}
function $getFileName(fullFileName) {
  var fileNameParts = fullFileName.split(".");
  var fileName = fileNameParts[0];
  return fileName;
}
function $parseFilePath(path) {
  const lastIndex = path.lastIndexOf("/");
  const directory = path.substring(0, lastIndex);
  const filename = path.substring(lastIndex + 1, path.lastIndexOf("."));
  const extension = path.substring(path.lastIndexOf(".") + 1);

  return {
    directory: directory,
    name: filename,
    type: extension,
  };
}

function $separateNumberAndLetters(inputString) {
  var number = parseInt(inputString.match(/\d+/g).join("")); // Chuyển các số thành số nguyên
  var letters = inputString.replace(/\d+/g, "").trim(); // Lấy các kí tự khác và loại bỏ khoảng trắng thừa
  return {
    number: Math.round(number),
    letters: letters,
  };
}
function $addUnit(unit1, unit2) {
  const character1 = $separateNumberAndLetters(unit1);
  const character2 = $separateNumberAndLetters(unit2);
  if (character1.letters !== character2.letters) {
    console.error(
      "Hai số không cùng đơn vị: " +
      character1.letters +
      ", " +
      character2.letters
    );
    return;
  }
  return character1.number + character2.number + character1.letters;
}
function $subtractUnit(unit1, unit2) {
  const character1 = $separateNumberAndLetters(unit1);
  const character2 = $separateNumberAndLetters(unit2);
  if (character1.letters !== character2.letters) {
    console.error(
      "Hai số không cùng đơn vị: " +
      character1.letters +
      ", " +
      character2.letters
    );
    return;
  }
  return character1.number - character2.number + character1.letters;
}
function $multiUnit(unit, heso) {
  const character = $separateNumberAndLetters(unit);
  return character.number * heso + character.letters;
}
function $divideUnit(unit, heso) {
  const character = $separateNumberAndLetters(unit);
  return character.number / heso + character.letters;
}
function $getRemainder(unit, heso) {
  const character = $separateNumberAndLetters(unit);
  return (character.number % heso) + character.letters;
}
function $isGreaterThan(unit1, unit2) {
  const character1 = $separateNumberAndLetters(unit1);
  const character2 = $separateNumberAndLetters(unit2);
  if (character1.letters !== character2.letters) {
    console.error(
      "Hai số không cùng đơn vị: " +
      character1.letters +
      ", " +
      character2.letters
    );
    return true;
  }
  return character1.number > character2.number;
}
function $isLessThan(unit1, unit2) {
  const character1 = $separateNumberAndLetters(unit1);
  const character2 = $separateNumberAndLetters(unit2);
  if (character1.letters !== character2.letters) {
    console.error(
      "Hai số không cùng đơn vị: " +
      character1.letters +
      ", " +
      character2.letters
    );
    return true;
  }
  return character1.number < character2.number;
}
function $isGreaterThanOrEqual(unit1, unit2) {
  const character1 = $separateNumberAndLetters(unit1);
  const character2 = $separateNumberAndLetters(unit2);
  if (character1.letters !== character2.letters) {
    console.error(
      "Hai số không cùng đơn vị: " +
      character1.letters +
      ", " +
      character2.letters
    );
    return true;
  }
  return character1.number >= character2.number;
}
function $isLessThanOrEqual(unit1, unit2) {
  const character1 = $separateNumberAndLetters(unit1);
  const character2 = $separateNumberAndLetters(unit2);
  if (character1.letters !== character2.letters) {
    console.error(
      "Hai số không cùng đơn vị: " +
      character1.letters +
      ", " +
      character2.letters
    );
    return true;
  }
  return character1.number <= character2.number;
}
function $trim(input) {
  return (input || "").trim();
}
function $formatMoney(amount) {
  if ($isNullOrEmpty(amount)) return "";
  var amountString = parseFloat(amount).toFixed(2).toString(); // Chuyển đổi thành dạng thập phân và giữ hai số sau dấu phẩy
  var parts = [];
  var decimalIndex = amountString.indexOf("."); // Xác định vị trí dấu chấm (nếu có)

  // Xử lý phần nguyên
  var integerPart = amountString.substring(
    0,
    decimalIndex !== -1 ? decimalIndex : amountString.length
  );
  for (var i = integerPart.length - 1; i >= 0; i -= 3) {
    var part = integerPart.slice(Math.max(0, i - 2), i + 1);
    parts.unshift(part);
  }

  // Xử lý phần thập phân (nếu có)
  var decimalPart =
    decimalIndex !== -1 ? amountString.substring(decimalIndex + 1) : "";
  if (decimalPart !== "") {
    amountString = parts.join(",") + "." + decimalPart;
  } else {
    amountString = parts.join(",");
  }

  return amountString;
}
function $saveToLocalStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.log("Lỗi khi lưu vào Local Storage:", error.message);
  }
}
function $getFromLocalStorage(key) {
  try {
    const value = localStorage.getItem(key);
    if (value === null) {
      return undefined;
    }
    return JSON.parse(value);
  } catch (error) {
    console.log("Lỗi khi lấy giá trị từ Local Storage:", error.message);
    return undefined;
  }
}
function $generateRandomString(length) {
  var characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
  var result = "";

  for (var i = 0; i < length; i++) {
    var randomIndex = Math.floor(Math.random() * characters.length);
    result += characters.charAt(randomIndex);
  }

  return result;
}
function $generateElementId(length) {
  var characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";
  var id = "";

  for (var i = 0; i < length; i++) {
    var randomIndex = Math.floor(Math.random() * characters.length);
    id += characters.charAt(randomIndex);
  }

  return id;
}
function $exportFileExcel(data, columnName, excelName) {
  const dataTable = [columnName, ...data];
  // Tạo nội dung XML Spreadsheet
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml +=
    '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:html="http://www.w3.org/TR/REC-html40">\n';
  xml += '  <Worksheet ss:Name="Sheet1">\n';
  xml += "    <Table>\n";

  // Thêm dữ liệu vào bảng
  dataTable.forEach((row) => {
    xml += "      <Row>\n";
    row.forEach((cell) => {
      xml += `        <Cell><Data ss:Type="String">${cell}</Data></Cell>\n`;
    });
    xml += "      </Row>\n";
  });

  // Kết thúc nội dung XML Spreadsheet
  xml += "    </Table>\n";
  xml += "  </Worksheet>\n";
  xml += "</Workbook>";

  // Tạo và tải xuống file Excel
  const blob = new Blob([xml], { type: "application/vnd.ms-excel" });
  const link = document.createElement("a");
  link.href = window.URL.createObjectURL(blob);
  link.download = excelName + ".xls";
  link.click();
}
function $toStringObj(obj) {
  if ($isEmptyObject(obj)) return {};
  if (typeof obj !== "object" || obj === null) {
    return obj;
  }
  const result = Array.isArray(obj) ? [] : {};
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      result[key] = obj[key] ? obj[key].toString() : "";
    }
  }
  return result;
}
function $isTimePassed(targetTime) {
  const now = new Date();

  // Tách giờ và phút từ chuỗi đầu vào (targetTime)
  const [targetHour, targetMinute] = targetTime.split(":").map(Number);

  // Thiết lập thời gian mục tiêu
  const targetDateTime = new Date(now);
  targetDateTime.setHours(targetHour, targetMinute, 0, 0);

  // Kiểm tra xem thời gian hiện tại có vượt qua thời gian mục tiêu hay không
  return now >= targetDateTime;
}
function $isHasCommonElement(arr1, arr2) {
  for (let i = 0; i < arr1.length; i++) {
    if (arr2.includes(arr1[i])) {
      return true;
    }
  }
  return false;
}
function $handleConvertBase64ToBlob(base64String, filename) {
  function base64ToBlob(base64, contentType) {
    var byteCharacters = atob(base64);
    var byteArrays = [];

    for (var offset = 0; offset < byteCharacters.length; offset += 512) {
      var slice = byteCharacters.slice(offset, offset + 512);
      var byteNumbers = new Array(slice.length);

      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      var byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays, { type: contentType });
    return blob;
  }
  var blob = base64ToBlob(
    base64String,
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  );
  var link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
}
function $addWorkingDays(date, daysToAdd, holidays) {
  const oneDay = 24 * 60 * 60 * 1000; // Số mili giây trong một ngày
  function isWeekend(day) {
    return day.getDay() === 0 || day.getDay() === 6;
  }
  function isHoliday(day, holidays) {
    const formattedDate = day.toISOString().split("T")[0];
    return holidays.includes(formattedDate);
  }
  let count = 0;
  while (count < daysToAdd) {
    date.setTime(date.getTime() + oneDay);
    if (!isWeekend(date) && !isHoliday(date, holidays)) {
      count++;
    }
  }
  return date;
}
function $replaceSpecialCharacters(inputString) {
  var replacedString = inputString
    .replace(/ờ/g, "\u1EDD")
    .replace(/ề/g, "\u1EC1")
    .replace(/đ/g, "\u0111")
    .replace(/ọ/g, "\u1ECF");

  return replacedString;
}
function $capitalizeFirstLetter(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
function $getElementTop(flexContainer) { //Truyền vào flexContainer ngay phía trên
  if (!flexContainer.top) {
    console.error("Lỗi top của flexContainer truyền vào.");
    return;
  }
  if (!flexContainer.height) {
    console.error("Lỗi height của flexContainer truyền vào.");
    return;
  }
  return $addUnit(flexContainer.top, flexContainer.height);
}