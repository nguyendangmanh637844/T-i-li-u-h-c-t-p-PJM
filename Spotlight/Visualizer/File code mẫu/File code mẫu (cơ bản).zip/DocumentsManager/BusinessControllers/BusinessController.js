define(["ModelManager"], function (ModelManager) {
  /**
   * DocumentsManager manages models: termsAndConditions
   */
  function DocumentsManager() {
    kony.mvc.Business.Delegator.call(this);
  }

  inheritsFrom(DocumentsManager, kony.mvc.Business.Delegator);

  DocumentsManager.prototype.initializeBusinessController = function () {};

  //Documents
  DocumentsManager.prototype.getDocuments = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getDocuments",
      options,
      onSuccess,
      onError
    );
  };
  DocumentsManager.prototype.createDocument = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "createDocument",
      options,
      onSuccess,
      onError
    );
  };
  DocumentsManager.prototype.updateDocument = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "updateDocument",
      options,
      onSuccess,
      onError
    );
  };

  return DocumentsManager;
});
