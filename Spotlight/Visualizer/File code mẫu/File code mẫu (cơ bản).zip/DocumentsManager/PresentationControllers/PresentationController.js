define([], function(){
    function DocumentsManager_PresentationController() {
        kony.mvc.Presentation.BasePresenter.call(this);
    }

    inheritsFrom(DocumentsManager_PresentationController, kony.mvc.Presentation.BasePresenter);

    DocumentsManager_PresentationController.prototype.initializePresentationController = function () {
    };
    return DocumentsManager_PresentationController;
});