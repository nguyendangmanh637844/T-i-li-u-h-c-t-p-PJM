define([], function(){
    function DetailAndLogManager_PresentationController() {
        kony.mvc.Presentation.BasePresenter.call(this);
    }

    inheritsFrom(DetailAndLogManager_PresentationController, kony.mvc.Presentation.BasePresenter);

    DetailAndLogManager_PresentationController.prototype.initializePresentationController = function () {
    };
    return DetailAndLogManager_PresentationController;
});