define(["ModelManager"], function (ModelManager) {
  /**
   * DetailAndLogManager manages models: DetailAndLog
   */
  function DetailAndLogManager() {
    kony.mvc.Business.Delegator.call(this);
  }

  inheritsFrom(DetailAndLogManager, kony.mvc.Business.Delegator);

  DetailAndLogManager.prototype.initializeBusinessController = function () { };

  DetailAndLogManager.prototype.getDetail = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getOneFundTransfer",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getLog = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "termsandconditions",
      "getAllTermsAndConditions",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getAllRecordsManagement = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getAllFileFundTransfers",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.updateFundTransfer = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "updateFundTransfer",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.updateFtFxFundTransfer = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "updateFtFxFundTransfer",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.saveAdditional = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "createFundTransferAdditional",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.updateAdditional = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "updateFundTransferAdditional",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getAllUsers = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getAllUsers",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getOneFundTransferAdditional = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getOneFundTransferAdditional",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.uploadDocumentsToS3 = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "uploadDocumentToS3",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.createFundTransferDocument = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "createFundTransferDocument",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getApprovalLevels = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getApprovalLevels",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.createApprovalStep = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "createApprovalSteps",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getApprovalStep = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getApprovalSteps",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getInfoUser = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getInfoUser",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.downloadFileFromS3 = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "downloadFileFromS3",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.sendMails = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "sendMails",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getNostros = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "ListCreditAccountNostro",
      "getNostro",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.assignRecordSendEmail = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "assignRecordSendEmail",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getBranchesMap = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getBranchesMap",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.chuyenCap = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "chuyenCap",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getPaymentOrder = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getPaymentOrder",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.assignFundTransfer = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "assignFundTransfer",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.finalApproval = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "finalApproval",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getListHoliday = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getListHoliday",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.verifySwiftCode = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "verifySwiftCode",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getChannel = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getChannel",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getAccessibleChannel = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getAccessibleChannel",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getCountries = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getCountries",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.updateFundTransferAccepted = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "updateFundTransferAccepted",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getProcessLog = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getProcessLog",
      options,
      onSuccess,
      onError
    );
  };
  DetailAndLogManager.prototype.getPaymentOrderNium = function (
    options,
    onSuccess,
    onError
  ) {
    ModelManager.invoke(
      "PvbIftManagement",
      "getPaymentOrderNium",
      options,
      onSuccess,
      onError
    );
  };
  return DetailAndLogManager;
});
