define(["ErrorInterceptor", "ErrorIsNetworkDown", "Promisify"], function (
  ErrorInterceptor,
  isNetworkDown,
  Promisify
) {
  function DetailAndLog_PresentationController() {
    kony.mvc.Presentation.BasePresenter.call(this);
    this.model = {
      data: null,
      context: null,
    };
    this.context = {
      toast: null,
      message: null,
    };
  }

  inheritsFrom(
    DetailAndLog_PresentationController,
    kony.mvc.Presentation.BasePresenter
  );
  DetailAndLog_PresentationController.prototype.detailInfor = null;
  DetailAndLog_PresentationController.prototype.logs = null;

  DetailAndLog_PresentationController.prototype.initializePresentationController =
    function () {
      var self = this;
      ErrorInterceptor.wrap(this, "businessController").match(function (on) {
        return [
          on(isNetworkDown).do(function () {
            self.presentUserInterface(self.currentForm, {
              NetworkDownMessage: {},
            });
          }),
        ];
      });
    };

  DetailAndLog_PresentationController.prototype.getDetail = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "viewDetail";
      self.model.data = response.data || "";
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "viewDetailError";
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    this.businessController.getDetail(param, successCallback, failureCallback);
  };
  DetailAndLog_PresentationController.prototype.getLog = function () {
    var self = this;
    function successCallback(response) {
      self.model.context = "viewLog";
      self.model.data = response.termsAndConditions || {};
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.errmsg = error.errmsg;
      kony.print("Not able to fetch detail information", error);
    }
    this.businessController.getLog({}, successCallback, failureCallback);
  };
  DetailAndLog_PresentationController.prototype.validatePayload = function (
    payload
  ) {
    delete payload.lastmodifiedts;
    delete payload.modifiedby;
    delete payload.createdts;
    delete payload.createdby;
  };
  DetailAndLog_PresentationController.prototype.getAllUsers = function (param) {
    const self = this;
    const success = (response) => {
      self.model.context = "getAllUsers";
      self.model.data = response.data || {};
      self.presentUserInterface("frmDetailAndLog", self.model);
    };

    const fail = (error) => {
      kony.print("Not able to fetch detail information", error);
    };
    this.businessController.getAllUsers(
      {
        branchCode: param.branchCode,
        roleId: param.roleId,
      },
      success,
      fail
    );
  };
  DetailAndLog_PresentationController.prototype.getAllRecordsManagement = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "listRecordsManagement";
      self.model.data = {
        result: response.data.result || [],
        resultAll: response.data.resultAll || [],
        totalRecord: response.data.totalRecord
      } || {};
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.errmsg = error.errmsg;
      self.model.context = "listRecordsManagementError";
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    this.businessController.getAllRecordsManagement(
      param ? param :
        {
          limitRecord: 10,
          offsetRecord: 0
        },
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.updateFundTransfer = function (
    param,
    isOnlyShowSuccessMessage = false,
    action
  ) {
    var self = this;
    function successCallback(response) {
      if (isOnlyShowSuccessMessage) {
        self.model.context = "saveDetailInformation";
        self.presentUserInterface("frmDetailAndLog", self.model);
      } else {
        self.model.context = action ? action : "updateFundTransfer";
        self.presentUserInterface("frmDetailAndLog", self.model);
      }
    }

    function failureCallback(error) {
      self.model.context = "updateFundTransferError";
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.validatePayload(param);
    this.businessController.updateFundTransfer(
      param,
      successCallback,
      failureCallback
    );
  };

  DetailAndLog_PresentationController.prototype.updateFtFxFundTransfer = function (
    param,
  ) {
    var self = this;
    function successCallback(response) {     
      self.model.context = "updateFtFxFundTransfer";
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
     
    function failureCallback(error) {
      self.model.context = "updateFtFxFundTransferError";
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.updateFtFxFundTransfer(
      param,
      successCallback,
      failureCallback
    );
  };

  DetailAndLog_PresentationController.prototype.saveAdditional = function (
    param,
    isPhanHoi = false,
    level = null
  ) {
    var self = this;
    function successCallback(response) {
      if (isPhanHoi) self.model.context = "saveFeedbackReasonBeforPhanHoi";
      else self.model.context = "saveAdditional";
      self.model.level = level;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "saveAdditionalError";
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.validatePayload(param);
    this.businessController.saveAdditional(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.updateAdditional = function (
    param,
    isPhanHoi = false,
    level = null
  ) {
    var self = this;
    function successCallback(response) {
      if (isPhanHoi) self.model.context = "updateFeedbackReasonBeforPhanHoi";
      else self.model.context = "updateAdditional";
      self.model.level = level;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "updateAdditionalError";
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.validatePayload(param);
    this.businessController.updateAdditional(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getOneFundTransferAdditional =
    function (param, isPhanHoi) {
      var self = this;
      function successCallback(response) {
        self.model.context = "getOneFundTransferAdditional";
        self.model.data = response.data;
        self.model.isPhanHoi = isPhanHoi;
        self.presentUserInterface("frmDetailAndLog", self.model);
      }

      function failureCallback(error) {
        self.model.context = "getOneFundTransferAdditionalError";
        self.model.httpStatusCode = error.httpStatusCode;
        self.model.errmsg = error.errmsg;
        self.model.isPhanHoi = isPhanHoi;
        self.presentUserInterface("frmDetailAndLog", self.model);
      }

      this.businessController.getOneFundTransferAdditional(
        param,
        successCallback,
        failureCallback
      );
    };
  DetailAndLog_PresentationController.prototype.uploadDocumentsToS3 = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "uploadDocumentsToS3";
      self.model.data = response.data[0];
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "uploadDocumentsToS3Error";
      self.model.errmsg = error.errmsg;
      self.model.httpStatusCode = error.httpStatusCode;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    this.businessController.uploadDocumentsToS3(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.createFundTransferDocument =
    function (param) {
      var self = this;
      function successCallback(response) {
        self.model.context = "createFundTransferDocument";
        self.model.data = response.data;
        self.presentUserInterface("frmDetailAndLog", self.model);
      }

      function failureCallback(error) {
        self.model.context = "createFundTransferDocumentError";
        self.model.httpStatusCode = error.httpStatusCode;
        self.model.errmsg = error.errmsg;
        self.presentUserInterface("frmDetailAndLog", self.model);
      }
      this.validatePayload(param);
      this.businessController.createFundTransferDocument(
        param,
        successCallback,
        failureCallback
      );
    };

  DetailAndLog_PresentationController.prototype.getApprovalLevels = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getApprovalLevels";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getApprovalLevelsError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getApprovalLevels(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.createApprovalStep = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "createApprovalStep";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "createApprovalStepError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.createApprovalStep(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getApprovalStep = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getApprovalStep";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getApprovalStepError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getApprovalStep(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getInfoUser = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getInfoUser";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getInfoUserError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getInfoUser(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.downloadFileFromS3 = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "downloadFileFromS3";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "downloadFileFromS3Error";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.downloadFileFromS3(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.sendMails = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "sendMails";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "sendMailsError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.sendMails(param, successCallback, failureCallback);
  };
  DetailAndLog_PresentationController.prototype.getNostros = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getNostros";
      self.model.data = response.detail || [];
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getNostrosError";
      self.model.errmsg = error.errmsg;
      self.model.httpStatusCode = error.httpStatusCode;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getNostros(param, successCallback, failureCallback);
  };
  DetailAndLog_PresentationController.prototype.assignRecordSendEmail = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "assignRecordSendEmail";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "assignRecordSendEmailError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.assignRecordSendEmail(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getBranchesMap = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getBranchesMap";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getBranchesMapError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getBranchesMap(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.chuyenCap = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "chuyenCap";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "chuyenCapError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.chuyenCap(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getPaymentOrder = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getPaymentOrder";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getPaymentOrderError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getPaymentOrder(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.assignFundTransfer = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "assignFundTransfer";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "assignFundTransferError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.assignFundTransfer(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.finalApproval = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "finalApproval";
      self.model.data = response.data;
      self.model.success = response.success;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "finalApprovalError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.finalApproval(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getListHoliday = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getListHoliday";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getListHolidayError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getListHoliday(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.verifySwiftCode = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "verifySwiftCode";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "verifySwiftCodeError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.verifySwiftCode(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getChannel = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getChannel";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getChannelError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getChannel(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getAccessibleChannel = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getAccessibleChannel";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getAccessibleChannelError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getAccessibleChannel(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getCountries = function (param) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getCountries";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getCountriesError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getCountries(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.updateFundTransferAccepted = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "updateFundTransferAccepted";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "updateFundTransferAcceptedError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.updateFundTransferAccepted(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getProcessLog = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getProcessLog";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getProcessLogError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getProcessLog(
      param,
      successCallback,
      failureCallback
    );
  };
  DetailAndLog_PresentationController.prototype.getPaymentOrderNium = function (
    param
  ) {
    var self = this;
    function successCallback(response) {
      self.model.context = "getPaymentOrderNium";
      self.model.data = response.data;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }

    function failureCallback(error) {
      self.model.context = "getPaymentOrderNiumError";
      self.model.httpStatusCode = error.httpStatusCode;
      self.model.errmsg = error.errmsg;
      self.presentUserInterface("frmDetailAndLog", self.model);
    }
    this.businessController.getPaymentOrderNium(
      param,
      successCallback,
      failureCallback
    );
  };
  return DetailAndLog_PresentationController;
});
