define([], function () {
  function DetailAndLogModule_BusinessController() {
    kony.mvc.Business.Delegator.call(this);
  }

  inheritsFrom(
    DetailAndLogModule_BusinessController,
    kony.mvc.Business.Delegator
  );

  DetailAndLogModule_BusinessController.prototype.initializeBusinessController =
    function () { };
  DetailAndLogModule_BusinessController.prototype.getDetail = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getDetail(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getLog = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getLog(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.updateFundTransfer =
    function (options, onSuccess, onError) {
      kony.mvc.MDAApplication.getSharedInstance()
        .getModuleManager()
        .getModule("DetailAndLogManager")
        .businessController.updateFundTransfer(options, onSuccess, onError);
    };
  DetailAndLogModule_BusinessController.prototype.updateFtFxFundTransfer =
  function (options, onSuccess, onError) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.updateFtFxFundTransfer(options, onSuccess, onError);
  };  
  DetailAndLogModule_BusinessController.prototype.saveAdditional = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.saveAdditional(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.updateAdditional = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.updateAdditional(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getAllRecordsManagement =
    function (options, onSuccess, onError) {
      kony.mvc.MDAApplication.getSharedInstance()
        .getModuleManager()
        .getModule("DetailAndLogManager")
        .businessController.getAllRecordsManagement(
          options,
          onSuccess,
          onError
        );
    };
  DetailAndLogModule_BusinessController.prototype.getAllUsers = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getAllUsers(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getOneFundTransferAdditional =
    function (options, onSuccess, onError) {
      kony.mvc.MDAApplication.getSharedInstance()
        .getModuleManager()
        .getModule("DetailAndLogManager")
        .businessController.getOneFundTransferAdditional(
          options,
          onSuccess,
          onError
        );
    };
  DetailAndLogModule_BusinessController.prototype.uploadDocumentsToS3 =
    function (options, onSuccess, onError) {
      kony.mvc.MDAApplication.getSharedInstance()
        .getModuleManager()
        .getModule("DetailAndLogManager")
        .businessController.uploadDocumentsToS3(options, onSuccess, onError);
    };
  DetailAndLogModule_BusinessController.prototype.createFundTransferDocument =
    function (options, onSuccess, onError) {
      kony.mvc.MDAApplication.getSharedInstance()
        .getModuleManager()
        .getModule("DetailAndLogManager")
        .businessController.createFundTransferDocument(
          options,
          onSuccess,
          onError
        );
    };
  DetailAndLogModule_BusinessController.prototype.getApprovalLevels = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getApprovalLevels(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.createApprovalStep =
    function (options, onSuccess, onError) {
      kony.mvc.MDAApplication.getSharedInstance()
        .getModuleManager()
        .getModule("DetailAndLogManager")
        .businessController.createApprovalStep(options, onSuccess, onError);
    };
  DetailAndLogModule_BusinessController.prototype.getApprovalStep = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getApprovalStep(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getInfoUser = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getInfoUser(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.downloadFileFromS3 = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.downloadFileFromS3(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.sendMails = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.sendMails(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getNostros = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getNostros(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.assignRecordSendEmail = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.assignRecordSendEmail(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getBranchesMap = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getBranchesMap(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.chuyenCap = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.chuyenCap(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getPaymentOrder = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getPaymentOrder(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.assignFundTransfer = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.assignFundTransfer(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.finalApproval = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.finalApproval(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getListHoliday = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getListHoliday(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.verifySwiftCode = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.verifySwiftCode(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getChannel = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getChannel(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getAccessibleChannel = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getAccessibleChannel(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getCountries = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getCountries(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.updateFundTransferAccepted = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.updateFundTransferAccepted(options, onSuccess, onError);
  };
  DetailAndLogModule_BusinessController.prototype.getProcessLog = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getProcessLog(options, onSuccess, onError);
  }
  DetailAndLogModule_BusinessController.prototype.getPaymentOrderNium = function (
    options,
    onSuccess,
    onError
  ) {
    kony.mvc.MDAApplication.getSharedInstance()
      .getModuleManager()
      .getModule("DetailAndLogManager")
      .businessController.getPaymentOrderNium(options, onSuccess, onError);
  }
  return DetailAndLogModule_BusinessController;
});
