define({
  dataHeader: [
    "STT",
    "Chi nhánh",
    "Đơn vị KD",
    "Mã hồ sơ",
    "Tên khách hàng",
    "CIF",
    "Mã giao dịch (Số FT)",
    "Số FX",
    "Ngày giao dịch",
    "Số ngoại tệ chuyển",
    "Loại ngoại tệ",
    "Created time",
    "Kênh giao dịch",
    "Trạng thái hồ sơ",
    "Trạng thái phê duyệt",
    "Nợ chứng từ",
    "User xử lý",
    "Xem chi tiết"
  ],
  isNewAdditional: false,
  generalHeight: 30,
  form: {},
  buttons: {},
  detailUI: {},
  recordSelected: { id: 0 },
  recordList: [],
  recordListExport: [],
  approvalLevelsList: [],
  detailData: {},
  responseData: {
    approvalLevel: { maxAmount: 0 }
  },
  flxCustomDocumentInformation: {},
  listAllUser: [],
  flxButtons: {},
  bankNameChina: [
    ...BANK_OF_CHINA,
    ...CHINA_CONTRUCTION_BANK,
    ...INDUSTRIAL_AND_COMMERCIAL_BANK_OF_CHINA,
    ...ICBC,
  ],
  attachFiles: [],
  level: -2,
  levelPhanHoi: -2,
  action: "",
  changeAdditionalData: [],
  levelDefinition: [],
  infoUser: {},
  roleCanUpdate: [],
  paramsListRecords: {},
  limitRecord: 10,
  paginationRecords: {
    limitRecord: 10,
    offsetRecord: 0,
    totalRecord: 1
  },
  listBranchCompany: [],
  listBranchCodeCurrent: [],
  loadApiFirst: false,
  currentSelectPage: 1,
  statusFilterFirstGDV: false,
  statusFilterFirstKSV: false,
  statusFilterFirstLDDV: false,
  statusFilterFirstCVTTQT: false,
  statusFilterFirstC1: false,
  statusFilterFirstC2: false,
  senderToReceiverInfoTextBoxs: [],
  nganHangThuHuongTextBoxs: [],
  f77bTextBoxs: [],
  listNostro: [],
  listDataRecordsFilter: [],
  files: [],
  isHasRoleUpdateDocument: false,
  fileUploadToS3: {},
  dataForLogAssign: {},
  holidays: [],
  listBranchCodeIsDecenterlized: [],
  approvalStepCurrent: null,
  approvalStepFirstLoad: true,
  listApprovalStep: [],
  fieldFt: {},
  detailUIFundTransfer: {},
  detailUIDocuments: {},
  flxPhanHoi: {},
  isExistSwiftCode: false,
  paymentModel: "",
  listChannels: [],
  tableThongTinNganHangThuHuongLeft: {},
  tableThongTinNganHangThuHuongRight: {},
  flxThongTinNganHangThuHuongLeft: {},
  flxThongTinNganHangThuHuongRight: {},
  flxThongTinNganHangThuHuong: {},
  flxLabelThongTinKiemTra: {},
  tableThongTinNguoiChuyenTienLeft: {},
  flxKQKT: {},
  flxColMoTaLyDoChiTiet: {},
  flxSpace: {},
  flxKenhGiaoDich: {},
  accessibleChannels: [],
  countries: [],
  tenKhachHangTextBoxs: [],
  diaChiNguoiChuyenTextBoxs: [],
  diaChiNguoiHuongTextBoxs: [],
  flxThongTinNguoiChuyen: {},
  fieldFx: {},
  flxLabelThongTinNguoiChuyenTien: {},
  flxLabelThongTinNguoiThuHuong: {},
  flxThongTinNguoiThuHuong: {},
  flxLabelThongTinNganHangThuHuong: {},
  amountOfAddressLine: 8,
  amountOfAddressLineNguoiHuong: 6,
  amountOfLineNoiDungChuyenTien: 6,
  diaChi2: {},
  diaChi3: {},
  diaChi4: {},
  diaChi5: {},
  diaChi6: {},
  diaChi7: {},
  diaChi8: {},
  diaChiNguoiHuong2: {},
  diaChiNguoiHuong3: {},
  diaChiNguoiHuong4: {},
  diaChiNguoiHuong5: {},
  diaChiNguoiHuong6: {},
  noiDungChuyenTien2: {},
  noiDungChuyenTien3: {},
  noiDungChuyenTien4: {},
  noiDungChuyenTien5: {},
  noiDungChuyenTien6: {},
  noiDungChuyenTien7: {},
  noiDungChuyenTien8: {},
  tableThongTinGiaoDichLeft: {},
  tenNguoiThuHuongTextBoxs: [],
  tableThongTinNguoiThuHuongLeft: {},
  flxThongTinGiaoDich: {},
  noiDungChuyenTienTextBoxs: [],
  fundTransferAdditionalInitial: {},
  flxAttachButton: {},
  callbackAfterValidate: () => { },
  preShowActions() {
    const self = this;
    this.presenter.getCountries();
    this.createUI();
    this.flowActions();
    this.view.Button0fa38bc439f3e48.onClick = () => {
      this.paginationRecords = {
        ...this.paginationRecords,
        limitRecord: 10,
        offsetRecord: 0
      };
      this.currentSelectPage = 1;
      this.handleSearchAllRecords();
    };
    this.view.FlexContainer0fda0ceb7d9bb49.onClick = () => {
      const dataHeader = self.dataHeader;
      const dataHeaderSplice = [...dataHeader.slice(0, 7), "Fx1", "Fx2", ...dataHeader.slice(8, 16)];
      $exportFileExcel(
        self.listDataRecordsFilter,
        dataHeaderSplice,
        "Danh sách hồ sơ CTQT"
      );
    };
    this.presenter.getApprovalLevels();
    this.getListNostro();
    this.presenter.getChannel();
    this.presenter.getListHoliday();
    this.view.Button0a8863fe63a4e45.onClick = () => {
      $showLoading(self.view);
      self.presenter.getPaymentOrder(
        self.detailData ? { transferCode: self.detailData.transferCode } : {}
      );
    };
    this.view.CopyButton0c512b924758348.onClick = () => {
      this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = true;
      this.view.CopyflxPopUpTopColor0e442b9b0742843.skin =
        DEFAULT_SKIN.InforPopup;
    };
    this.view.CopybtnPopUpCancel0f3298c2214fe47.onClick = () => {
      this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
    };
    this.view.CopyflxPopUpClose0b9f4641e1b4845.onClick = () => {
      this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
    };
    this.view.TabPanel.ListBox0d2a157cf308144.onSelection = (data) => {
      $showLoading(self.view);
      const dataSelect = self.listApprovalStep.filter(
        (item) => item.createdts === data.selectedkey
      );
      self.approvalStepCurrent = dataSelect[0];
      this.presenter.getApprovalStep({
        fundTransferId: self.detailData.id,
        versionStep: dataSelect[0].version,
        stepAction: dataSelect[0].action
      });
    };
    this.view.TabPanel.CopyButton0f5d87f845cce48.onClick = () => {
      this.view.TabPanel.FlexContainer0e79069ca95a647.isVisible = true;
      this.view.TabPanel.FlexContainer0ed8d88ec685444.isVisible = false;
    }
    this.view.TabPanel.CopyButton0eafff54093a64f.onClick = () => {
      this.view.TabPanel.FlexContainer0e79069ca95a647.isVisible = false;
      this.view.TabPanel.FlexContainer0ed8d88ec685444.isVisible = true;
    }
  },
  //Hàm thay đổi
  willUpdateUI(model) {
    const roleId = kony.store.getItem("roleId");
    this.updateLeftMenu(model, roleId === ROLE.ADMIN);
    this.updateUserName();
    this.updateContent(model);
    this.view.forceLayout();
  },
  updateUserName() {
    this.view.dropdownMainHeader.lblUserName.text =
      "Hello, " +
      kony.mvc.MDAApplication.getSharedInstance().appContext.userName;
  },
  updateContent(model) {
    const self = this;
    switch (model.context) {
      case "listRecordsManagement":
        this.view.Button0a8863fe63a4e45.isVisible = false;
        this.recordList = model.data.result;
        this.recordListExport = model.data.resultAll;
        this.paginationRecords = {
          ...this.paginationRecords,
          totalRecord: model.data.totalRecord
        };
        this.createPagination(model.data.totalRecord);
        if (!this.loadApiFirst) {
          this.presenter.getAllUsers({});
        } else {
          this.setCustomersSegmentData();
          this.setCSSstyle();
          this.setStyleForList();
          $hideLoading(this.view);
        }
        if (this.recordList && this.recordList.length) {
          this.view.flxPagination.isVisible = true;
          this.view.FlexContainer0fda0ceb7d9bb49.isVisible = true;
        } else {
          this.view.flxPagination.isVisible = false;
          this.view.FlexContainer0fda0ceb7d9bb49.isVisible = false;
        }
        break;
      case "listRecordsManagementError":
        this.showMessageAndClose(model.errmsg);
        $hideLoading(this.view);
        break;
      case "viewDetail":
        this.responseData = { ...this.responseData, ...model.data };
        this.detailData = model.data.fundTransfer;
        this.detailData.transferPurposeName =
          this.responseData.transferPurpose || "";
        this.fundTransferAdditionalInitial = model.data.fundTransferAdditional || {};
        this.showDetailInfo(this.detailData);
        this.presenter.getApprovalStep({ fundTransferId: self.detailData.id });
        break;
      case "getNostros":
        this.listNostro = model.data;
        break;
      case "getNostrosError":
        this.listNostro = [];
        this.showErrorMessage(
          "Lấy danh sách tài khoản Nostro/Đối tác không thành công."
        );
        break;
      case "viewDetailError":
        this.showMessageAndClose(model.errmsg);
        break;
      case "getAllUsers":
        this.listAllUser = model.data;
        this.presenter.getInfoUser();
        break;
      case "getOneFundTransferAdditional":
        this.responseData.fundTransferAdditional = model.data;
        if (model.isPhanHoi)
          this.saveFeedbackReasonBeforPhanHoi(this.levelPhanHoi);
        else this.saveAdditional(true);
        break;
      case "getOneFundTransferAdditionalError":
        if (model.httpStatusCode === 204) {
          if (model.isPhanHoi)
            this.saveFeedbackReasonBeforPhanHoi(this.levelPhanHoi);
          else this.saveAdditional(false);
        } else {
          $hideLoading(this.view);
          this.showErrorMessage(model.errmsg);
        }
        break;
      case "uploadDocumentsToS3":
        this.fileUploadToS3 = this.attachFiles.shift();
        this.uploadFile(model.data.link, this.fileUploadToS3);
        break;
      case "uploadDocumentsToS3Error":
        this.showErrorMessage("Error uploading the document");
        break;
      case "createFundTransferDocument":
        if (this.files.length > 0) this.uploadDocumentsToS3();
        else {
          this.handleSearchAllRecords();
        }
        break;
      case "createFundTransferDocumentError":
        this.showErrorMessage(model.errmsg);
        break;
      case "getApprovalLevels":
        this.approvalLevelsList = model.data;
        this.createApprovalLevelList(model.data);
        $hideLoading(this.view);
        break;
      case "getApprovalLevelsError":
        this.showErrorMessage(model.errmsg);
        $hideLoading(this.view);
        break;
      case "getApprovalStep":
        $hideLoading(this.view);
        this.showLog(model.data);
        break;
      case "getApprovalStepError":
        $hideLoading(this.view);
        this.showErrorMessage(model.errmsg);
        break;
      case "getInfoUser":
        $hideLoading(this.view);
        this.infoUser = model.data;
        this.setCustomersSegmentData();
        this.setCSSstyle();
        this.setStyleForList();
        this.presenter.getBranchesMap();
        break;
      case "getInfoUserError":
        $hideLoading(this.view);
        this.setCSSstyle();
        this.setStyleForList();
        this.showErrorMessage(model.errmsg);
        break;
      case "downloadFileFromS3":
        const isSuccess = this.downloadFile(model.data[0].link);
        if (isSuccess) {
          $hideLoading(self.view);
          self.showSuccessMessage();
        } else {
          $hideLoading(self.view);
          self.showErrorMessage("Error downloading the document");
        }
        break;
      case "downloadFileFromS3Error":
        $hideLoading(this.view);
        this.showErrorMessage("Error downloading the document");
        break;
      case "assignRecordSendEmail":
        $hideLoading(this.view);
        this.showSuccessMessage();
        break;
      case "assignRecordSendEmailError":
        $hideLoading(this.view);
        this.showErrorMessage(model.errmsg);
        break;
      case "getBranchesMap":
        $hideLoading(this.view);
        this.listBranchCompany = model.data;
        this.listBranchCodeIsDecenterlized = model.data.length
          ? model.data
            .filter((item) => item.isDecenterlized)
            .map((item) => item.branchCode)
          : [];
        this.createBranchList(model.data);
        this.checkLoadFirst();
        this.loadApiFirst = true;
        break;
      case "createApprovalStep":
        this.dataForLogAssign = {};
        this.showListView();
        this.handleSearchAllRecords();
        break;
      case "createApprovalStepError":
        this.dataForLogAssign = {};
        $hideLoading(this.view);
        this.showErrorMessage(model.errmsg);
        break;
      case "getBranchesMapError":
        $hideLoading(this.view);
        this.showErrorMessage(model.errmsg);
        break;
      case "chuyenCap":
        this.showListView();
        this.showSuccessMessage();
        if (this.attachFiles.length > 0) this.uploadDocumentsToS3();
        else {
          this.handleSearchAllRecords();
        }
        break;
      case "chuyenCapError":
        $hideLoading(this.view);
        this.showErrorMessage(model.errmsg);
        break;
      case "getPaymentOrder":
        $hideLoading(this.view);
        $handleConvertBase64ToBlob(model.data, "lenhChuyenTien.pdf");
        this.showSuccessMessage();
        break;
      case "getPaymentOrderError":
        $hideLoading(this.view);
        this.showErrorMessage(model.errmsg);
        break;
      case "assignFundTransfer":
        this.showListView();
        this.showSuccessMessage();
        this.handleSearchAllRecords();
        break;
      case "assignFundTransferError":
        $hideLoading(this.view);
        this.showErrorMessage(model.errmsg);
        this.handleSearchAllRecords();
        break;
      case "updateFtFxFundTransfer":
        this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
        this.view.CopyButton0c512b924758348.isVisible = false;
        this.view.CopyButton0a7f9b54ae4144e.isVisible = false;
        this.view.CopyButton0cc4f139ab6a742.isVisible = false
        this.logChangeAdditionalData();
        this.showListView();
        this.showSuccessMessage();
        this.handleSearchAllRecords();
      case "finalApproval":
        this.showListView();
        this.showSuccessMessage(model.success || "Success");
        this.handleSearchAllRecords();
        break;
      case "finalApprovalError":
        $hideLoading(this.view);
        this.showErrorMessage(model.errmsg);
        break;
      case "getListHoliday":
        this.holidays = model.data;
        break;
      case "getListHolidayError":
        this.showErrorMessage("Lấy dữ liệu ngày nghỉ thất bại");
        break;
      case "verifySwiftCode":
        Boolean(this.isExistSwiftCode = model.data);
        break;
      case "verifySwiftCodeError":
        this.showErrorMessage(
          "Có lỗi xảy ra khi thực hiện kiểm tra swiftcode có tồn tại trên hệ thống hay không."
        );
        break;
      case "getChannel":
        this.listChannels = model.data;
        break;
      case "getChannelError":
        this.showErrorMessage("Có lỗi xảy ra khi lấy thông tin kênh.");
        break;
      case "getAccessibleChannel":
        if (model.data.length === 0) {
          this.showErrorMessage("Không có kênh khả dụng.");
          return;
        }
        this.accessibleChannels = model.data[0];
        if (!this.accessibleChannels.isAccessible) {
          const errors = this.accessibleChannels.errors;
          const message = this.generateErrorMessage(
            errors,
            FIELD_CHANGE,
            this.accessibleChannels.channelCode
          );
          this.showWarningPopup(message);
          this.detailUI.lbKenhGiaoDich.selectedKey = this.detailData.channelCode;
          $hideLoading(this.view);
          return;
        }
        this.callbackAfterValidate();
        break;
      case "getAccessibleChannelError":
        $hideLoading(this.view);
        this.showErrorMessage(
          "Có lỗi xảy ra khi kiểm tra tính khả dụng của kênh."
        );
        break;
      case "getCountries":
        this.countries = model.data;
        break;
      case "getCountriesError":
        this.showErrorMessage("Có lỗi xảy ra khi lấy các quốc gia.");
        break;
      case "updateFundTransferAccepted":
        $hideLoading(this.view);
        this.showSuccessMessage();
        this.showListView();
        this.handleSearchAllRecords();
        this.view.CopyButton0a7f9b54ae4144e.isVisible = false;
        break;
      case "updateFundTransferAcceptedError":
        $hideLoading(this.view);
        this.showErrorMessage();
        break;
      case "getProcessLog":
        $hideLoading(this.view);
        this.showProcessLog(model.data);
        break;
      case "getProcessLogError":
        this.view.TabPanel.CopyFlexContainer0f9a94bcb4a9148.isVisible = false
        $hideLoading(this.view);
        this.showErrorMessage();
        break;
      case "getPaymentOrderNium":
        $hideLoading(this.view);
        $handleConvertBase64ToBlob(model.data, "dienChuyenTienNium.docx");
        break;
      case "getPaymentOrderNiumError":
        $hideLoading(this.view);
        this.showErrorMessage();
        break;
    }
  },
  showSuccessMessage(message = "Success") {
    $showToastMessage(
      this.view.flxToastMessage,
      this.view.toastMessage.flxToastContainer,
      message,
      TOAST_MODE.Success
    );
  },
  showErrorMessage(message = "Error") {
    $showToastMessage(
      this.view.flxToastMessage,
      this.view.toastMessage.flxToastContainer,
      message || "Error",
      TOAST_MODE.Error
    );
  },
  showWarningMessage(message = "Error", duration = 30) {
    $showToastMessage(
      this.view.flxToastMessage,
      this.view.toastMessage.flxToastContainer,
      message,
      TOAST_MODE.Warning,
      duration
    );
  },
  showMessageAndClose(message, isErrorMessage = true) {
    $showToastMessage(
      this.view.flxToastMessage,
      this.view.toastMessage.flxToastContainer,
      message,
      isErrorMessage ? TOAST_MODE.Error : TOAST_MODE.Success
    );
    this.showListView();
  },
  showListView() {
    this.responseData = {};
    this.view.flxScrollMainContent.isVisible = true;
    this.view.TabPanel.isVisible = false;
    this.view.flxAlertsBreadCrumb.isVisible = false;
    this.view.Label0i1920b9016c64557.isVisible = true;
    this.view.FlexContainer0hebff93deebc4156.isVisible = true;
    $hideLoading(this.view);
  },
  hideListView() {
    this.view.flxScrollMainContent.isVisible = false;
    this.view.TabPanel.isVisible = true;
    this.view.flxAlertsBreadCrumb.isVisible = true;
    this.view.breadcrumbs.btnBackToMain.text = "Danh sách yêu cầu";
    this.view.breadcrumbs.btnBackToMain.onClick = () => {
      this.backToListPage();
    };
    this.view.breadcrumbs.lblCurrentScreen.text = "Thông tin chi tiết";
    this.view.Label0i1920b9016c64557.isVisible = false;
    this.view.FlexContainer0hebff93deebc4156.isVisible = false;
    this.view.TabPanel.selectedTabIndex = 0;
  },
  postShowActions() {
    $setStyle(this.tableThongTinGiaoDichLeft[5], {
      overflow: "hidden !important"
    });
    $setStyle(this.tableThongTinNganHangThuHuongLeft[15], {
      overflow: "hidden !important"
    });
    $setStyle(this.tableThongTinNganHangThuHuongLeft[17], {
      overflow: "hidden !important"
    });
    $setStyle(this.tableThongTinNganHangThuHuongRight[5], {
      overflow: "hidden !important"
    });
    $setStyle(this.tableThongTinNguoiChuyenTienLeft[3], {
      overflow: "hidden !important"
    });
    $setStyle(this.tableThongTinNguoiChuyenTienLeft[5], {
      overflow: "hidden !important"
    });
    $setStyle(this.tableThongTinNguoiThuHuongLeft[3], {
      overflow: "hidden !important"
    });
    $setStyle(this.tableThongTinNguoiThuHuongLeft[5], {
      overflow: "hidden !important"
    });
    this.setCSSstyle();
    this.creatHeader();
    this.setStyleForList();
    this.view.Button0a8863fe63a4e45.isVisible = false;
    this.view.Button0a8863fe63a4e45.text = "Tải xuống lệnh chuyển tiền";
  },
  flowActions() { },
  //lịch sử
  showLog(data) {
    const self = this;
    const dataDetailFundTransfer = this.detailData;
    const convertIdToLabel = (id, type) => {
      if (type === "approvalLevel") {
        const currentBranch = dataDetailFundTransfer ? dataDetailFundTransfer.branchCode : ""
        const approvalLevelData = self.approvalLevelsList.filter(
          (item) => item.approvalLevel === parseInt(id)
        );
        if (approvalLevelData.length) {
          if (self.listBranchCodeIsDecenterlized.includes(currentBranch)) {
            return approvalLevelData[0].approvalName === "Chờ GĐV duyệt" ? "Chờ PD của LĐ chi nhánh" : approvalLevelData[0].approvalName
          } else {
            return approvalLevelData[0].approvalNameCenterlized === "Chờ GĐV duyệt" ? "Chờ PD của LĐ chi nhánh" : approvalLevelData[0].approvalNameCenterlized
          }
        }
        return "-"
      }
      if (type === "assigne") {
        const detailDataAssigneData = self.listAllUser.filter(
          (item) => item.id == id
        );
        return detailDataAssigneData.length
          ? detailDataAssigneData[0].lastName +
          detailDataAssigneData[0].firstName
          : "-";
      }
      if (type === "paymentModel") {
        return id
          ? id === "DECENTRALIZED"
            ? "Phi tập trung"
            : "Tập trung"
          : "-";
      }
      if (type === "resultCheck") {
        switch (id) {
          case CHECK_RESULT.ValidRecords:
            return "Hồ sơ hợp lệ";
          case CHECK_RESULT.SupplementalRecords:
            return "Bổ sung hồ sơ";
          case CHECK_RESULT.RejectedRecords:
            return "Từ chối hồ sơ";
          default:
            return "-";
        }
      }
      if (type === "pcrtBranch") {
        switch (id) {
          case "VIOLATION":
            return CHECK_PCRT.VIOLATION;
          case "NOT_VIOLATION":
            return CHECK_PCRT.NOT_VIOLATION;
          default:
            return "-";
        }
      }
      if (type === "assignLog") {
        let dataUserAssign =
          id &&
          id.substr(0, 1) === "{" &&
          self.listAllUser.filter((item) => JSON.parse(id).assigne == item.id);
        return dataUserAssign
          ? `Hồ sơ tại cấp ${JSON.parse(id) ? JSON.parse(id).approvalLevel : "-"
          }, được xử lý bởi ${dataUserAssign[0] ? dataUserAssign[0].lastName : "-"
          } ${dataUserAssign[0] ? dataUserAssign[0].firstName : "-"}`
          : "-";
      }
      return id || "-";
    };
    const checkAction = (item) => {
      if (this.approvalStepFirstLoad) {
        return true;
      }
      if (
        $convertToHmsDDMMYYYY(item.createdts) ===
        self.approvalStepCurrent.createdts ||
        ""
      ) {
        return true;
      }
      return false;
    };
    const checkActionName = (action) => {
      switch (action) {
        case ACTION_STEP_NAME.ganHoSo:
          return MAPPING_ACTION_STEP.ganHoSo;
        case ACTION_STEP_NAME.chuyenCapDuyet:
          return MAPPING_ACTION_STEP.chuyenCapDuyet;
        case ACTION_STEP_NAME.taiLenHoSo:
          return MAPPING_ACTION_STEP.taiLenHoSo;
        case ACTION_STEP_NAME.phanHoi:
          return MAPPING_ACTION_STEP.phanHoi;
        case ACTION_STEP_NAME.duyet:
          return MAPPING_ACTION_STEP.duyet;
        case ACTION_STEP_NAME.capNhatThuCong:
          return MAPPING_ACTION_STEP.capNhatThuCong;
        case ACTION_STEP_NAME.khachHangTao:
          return MAPPING_ACTION_STEP.khachHangTao;
        case ACTION_STEP_NAME.khachHangCapNhat:
          return MAPPING_ACTION_STEP.khachHangCapNhat;
        case ACTION_STEP_NAME.khachHangXacNhan:
          return MAPPING_ACTION_STEP.khachHangXacNhan;
        case ACTION_STEP_NAME.ketQuaChuyenTien:
          return MAPPING_ACTION_STEP.ketQuaChuyenTien;
        case ACTION_STEP_NAME.tuDongChuyenTien:
          return MAPPING_ACTION_STEP.tuDongChuyenTien;
        case ACTION_STEP_NAME.jobQuaHan:
          return MAPPING_ACTION_STEP.jobQuaHan;
      }
    };
    const checkActionType = (action) => {
      switch (action) {
        case MAPPING_ACTION_STEP.ganHoSo:
          return ACTION_STEP_NAME.ganHoSo;
        case MAPPING_ACTION_STEP.chuyenCapDuyet:
          return ACTION_STEP_NAME.chuyenCapDuyet;
        case MAPPING_ACTION_STEP.taiLenHoSo:
          return ACTION_STEP_NAME.taiLenHoSo;
        case MAPPING_ACTION_STEP.phanHoi:
          return ACTION_STEP_NAME.phanHoi;
        case MAPPING_ACTION_STEP.duyet:
          return ACTION_STEP_NAME.duyet;
        case MAPPING_ACTION_STEP.capNhatThuCong:
          return ACTION_STEP_NAME.capNhatThuCong;
        case MAPPING_ACTION_STEP.khachHangTao:
          return ACTION_STEP_NAME.khachHangTao;
        case MAPPING_ACTION_STEP.khachHangCapNhat:
          return ACTION_STEP_NAME.khachHangCapNhat;
        case MAPPING_ACTION_STEP.khachHangXacNhan:
          return ACTION_STEP_NAME.khachHangXacNhan;
        case MAPPING_ACTION_STEP.ketQuaChuyenTien:
          return ACTION_STEP_NAME.ketQuaChuyenTien;
        case MAPPING_ACTION_STEP.tuDongChuyenTien:
          return ACTION_STEP_NAME.tuDongChuyenTien;
        case MAPPING_ACTION_STEP.jobQuaHan:
          return ACTION_STEP_NAME.jobQuaHan;
      }
    };
    const convertData = data.length
      ? data
        .filter(
          (item) =>
            item.field !== "additionalAssigne" &&
            item.field !== "pvbFundTransferId" &&
            item.field !== "customerAccountType" &&
            item.oldValue !== item.newValue &&
            checkAction(item)
        )
        .map((item) => {
          return {
            ...item,
            action: checkActionName(item.action),
            createdts: $convertToHmsDDMMYYYY(item.createdts),
            field: FIELD_CHANGE[item.field]
              ? $capitalizeFirstLetter(FIELD_CHANGE[item.field])
              : "-",
            oldValue: convertIdToLabel(item.oldValue, item.field).replaceAll(SEPARATOR_OPERATOR, " ") || "-",
            newValue: convertIdToLabel(item.newValue, item.field).replaceAll(SEPARATOR_OPERATOR, " ") || "-"
          };
        })
      : [];
    if (this.approvalStepFirstLoad) {
      this.approvalStepFirstLoad = false;
      let listVersion =
        convertData.length &&
        convertData.map((item) => {
          return {
            createdts: item.createdts,
            action: checkActionType(item.action),
            version: item.version
          };
        });
      listVersion = [...new Set(listVersion.map(JSON.stringify))].map(
        JSON.parse
      );
      this.listApprovalStep = listVersion;
      this.view.TabPanel.ListBox0d2a157cf308144.masterData = [
        ...listVersion.map((item) => [
          item.createdts,
          `${checkActionName(item.action)} - Thời gian thực hiện ${item.createdts
          }`
        ])
      ];
      this.approvalStepCurrent = listVersion[0];
      this.presenter.getApprovalStep({
        fundTransferId: self.detailData.id,
        versionStep: listVersion[0].version,
        stepAction: listVersion[0].action
      });
    }

    const tabDetail = this.view.TabPanel;
    tabDetail.txtMaHoSoLog.text =
      "Mã hồ sơ: " + dataDetailFundTransfer.transferCode || "";
    tabDetail.txtTrangThaiLog.text =
      "Trạng thái: " + dataDetailFundTransfer.status || "";
    tabDetail.txtMaGiaoDichLog.text =
      "Mã giao dịch: " +
      ("ft" in dataDetailFundTransfer ? dataDetailFundTransfer.ft : "");
    tabDetail.txtThoiGianBatDauXuLyLog.text =
      "Mã giao dịch FX: " + (dataDetailFundTransfer.fx && dataDetailFundTransfer.fx !== undefined ? dataDetailFundTransfer.fx : "");
    tabDetail.txtThoiDiemHetHanLog.text =
      "Thời điểm hết hạn: " +
      $convertToHmsDDMMYYYY(dataDetailFundTransfer.duets || "");
    tabDetail.txtThoiGianKetThucXuLyLog.text =
      "Thời điểm khởi tạo yêu cầu: " +
      $convertToHmsDDMMYYYY(dataDetailFundTransfer.createdts || "");
    tabDetail.dgLog.setData(
      convertData.map((item) => {
        return {
          ...item,
          action: item.action
        };
      }) || []
    );
    tabDetail.CopydgLog0e12a4c0504204f.setData(
      this.listApprovalStep.map((item) => {
        return {
          ...item,
          action: checkActionName(item.action)
        };
      }) || []
    );
    this.view.TabPanel.Label0bdf5246ff60a4b.isVisible = convertData.length
      ? false
      : true;

    //Docking header
    var element = document.querySelector(
      "#frmDetailAndLog_TabPanel_dgLog > thead"
    );
    $dockHeaderForDataGrid(element);
    $hideLoading(this.view);
  },
  handleClickRowHistory(eventobject) {
    const selecteditem = eventobject.selecteditem;
    $showLoading(this.view);
    const dataSelect = this.listApprovalStep.filter(
      (item) => item.createdts === selecteditem.createdts
    );
    this.approvalStepCurrent = dataSelect[0];
    this.presenter.getApprovalStep({
      fundTransferId: this.detailData.id,
      versionStep: dataSelect[0].version,
      stepAction: dataSelect[0].action
    });
  },
  onTabSelected(selectedIndex) {
    const self = this;
    if (selectedIndex === 0) {
      this.approvalStepFirstLoad = true;
      //Do anything
    } else if (selectedIndex === 3) {
      this.presenter.getApprovalStep({ fundTransferId: self.detailData.id });
    }
  },
  backToListPage() {
    this.setEnabledToFormBoSung(false);
    this.responseData = {};
    this.dataForLogAssign = {};
    this.fieldFt.isVisible = false;
    this.fieldFx.isVisible = false;
    this.fieldFt = {};
    this.fieldFx = {};
    this.buttons = {};
    this.showListView();
    this.attachFiles = [];
    this.setEnabledWhenIsUpdateLevel(false);
    this.files = [];
    this.fileUploadToS3 = {};
    $hideToastMessage(this.view.flxToastMessage);
    this.handleSearchAllRecords();
    this.view.Button0a8863fe63a4e45.isVisible = false;
    this.view.CopyButton0c512b924758348.isVisible = false;
    this.view.CopyButton0a7f9b54ae4144e.isVisible = false;
    this.view.CopyButton0cc4f139ab6a742.isVisible = false
    this.approvalStepFirstLoad = true;
    this.view.TabPanel.CopyFlexContainer0f9a94bcb4a9148.isVisible = true
    const div = document.getElementById("frmDetailAndLog_TabPanel_FlexContainer0e87ac447008144");
    div.innerHTML = "";
  },
  setGeneralInfor(uiSaver, data) {
    uiSaver.txtMaHoSo.text = "Mã hồ sơ: " + data.transferCode || "";
    uiSaver.txtTrangThai.text = "Trạng thái: " + data.status || "";
    uiSaver.txtMaGiaoDich.text =
      "Mã giao dịch: " + ("ft" in data ? data.ft : "");
    uiSaver.txtThoiGianKhoiTaoYeuCau.text =
      "Thời điểm khởi tạo yêu cầu: " +
      $convertToHmsDDMMYYYY(data.createdts || "");
    uiSaver.txtThoiDiemHetHan.text =
      "Thời điểm hết hạn: " + $convertToHmsDDMMYYYY(data.duets || "");
    uiSaver.txtMaGiaoDichFX.text =
      "Mã giao dịch FX: " + ("fx" in data ? data.fx : "");
  },
  createNostroSearchBox() {
    const cssProperties = {
      width: "25%",
      maxHeight: "150px",
      left: "75%",
      top: "180px"
    };
    const list5003 = this.listNostro.filter(
      (nostro) => nostro.category === "5003"
    );
    $createSearchBoxForTextBox(
      this.form.txtTaiKhoanNostro,
      cssProperties,
      list5003,
      ["category", "currency", "accountNumber", "accountName"],
      "accountNumber",
      this.view.TabPanel.flxContainerFundTransfer,
      (nostro) => {
        this.form.lblTenNostro.toolTip = nostro.accountName;
        if (this.detailUI.lbKenhGiaoDich.selectedKey === CHANNEL.Nostro && nostro.currency !== this.detailData.foreinCurrency) {
          this.showErrorMessage("Loại tiền tài khoản Nostro khác loại ngoại tệ chuyển.");
          return;
        }
        this.showSuccessMessage(
          `Bạn đã chọn tài khoản ${nostro.accountName} ${nostro.accountNumber}`
        );
      }
    );
  },
  createKenhGiaoDich() {
    const self = this
    this.flxKenhGiaoDich.removeAll();
    const displays = this.listChannels.map(
      (channel) => `${channel.name} - ${channel.code}`
    );
    const keys = this.listChannels.map((channel) => channel.code);
    this.detailUI.lbKenhGiaoDich = $createListBox(displays, keys, {
      width: "100%",
      height: "100%",
      skin: "skinListBoxContentTable"
    });
    this.detailUI.lbKenhGiaoDich.onSelection = (lb) => {
      const channelSelected = lb.selectedKey;
      const handleSelect = () => {
        //Validate số lượng kí tự nội dung chuyển tiền
        const noiDungChuyenTien = [];
        this.noiDungChuyenTienTextBoxs.forEach((key) => {
          if (!$isNullOrEmpty($trim(key.text)))
            noiDungChuyenTien.push($trim(key.text));
        });
        const noiDungCT = noiDungChuyenTien.join('');
        const isOverLengthNostro = channelSelected === CHANNEL.Nostro && noiDungCT.length > 140;
        const isOverLengthNium = channelSelected !== CHANNEL.Nostro && noiDungCT.length > 255;
        if (isOverLengthNostro || isOverLengthNium) {
          this.showErrorMessage("Vượt quá số lượng kí tự trường Nội dung thanh toán nên không thể chuyển kênh.");
          this.detailUI.lbKenhGiaoDich.selectedKey = this.detailData.channelCode;
          return;
        }
        //Validate số lượng kí tự địa chỉ người chuyển
        const diaChi = [];
        this.diaChiNguoiChuyenTextBoxs.forEach((key) => {
          if (!$isNullOrEmpty($trim(key.text)))
            diaChi.push($trim(key.text));
        });
        const diaChiKH = diaChi.join('');
        const isOverLengthNostroDC = channelSelected === CHANNEL.Nostro && diaChiKH.length > 70;
        let isOverLengthNiumDC = false;
        if (channelSelected !== CHANNEL.Nostro) {
          if (["AUD", "GBP", "USD", "SGD", "CAD", "JPY"].includes(this.detailData.foreinCurrency) && diaChiKH.length > 255) {
            isOverLengthNiumDC = true;
          }
          if (this.detailData.foreinCurrency === "NZD" && diaChiKH.length > 70) {
            isOverLengthNiumDC = true;
          }
          if (this.detailData.foreinCurrency === "EUR" && diaChiKH.length > 140) {
            isOverLengthNiumDC = true;
          }
        }
        if (isOverLengthNostroDC || isOverLengthNiumDC) {
          this.showErrorMessage("Vượt quá số lượng kí tự trường Địa chỉ người chuyển nên không thể chuyển kênh.");
          this.detailUI.lbKenhGiaoDich.selectedKey = this.detailData.channelCode;
          return;
        }
        //Validate 
        const diaChiNguoiHuong = [];
        this.diaChiNguoiHuongTextBoxs.forEach((key) => {
          if (!$isNullOrEmpty($trim(key.text)))
            diaChiNguoiHuong.push($trim(key.text));
        });
        const diaChiNH = diaChiNguoiHuong.join('');
        const isOverLengthNostroDCNH = channelSelected === CHANNEL.Nostro && diaChiNH.length > 70;
        const isOverLengthNiumDCNH = channelSelected !== CHANNEL.Nostro && diaChiNH.length > 200;
        if (isOverLengthNostroDCNH || isOverLengthNiumDCNH) {
          this.showErrorMessage("Vượt quá số lượng kí tự trường Địa chỉ người thụ hưởng nên không thể chuyển kênh.");
          this.detailUI.lbKenhGiaoDich.selectedKey = this.detailData.channelCode;
          return;
        }
        const diaChiNganHangHuong = [];
        this.nganHangThuHuongTextBoxs.forEach((key) => {
          if (!$isNullOrEmpty($trim(key.text)))
            diaChiNganHangHuong.push($trim(key.text));
        });
        // if (channelSelected === CHANNEL.Nostro && $isNullOrEmpty(diaChiNganHangHuong.join(''))) {
        //   this.showErrorMessage("Không được để trống trường Địa chỉ ngân hàng hưởng.");
        //   this.detailUI.lbKenhGiaoDich.selectedKey = this.detailData.channelCode;
        //   return;
        // }
        if ([CHANNEL.Nostro, CHANNEL.NiumSwift].includes(channelSelected) && $isNullOrEmpty(this.detailUI.txtSwiftCodeNganHangThuHuong)) {
          this.showErrorMessage("Không được để trống trường Mã Swift.");
          this.detailUI.lbKenhGiaoDich.selectedKey = this.detailData.channelCode;
          return;
        }
        if (this.detailData.channelCode === CHANNEL.NiumLocal &&
          channelSelected === CHANNEL.Nostro &&
          ["AUD", "GBP"].includes(this.detailData.foreinCurrency) &&
          $isNullOrEmpty(this.detailUI.txtSwiftCodeNganHangThuHuong.text) &&
          $isNullOrEmpty(diaChiNganHangHuong.join(""))
        ) {
          this.showErrorMessage("Không được để trống cả Mã swift và Địa chỉ ngân hàng hưởng.");
          this.detailUI.lbKenhGiaoDich.selectedKey = this.detailData.channelCode;
          return;
        }
        const required = channelSelected === CHANNEL.Nostro ||
          this.detailData.foreinCurrency === "AUD" ||
          (channelSelected === CHANNEL.NiumSwift && this.detailData.foreinCurrency === "GBP") ||
          (channelSelected === CHANNEL.NiumLocal && this.detailData.foreinCurrency === "USD") ||
          (channelSelected === CHANNEL.NiumLocal && this.detailData.foreinCurrency === "SGD") ||
          this.detailData.foreinCurrency === "CAD" ||
          (channelSelected === CHANNEL.NiumLocal && this.detailData.foreinCurrency === "JPY");
        if (required && $isNullOrEmpty(diaChiNguoiHuong)) {
          this.showErrorMessage("Không được để trống trường địa chỉ người hưởng.");
          this.detailUI.lbKenhGiaoDich.selectedKey = this.detailData.channelCode;
          return;
        }
        // validate các trường
        this.validateChannel(
          channelSelected,
          this.setMaxLengthTheoKenh(this.detailData)
        );
      }
      self.showPopup("Bạn có chắc chắn muốn chuyển kênh thanh toán không?", handleSelect, () => {
        self.detailUI.lbKenhGiaoDich.selectedKey = self.detailData.channelCode;
      })
    };
    const contentFlxKenhGiaoDich = [
      [
        $createLabel("Kênh giao dịch", { skin: "titleInforKey" }),
        this.detailUI.lbKenhGiaoDich
      ]
    ];
    $createTable(this.flxKenhGiaoDich, contentFlxKenhGiaoDich, {
      oddColumnSkin: "rowTitleLeft",
      evenColumnSkin: "rowTitleRight",
      rowHeight: this.generalHeight + "px"
    });
  },
  showDetailInfo(data) {
    this.changeAdditionalData = [];
    const self = this;
    // set giá trị cho các phần thông tin chung
    this.setGeneralInfor(this.detailUI, data);
    this.setGeneralInfor(this.detailUIDocuments, data);
    this.setGeneralInfor(this.detailUIFundTransfer, data);
    //Set giá trị
    this.createKenhGiaoDich();
    if (this.detailUI.lbCountry.masterData.length === 0) {
      this.createCountryListBox();
    }
    this.detailUI.lbKenhGiaoDich.selectedKey = data.channelCode || "";
    this.setMaxLengthTheoKenh(data);
    this.detailUI.txtSoDienThoai.text = data.customerPhone || "";
    this.detailUI.txtEmail.text = data.customerEmail || "";
    this.detailUI.txtThanhPhoNguoiChuyen.text = data.customerCity || "";
    this.detailUI.txtMaBuuChinhNguoiChuyen.text =
      data.customerPostcode || "00000";
    this.detailUI.txtLoaiTaiKhoanNguoiChuyen.text =
      data.customerAccountType || "Individual";
    this.detailUI.txtQuanHuyenNguoiChuyen.text = data.customerState || "";
    this.detailUI.txtLoaiGiayToTuyThan.text =
      data.customerIdentificationType || "Legal ID";
    this.detailUI.txtSoGiayToTuyThan.text =
      data.customerId || "";
    this.detailUI.txtMaQuocGiaNguoiChuyen.text =
      data.customerCountryCode || "VN";
    this.detailUI.txtNgaySinhCuaNguoiChuyen.text = $convertToYYYYMMDD(
      data.customerDob || ""
    );
    this.detailUI.txtMaKhachHang.text = data.cifNumber || "";
    this.detailUI.txtLoaiTaiKhoanNganHangNguoiHuong.text =
      data.beneficiaryBankAccountType || "";
    this.detailUI.txtLoaiTaiKhoanNguoiHuong.text =
      $toTitleCase(data.beneficiaryAccountType || "");
    this.detailUI.txtThanhPhoNguoiThuHuong.text = data.beneficiaryCity || "";
    this.detailUI.txtBangNguoiThuHuong.text = data.beneficiaryState || "";
    this.detailUI.txtMaBuuChinhNguoiHuong.text = data.beneficiaryPostcode || "";
    this.detailUI.txtNgoaiTeChuyenDoi.text = data.localConversionCurrency || "";
    this.detailUI.txtLoaiMaNganHangHuong.text = (data.routingCodeType || "").replace("_", " ");
    this.detailUI.txtQuocGiaNguoiThuHuong.text = this.getDisplayCountry(
      data.countryCode || DEFAULT_COUNTRY_CODE
    );
    this.detailUI.txtMaKhachHang2.text = this.detailUI.txtMaKhachHang.text;
    this.detailUI.lbPhanLoaiKhachHang.selectedKey =
      data.customerType;
    this.detailUI.txtMucDichChuyenTien.text =
      data.transferPurposeName.name || "";
    this.detailUI.txtMucDichChuyenTien2.text =
      data.channelCode === CHANNEL.Nostro
        ? data.transferPurposeName.t24Code || ""
        : data.transferPurposeName.niumCode || "";
    this.detailUI.txtMucDichChuyenTien2.toolTip =
      data.transferPurposeName.name || "";
    this.detailUI.txtCaiDatTuDongChuyenTien.text = data.autoTransfer ? "Có" : "Không";
    const loaiTien = ($isNullOrEmpty(data.maximumAmountAutoTransfer) || data.maximumAmountAutoTransfer == 0) ? "" : data.debitAccountType || "";
    this.detailUI.txtSoTienToiDaKHDongYChiTra.text = data.debitAccountType === "VND" ? $getDisplayFee($formatMoney(data.maximumAmountAutoTransfer || ""), loaiTien, false, " ") : "";
    this.detailUI.txtMaUuDai.text = data.rateCoupon || "";
    this.detailUI.txtQuanHeNhanThan.text = data.relationship || "";
    this.detailUI.txtTenNguoiThuHuong.text = data.beneficiaryName || "";
    const initialTenNguoiThuHuong = !(data.beneficiaryName || "").includes(SEPARATOR_OPERATOR) && (data.beneficiaryName || "").length > 35 ?
      $insertCharacterAtPosition(data.beneficiaryName || "", SEPARATOR_OPERATOR, 35) :
      $removeDashes(data.beneficiaryName || "");
    const tenNguoiThuHuong = initialTenNguoiThuHuong.split(SEPARATOR_OPERATOR);
    let notEmptyTxtCountTenNguoiThuHuong = 0;
    if (this.tenNguoiThuHuongTextBoxs.length > 0) {
      this.tenNguoiThuHuongTextBoxs.forEach((key, index) => {
        key.text = tenNguoiThuHuong[index];
        key.isVisible = !$isNullOrEmpty(key.text);
      });
      this.detailUI.txtTenNguoiThuHuong.isVisible = true;
      for (var i = this.tenNguoiThuHuongTextBoxs.length - 1; i >= 1; i--) {
        if (!$isNullOrEmpty(this.tenNguoiThuHuongTextBoxs[i].text))
          notEmptyTxtCountTenNguoiThuHuong++;
      }
      this.tableThongTinNguoiThuHuongLeft[2].height =
        this.generalHeight * (notEmptyTxtCountTenNguoiThuHuong + 1) + "px";
      this.tableThongTinNguoiThuHuongLeft[3].height =
        this.generalHeight * (notEmptyTxtCountTenNguoiThuHuong + 1) + "px";
      this.tableThongTinNguoiThuHuongLeft[4].top =
        this.generalHeight * (notEmptyTxtCountTenNguoiThuHuong + 2) + "px";
      this.tableThongTinNguoiThuHuongLeft[5].top =
        this.generalHeight * (notEmptyTxtCountTenNguoiThuHuong + 2) + "px";
      this.tableThongTinNguoiThuHuongLeft[6].top =
        this.generalHeight * (notEmptyTxtCountTenNguoiThuHuong + 3) + "px";
      this.tableThongTinNguoiThuHuongLeft[7].top =
        this.generalHeight * (notEmptyTxtCountTenNguoiThuHuong + 3) + "px";
    }
    this.detailUI.txtSoTaiKhoanNguoiHuong.text =
      data.beneficiaryAccountNumber || "";
    this.detailUI.txtTenNganHangThuHuong.text = data.beneficiaryBank || "";
    if (
      data.foreinCurrency === "USD" &&
      data.beneficiaryCountryCode === "US" &&
      (data.channelCode === CHANNEL.NiumLocal ||
        data.channelCode === CHANNEL.NiumSwift)
    ) {
      this.detailUI.txtNgoaiTeChuyenDoi.text =
        data.localConversionCurrency || "USD";
    }
    this.detailUI.txtTaiKhoanChuyen.text = $getDisplayFee(data.debitAccountNumber || "", data.debitAccountType || "");
    this.detailUI.txtSwiftCodeNganHangThuHuong.text = data.swiftCode || "";
    this.detailUI.lblSwiftCodeNganHangThuHuong.text = data.swiftCodeValid
      ? "Valid swift code"
      : "Invalid swift code";
    this.detailUI.lblSwiftCodeNganHangThuHuong.skin = data.swiftCodeValid
      ? "greenLabel"
      : "skinRedLabel";
    this.detailUI.lblSwiftCodeNganHangThuHuong.isVisible = !$isNullOrEmpty(this.detailUI.txtSwiftCodeNganHangThuHuong.text);
    this.detailUI.txtSwiftCodeNganHangTrungGian.text =
      data.intermediaryBankCode || "";
    this.detailUI.txtNganHangTrungGian.text = data.intermediaryBankName || "";
    this.detailUI.txtHinhThucNhap.text =
      Boolean(data.manualSwiftCode) ? "Nhập thủ công" : "Nhập theo SwiftCode";
    if (!data.manualSwiftCode) {
      this.detailUI.lblBSBorRouting.text = "BSB/Transit/Sort code/Khác";
    } else {
      this.detailUI.lblBSBorRouting.text =
        "Số Routing/UID/Fedwire/SortCode/Khác";
    }
    this.detailUI.txtBSBorRouting.onTextChange = (txt) => {
      const text = $trim(txt.text);
      this.detailUI.txtBSBorRouting.text = text;
      if ($isContainsVietnamese(text)) {
        this.showErrorMessage("Vui lòng nhập tiếng Anh.");
        return;
      }
      if (!this.detailData.manualSwiftCode) {
        this.detailData.beneficiaryBankIdentifierCode = text;
      } else {
        this.detailData.extraCode = text;
      }
    };
    if (typeof data.autoTransfer === "boolean") {
      this.detailUI.txtTiGiaNgoaiTe.text = (this.isHoSoCompleted(data.status) && data.rateCoupon !== undefined) ? $formatMoney(data.listedRate || "") : (data.rateCoupon === undefined ? $formatMoney(data.listedRate || "") : "");
    } else {
      this.detailUI.txtTiGiaNgoaiTe.text = $formatMoney(data.listedRate || "");
    }

    this.detailUI.txtTiGiaUSDNiemYet.text = $formatMoney(data.usdListedRate || "");
    this.detailUI.txtTiGiaApDung.text = $formatMoney(data.exchangeRate || "");
    this.detailUI.txtSoTienQuyDoi.text = $formatMoney(data.exchangeAmount || "");
    this.detailUI.txtSoTienGiaoDichThucTe.text = $formatMoney(data.transferAmount || "");
    this.detailUI.txtSoTienGiaoDichThucTe2.text =
      this.detailUI.txtSoTienGiaoDichThucTe.text;
    this.detailUI.txtLoaiTienGiaoDich.text = data.foreinCurrency || "";
    this.detailUI.txtLoaiTienGiaoDich2.text =
      this.detailUI.txtLoaiTienGiaoDich.text;
    this.detailUI.txtSoTienGiaoDich.text = $formatMoney(data.foreinAmount || "");
    this.detailUI.txtNgayXacNhanGiaoDich.text = $convertToDDMMYYYY(data.confirmationDate || "");
    this.detailUI.txtNgayThucHienGiaoDich.text = $convertToDDMMYYYY(data.executionDate || "");
    this.detailUI.txtBenChiuPhi.text = data.benOurCharge || "";
    this.detailUI.txtTaiKhoanChiuPhi.text = $getDisplayFee(data.feeAccountNumber || "", data.feeAccountType || "");
    const isDisplayZero = !$isNullOrEmpty(data.executionDate || "");
    if (data.autoTransfer !== undefined) {
      this.detailUI.txtDienPhi.text = this.isHoSoCompleted(data.status) ? $getDisplayFee(data.swiftFeeCode || "", $formatMoney(data.swiftFee || ""), isDisplayZero) : "";
      this.detailUI.txtTongPhi.text = this.isHoSoCompleted(data.status) ? $getDisplayFee(data.totalFeeCurrency || "", $formatMoney(data.totalFeeAmount || ""), isDisplayZero) : "";
      this.detailUI.txtPhiTrongNuoc.text = this.isHoSoCompleted(data.status) ? $getDisplayFee(data.domesticFeeCode || "", $formatMoney(data.domesticFeeAmount || ""), isDisplayZero) : "";
      this.detailUI.txtPhiNuocNgoai.text = this.isHoSoCompleted(data.status) ? $getDisplayFee(data.internationalFeeCode || "", $formatMoney(data.internationalFeeAmount || ""), isDisplayZero) : "";
    } else {
      this.detailUI.txtDienPhi.text = $getDisplayFee(data.domesticFeeCode || "", $formatMoney(data.domesticFeeAmount || ""), isDisplayZero);
      this.detailUI.txtPhiTrongNuoc.text = $getDisplayFee(data.internationalFeeCode || "", $formatMoney(data.internationalFeeAmount || ""), isDisplayZero);
      this.detailUI.txtPhiNuocNgoai.text = $getDisplayFee(data.swiftFeeCode || "", $formatMoney(data.swiftFee || ""), isDisplayZero);
      this.detailUI.txtTongPhi.text = $getDisplayFee(data.totalFeeCurrency || "", $formatMoney(data.totalFeeAmount || ""), isDisplayZero);
    }
    const initialNoiDungChuyenTien = !(data.paymentNoteEn || "").includes(SEPARATOR_OPERATOR) ?
      $splitStringBySeparatorOperator(data.paymentNoteEn || "") :
      $removeDashes(data.paymentNoteEn || "");
    const noiDungChuyenTien = initialNoiDungChuyenTien.split(SEPARATOR_OPERATOR);
    let notEmptyTxtCountNoiDungChuyenTien = 0;
    if (this.noiDungChuyenTienTextBoxs.length > 0) {
      this.noiDungChuyenTienTextBoxs.forEach((key, index) => {
        key.text = noiDungChuyenTien[index];
        key.isVisible = !$isNullOrEmpty(key.text);
      });
      for (var i = this.noiDungChuyenTienTextBoxs.length - 1; i >= 1; i--) {
        if (!$isNullOrEmpty(this.noiDungChuyenTienTextBoxs[i].text))
          notEmptyTxtCountNoiDungChuyenTien++;
      }
      this.detailUI.txtNoiDungChuyenTien.isVisible = true;
      this.tableThongTinGiaoDichLeft[4].height =
        this.generalHeight * (notEmptyTxtCountNoiDungChuyenTien + 1) + "px";
      this.tableThongTinGiaoDichLeft[5].height =
        this.generalHeight * (notEmptyTxtCountNoiDungChuyenTien + 1) + "px";
    }
    this.flxThongTinGiaoDich.height = $isGreaterThan($getElementTop(this.tableThongTinGiaoDichLeft[5]),
      this.generalHeight * 3 + "px") ? $getElementTop(this.tableThongTinGiaoDichLeft[5]) : this.generalHeight * 3 + "px";

    const initialDiaChiNganHangHuong = !(data.beneficiaryBankAddress || "").includes(SEPARATOR_OPERATOR) && (data.beneficiaryBankAddress || "").length > 35 ?
      $insertCharacterAtPosition(data.beneficiaryBankAddress || "", SEPARATOR_OPERATOR, 35) :
      $removeDashes(data.beneficiaryBankAddress || "");
    const diaChiNganHangHuong = initialDiaChiNganHangHuong.split(SEPARATOR_OPERATOR);
    if (this.nganHangThuHuongTextBoxs.length > 0) {
      this.nganHangThuHuongTextBoxs.forEach((key, index) => {
        key.text = diaChiNganHangHuong[index];
        key.isVisible = !$isNullOrEmpty(key.text);
      });
      this.detailUI.txtDiaChiNganHangHuong.isVisible = true;
      let notEmptyTxtCount = 0;
      for (var i = this.nganHangThuHuongTextBoxs.length - 1; i >= 1; i--) {
        if (!$isNullOrEmpty(this.nganHangThuHuongTextBoxs[i].text))
          notEmptyTxtCount++;
      }
      this.tableThongTinNganHangThuHuongRight[4].height =
        this.generalHeight * (notEmptyTxtCount + 1) + "px";
      this.tableThongTinNganHangThuHuongRight[5].height =
        this.generalHeight * (notEmptyTxtCount + 1) + "px";
    }
    const initialName = !(data.customerNameEn || "").includes(SEPARATOR_OPERATOR) && (data.customerNameEn || "").length > 35 ?
      $insertCharacterAtPosition(data.customerNameEn || "", SEPARATOR_OPERATOR, 35) :
      $removeDashes(data.customerNameEn || "");
    const tenKhachHang = initialName.split(SEPARATOR_OPERATOR);
    let notEmptyTxtCountTenKH = 0;
    if (this.tenKhachHangTextBoxs.length > 0) {
      this.tenKhachHangTextBoxs.forEach((key, index) => {
        key.text = tenKhachHang[index];
        key.isVisible = !$isNullOrEmpty(key.text);
      });
      for (var i = this.tenKhachHangTextBoxs.length - 1; i >= 1; i--) {
        if (!$isNullOrEmpty(this.tenKhachHangTextBoxs[i].text))
          notEmptyTxtCountTenKH++;
      }
      this.detailUI.txtTenKhachHang.isVisible = true;
      this.tableThongTinNguoiChuyenTienLeft[2].height =
        this.generalHeight * (notEmptyTxtCountTenKH + 1) + "px";
      this.tableThongTinNguoiChuyenTienLeft[3].height =
        this.generalHeight * (notEmptyTxtCountTenKH + 1) + "px";
      this.tableThongTinNguoiChuyenTienLeft[4].top =
        this.generalHeight * (notEmptyTxtCountTenKH + 2) + "px";
      this.tableThongTinNguoiChuyenTienLeft[5].top =
        this.generalHeight * (notEmptyTxtCountTenKH + 2) + "px";
      this.tableThongTinNguoiChuyenTienLeft[6].top =
        this.generalHeight * (notEmptyTxtCountTenKH + 3) + "px";
      this.tableThongTinNguoiChuyenTienLeft[7].top =
        this.generalHeight * (notEmptyTxtCountTenKH + 3) + "px";
    }

    this.detailUI.txtTenKhachHang2.text = (data.customerName || "").replace(SEPARATOR_OPERATOR, " ");
    let quocGiaTheoNganHang = "";
    if ($isNullOrEmpty(data.beneficiaryCountryCode || "")) {
      quocGiaTheoNganHang = data.countryCode || DEFAULT_COUNTRY_CODE;
    }
    else {
      quocGiaTheoNganHang = data.beneficiaryCountryCode;
    }
    this.detailUI.lbCountry.selectedKey = quocGiaTheoNganHang;
    this.detailUI.lblCountry.text = this.getDisplayCountry(quocGiaTheoNganHang);
    const initialDiaChiNguoiChuyen = !(data.customerAddressEn || "").includes(SEPARATOR_OPERATOR) ?
      $splitStringBySeparatorOperator(data.customerAddressEn || "") :
      $removeDashes(data.customerAddressEn || "");
    const diaChiNguoiChuyen = initialDiaChiNguoiChuyen.split(SEPARATOR_OPERATOR);
    let notEmptyTxtCountDiaChi = 0;
    if (this.diaChiNguoiChuyenTextBoxs.length > 0) {
      this.diaChiNguoiChuyenTextBoxs.forEach((key, index) => {
        key.text = diaChiNguoiChuyen[index];
        key.isVisible = !$isNullOrEmpty(key.text);
      });
      for (var i = this.diaChiNguoiChuyenTextBoxs.length - 1; i >= 1; i--) {
        if (!$isNullOrEmpty(this.diaChiNguoiChuyenTextBoxs[i].text))
          notEmptyTxtCountDiaChi++;
      }
      this.detailUI.txtDiaChi.isVisible = true;
      this.tableThongTinNguoiChuyenTienLeft[4].height =
        this.generalHeight * (notEmptyTxtCountDiaChi + 1) + "px";
      this.tableThongTinNguoiChuyenTienLeft[5].height =
        this.generalHeight * (notEmptyTxtCountDiaChi + 1) + "px";
      this.tableThongTinNguoiChuyenTienLeft[6].top =
        this.generalHeight * (notEmptyTxtCountTenKH + notEmptyTxtCountDiaChi + 3) + "px";
      this.tableThongTinNguoiChuyenTienLeft[7].top =
        this.generalHeight * (notEmptyTxtCountTenKH + notEmptyTxtCountDiaChi + 3) + "px";
    }
    this.flxThongTinNguoiChuyen.height = $isGreaterThan($getElementTop(this.tableThongTinNguoiChuyenTienLeft[7]),
      this.generalHeight * 7 + "px") ? $getElementTop(this.tableThongTinNguoiChuyenTienLeft[7]) : this.generalHeight * 7 + "px";
    this.detailUI.txtDiaChi2.text = data.customerAddress || "";

    const initialDiaChiNguoiHuong = !(data.beneficiaryAddressEn || "").includes(SEPARATOR_OPERATOR) ?
      $splitStringBySeparatorOperator(data.beneficiaryAddressEn || "") :
      $removeDashes(data.beneficiaryAddressEn || "");
    const diaChiNguoiHuong = initialDiaChiNguoiHuong.split(SEPARATOR_OPERATOR);
    let notEmptyTxtCountDiaChiNguoiHuong = 0;
    if (this.diaChiNguoiHuongTextBoxs.length > 0) {
      this.diaChiNguoiHuongTextBoxs.forEach((key, index) => {
        key.text = diaChiNguoiHuong[index];
        key.isVisible = !$isNullOrEmpty(key.text);
      });
      for (var i = this.diaChiNguoiHuongTextBoxs.length - 1; i >= 1; i--) {
        if (!$isNullOrEmpty(this.diaChiNguoiHuongTextBoxs[i].text))
          notEmptyTxtCountDiaChiNguoiHuong++;
      }
      this.detailUI.txtDiaChiNguoiThuHuong.isVisible = true;
      this.tableThongTinNguoiThuHuongLeft[4].height =
        this.generalHeight * (notEmptyTxtCountDiaChiNguoiHuong + 1) + "px";
      this.tableThongTinNguoiThuHuongLeft[5].height =
        this.generalHeight * (notEmptyTxtCountDiaChiNguoiHuong + 1) + "px";
      this.tableThongTinNguoiThuHuongLeft[6].top =
        this.generalHeight * (notEmptyTxtCountTenNguoiThuHuong + notEmptyTxtCountDiaChiNguoiHuong + 3) + "px";
      this.tableThongTinNguoiThuHuongLeft[7].top =
        this.generalHeight * (notEmptyTxtCountTenNguoiThuHuong + notEmptyTxtCountDiaChiNguoiHuong + 3) + "px";
    }
    this.flxThongTinNguoiThuHuong.height = $isGreaterThan($getElementTop(this.tableThongTinNguoiThuHuongLeft[7]),
      this.generalHeight * 5 + "px") ? $getElementTop(this.tableThongTinNguoiThuHuongLeft[7]) : this.generalHeight * 5 + "px";
    this.reRenderUIThongTinGiaoDich();
    const { extraCode = "", beneficiaryBankIdentifierCode = "", routingCode = "" } = this.fundTransferAdditionalInitial;
    const isNew = $isEmptyObject(this.fundTransferAdditionalInitial);
    if (data.channelCode === CHANNEL.Nostro) {
      if (data.manualSwiftCode && data.foreinCurrency === "USD") {
        this.detailUI.txtBSBorRouting.text = isNew ? data.beneficiaryBankIdentifierCode || "" : beneficiaryBankIdentifierCode || "";
      } else {
        this.detailUI.txtBSBorRouting.text = isNew ? data.extraCode || "" : extraCode || "";
      }
    } else {
      this.detailUI.txtBSBorRouting.text = isNew ? data.routingCode || "" : routingCode || "";
    }
    const levelDefinition = (
      this.responseData.approvalLevel
        ? this.responseData.approvalLevel.levelDefinition || ""
        : ""
    ).split(",");
    if (levelDefinition[0] !== "") {
      this.levelDefinition = levelDefinition;
    } else {
      this.levelDefinition = [];
    }
    this.createToolTip();
    this.createCustomerDocuments(this.flxCustomDocumentInformation);
    this.createNostroSearchBox();
    this.paymentModel = data.paymentModel || null;
    this.detailUI.txtMoHinhThanhToan.text =
      PAYMENT_MODEL_NAME[this.paymentModel] || null;
    if ($isEmptyObject(this.responseData.fundTransferAdditional || {})) {
      this.showAddtionalInformationDefault();
      this.isNewAdditional = true;
    } else {
      this.isNewAdditional = false;
      this.showAddtionalInformation(this.responseData.fundTransferAdditional);
    }
    this.createButtonForForm();
    this.setEnabledWhenIsUpdateLevel(false);
    const isAssigned =
      !Object.values(APPROVAL_LEVEL_STATUS).includes(
        this.detailData.approvalLevel
      ) && this.detailData.assigne === this.infoUser.id.toString();
    if (isAssigned) {
      if (
        $isHasCommonElement(
          ROLE_CAN_UPDATE_FIELD.txtPhanHoiCuaDVKD,
          this.infoUser.roleId
        )
      ) {
        this.form.txtPhanHoiCuaDVKD.setEnabled(true);
      } else {
        this.form.txtPhanHoiCuaDVKD.setEnabled(false);
      }
      if (
        $isHasCommonElement(
          ROLE_CAN_UPDATE_FIELD.txtPhanHoiCuaTTTTQT,
          this.infoUser.roleId
        )
      ) {
        this.form.txtPhanHoiCuaTTTTQT.setEnabled(true);
      } else {
        this.form.txtPhanHoiCuaTTTTQT.setEnabled(false);
      }
      const roleCanUpdateMoTaLyDo = this.paymentModel === PAYMENT_MODEL.Decentralized ?
        ROLE_CAN_UPDATE_FIELD.txtMoTaLyDoChiTiet_Decentrelize :
        ROLE_CAN_UPDATE_FIELD.txtMoTaLyDoChiTiet_Centrelize;
      if ($isHasCommonElement(roleCanUpdateMoTaLyDo, this.infoUser.roleId) && this.form.lbKetQuaKiemTra.selectedKey !== CHECK_RESULT.ValidRecords) {
        this.form.txtMoTaLyDoChiTiet.setEnabled(true);
      } else {
        this.form.txtMoTaLyDoChiTiet.setEnabled(false);
      }
    } else {
      this.form.txtPhanHoiCuaDVKD.setEnabled(false);
      this.form.txtPhanHoiCuaTTTTQT.setEnabled(false);
      this.form.txtMoTaLyDoChiTiet.setEnabled(false);
    }
    //Ẩn hiện nút
    if (this.levelDefinition.length > 0) {
      let isUpdateLevel = false;
      if (this.paymentModel === PAYMENT_MODEL.Decentralized) {
        isUpdateLevel = this.levelDefinition.includes(
          LEVEL_DEFINITION.DecentralizedUpdateDocument
        );
      } else {
        isUpdateLevel = this.levelDefinition.includes(
          LEVEL_DEFINITION.CentralizedUpdateDocument
        );
      }
      this.isHasRoleUpdateDocument =
        isUpdateLevel &&
        $isHasCommonElement(this.roleCanUpdate, this.infoUser.roleId) &&
        this.infoUser.id.toString() === this.detailData.assigne;
      if (this.isHasRoleUpdateDocument) {
        this.setEnabledWhenIsUpdateLevel(true);
        if (
          this.form.lbKetQuaKiemTra.selectedKey !== CHECK_RESULT.ValidRecords
        ) {
          this.setEnabledForUserTable(false);
          this.setEnabledToFormBoSung(false);
          this.form.cbHoSo.setEnabled(true);
          this.form.cbNoChungTu.setEnabled(true);
          this.form.lbKiemTraPCRT.setEnabled(true);
          this.form.attachButton.setEnabled(true);
        }
      }
      if (isAssigned) {
        if (
          $isHasCommonElement(
            ROLE_CAN_UPDATE_FIELD.txtPhanHoiCuaDVKD,
            this.infoUser.roleId
          )
        ) {
          this.form.txtPhanHoiCuaDVKD.setEnabled(true);
        } else {
          this.form.txtPhanHoiCuaDVKD.setEnabled(false);
        }
        if (
          $isHasCommonElement(
            ROLE_CAN_UPDATE_FIELD.txtPhanHoiCuaTTTTQT,
            this.infoUser.roleId
          )
        ) {
          this.form.txtPhanHoiCuaTTTTQT.setEnabled(true);
        } else {
          this.form.txtPhanHoiCuaTTTTQT.setEnabled(false);
        }
      } else {
        this.form.txtPhanHoiCuaDVKD.setEnabled(false);
        this.form.txtPhanHoiCuaTTTTQT.setEnabled(false);
        this.form.txtMoTaLyDoChiTiet.setEnabled(false);
      }
      if (
        isUpdateLevel &&
        !$isHasCommonElement(this.roleCanUpdate, this.infoUser.roleId)
      ) {
        Object.keys(this.buttons).forEach((key) => {
          if (!$isEmptyObject(this.buttons[key]))
            this.buttons[key].setEnabled(false);
        });
        this.buttons.btnHuy.setEnabled(true);
      }
    }
    // Nếu là cấp duyệt thì disable hết
    const isApprovalLevel = !$isEmptyObject(this.buttons.btnDuyet);
    if (isApprovalLevel || data.status === FUND_TRANSFER_STATUS.Expired) {
      this.setEnabledWhenIsUpdateLevel(false);
      this.form.txtPhanHoiCuaDVKD.setEnabled(false);
      this.form.txtPhanHoiCuaTTTTQT.setEnabled(false);
      this.setEnabledToFormBoSung(false);
    }
    if (this.isNewAdditional) {
      this.form.txtMoTaLyDoChiTiet.setEnabled(false);
    }
    this.form.txtSwiftMT103SentTo.setEnabled(false);
    this.view.forceLayout();
    $hideLoading(this.view);
    //check hiển thị button cập nhật thủ công
    const checkShowButton = () => {
      if (
        (data.status === FUND_TRANSFER_STATUS.Comfirmed ||
          data.status === FUND_TRANSFER_STATUS.NotCompleted ||
          data.status === FUND_TRANSFER_STATUS.AwaitingFunds) &&
        (this.infoUser.roleId.includes(ROLE.CVTTQT) ||
          this.infoUser.roleId.includes(ROLE.C1) ||
          this.infoUser.roleId.includes(ROLE.C2))
      ) {
        return (!this.infoUser.roleId.includes(ROLE.ADMIN) && !this.infoUser.roleId.includes(ROLE.VIEW)) ? true : false;
      } else if (
        (data.status === FUND_TRANSFER_STATUS.Comfirmed ||
          data.status === FUND_TRANSFER_STATUS.NotCompleted) &&
        this.infoUser.roleId.includes(ROLE.GDV)
      ) {
        return (!this.infoUser.roleId.includes(ROLE.ADMIN) && !this.infoUser.roleId.includes(ROLE.VIEW)) ? true : false;
      }
      return false;
    };
    if (checkShowButton()) {
      this.view.CopyButton0c512b924758348.isVisible = true;
      const handleCancel = () => {
        self.fieldFt.isVisible = false;
        self.fieldFx.isVisible = false;
        self.fieldFt = {};
        self.fieldFx = {};
      }
      const handleConfirm = () => {
        $showLoading(self.view);
        self.action = ACTION_STEP_NAME.capNhatThuCong;
        self.changeAdditionalData = [];
        self.fieldFt.text &&
          self.changeAdditionalData.push({
            field: "status",
            oldValue: data.status || "-",
            newValue: FUND_TRANSFER_STATUS.Completed || "-"
          });
        self.changeAdditionalData.push({
          field: self.fieldFt.text ? "ft" : "fx",
          oldValue: self.fieldFt.text ? data.ft : data.fx,
          newValue: self.fieldFt.text || self.fieldFx.text
        });
        const bodyLogSteps = {
          action: self.action,
          data: self.changeAdditionalData,
          additionalDataId: null,
          pvbFundTransferId: data.id
        };
        self.presenter.updateFtFxFundTransfer({
          id: data.id,
          ft: self.fieldFt.text,
          fx: self.fieldFx.text,
          steps: bodyLogSteps
        });
        handleCancel()
      }

      this.view.CopyButton0c512b924758348.onClick = () => {
        self.fieldFt = $createTextBox({
          width: "calc(100% - 40px)",
          height: "30px",
          left: "20px",
          skin: "inputCustomFt",
          placeHolder: "Nhập số FT"
        });
        self.fieldFx = $createTextBox({
          width: "calc(100% - 40px)",
          height: "30px",
          left: "20px",
          skin: "inputCustomFt",
          placeHolder: "Nhập số FX"
        });
        const warningMess = $createLabel(
          "Số FT đã nhập sẽ không thể chỉnh sửa, vui lòng kiểm tra kỹ trước khi cập nhật!",
          {
            skin: "warningMess",
            top: "50px",
            left: "20px",
            height: "30px",
          }
        );
        if (self.infoUser.roleId[0] === ROLE.GDV) {
          self.view.CopyflxContainer0h2787d7c044d4e.add(self.fieldFx);
        } else if (
          self.infoUser.roleId[0] === ROLE.CVTTQT ||
          self.infoUser.roleId[0] === ROLE.C1 ||
          self.infoUser.roleId[0] === ROLE.C2
        ) {
          self.view.CopyflxContainer0h2787d7c044d4e.add(self.fieldFt);
          self.view.CopyflxContainer0h2787d7c044d4e.add(warningMess);
        }
        self.showPopup("Cập nhật thủ công", handleConfirm, handleCancel);
      };
    }

    //check hiển thị button tải điện chuyển tiền nium
    if (data.status === FUND_TRANSFER_STATUS.Completed && (data.channelCode === CHANNEL.niumCode || data.channelCode === CHANNEL.NiumSwift)) {
      this.view.CopyButton0cc4f139ab6a742.isVisible = true
      this.view.CopyButton0cc4f139ab6a742.onClick = () => {
        const params = {
          transferCode: data.transferCode || "",
          ft: data.ft || "",
          amount: data.foreinAmount || "",
          cifNumber: data.cifNumber || "",
          countryCode: data.countryCode || "",
          bankCode: data.beneficiaryBank || "",
          swiftCode: data.swiftCode || ""
        }
        self.presenter.getPaymentOrderNium(params)
      }
    }

    //Nếu là trạng thái STATUS_ADD_DOCUMENT thì cho hiển thị nút attach
    if (
      STATUS_ADD_DOCUMENT.includes(data.status) &&
      !this.infoUser.roleId.includes(ROLE.ADMIN) && !this.infoUser.roleId.includes(ROLE.VIEW)
    ) {
      this.form.attachButton.setEnabled(true);
      this.buttons.btnBoSung.setEnabled(true);
    }
    //call api getProcessLog
    this.presenter.getProcessLog({ id: data.id })
  },
  getDisplayCountry(countryCode) {
    if ($isNullOrEmpty(countryCode)) return "";
    const country = this.countries.filter(
      (country) => $trim(country.Code) === $trim(countryCode)
    );
    if (country.length !== 1) return countryCode;
    return `${country[0].Name} - ${country[0].Code}`;
  },
  createToolTip() {
    this.detailUI.txtMaKhachHang.toolTip = this.detailUI.txtMaKhachHang.text;
    this.detailUI.txtMaKhachHang2.toolTip = this.detailUI.txtMaKhachHang2.text;
    this.detailUI.txtTenKhachHang2.toolTip =
      this.detailUI.txtTenKhachHang2.text;
    this.detailUI.txtMucDichChuyenTien.toolTip =
      this.detailUI.txtMucDichChuyenTien.text;
    this.detailUI.txtDiaChi2.toolTip = this.detailUI.txtDiaChi2.text;
    this.detailUI.txtQuanHeNhanThan.toolTip =
      this.detailUI.txtQuanHeNhanThan.text;
    this.detailUI.txtTenNguoiThuHuong.toolTip =
      this.detailUI.txtTenNguoiThuHuong.text;
    this.detailUI.txtSoTaiKhoanNguoiHuong.toolTip =
      this.detailUI.txtSoTaiKhoanNguoiHuong.text;
    this.detailUI.txtNganHangTrungGian.toolTip =
      this.detailUI.txtNganHangTrungGian.text;
    this.detailUI.txtLoaiTienGiaoDich.toolTip =
      this.detailUI.txtLoaiTienGiaoDich.text;
    this.detailUI.txtSoTienGiaoDich.toolTip =
      this.detailUI.txtSoTienGiaoDich.text;
    this.detailUI.txtNgayXacNhanGiaoDich.toolTip =
      this.detailUI.txtNgayXacNhanGiaoDich.text;
    this.detailUI.txtNgayThucHienGiaoDich.toolTip =
      this.detailUI.txtNgayThucHienGiaoDich.text;
    this.detailUI.txtPhiTrongNuoc.toolTip = this.detailUI.txtPhiTrongNuoc.text;
    this.detailUI.txtPhiNuocNgoai.toolTip = this.detailUI.txtPhiNuocNgoai.text;
    this.detailUI.txtNoiDungChuyenTien.toolTip =
      this.detailUI.txtNoiDungChuyenTien.text;
    this.detailUI.txtBSBorRouting.toolTip = this.detailUI.txtBSBorRouting.text;
    this.detailUI.lblCountry.toolTip = this.detailUI.lblCountry.text;
  },
  showAddtionalInformationDefault() {
    this.form.cbHoSo.selectedKey = "KhongNgoaiLe";
    this.form.cbNoChungTu.selectedKey = "Khong";
    this.form.tbRegulatoryReporting.text = "";
    this.form.tbSenderToReceiverInfor.text = "";
    this.senderToReceiverInfoTextBoxs.forEach((key) => {
      key.text = "";
      key.isVisible = false;
    });
    this.f77bTextBoxs.forEach((key) => {
      key.text = "";
      key.isVisible = false;
    });
    this.tableThongTinNganHangThuHuongLeft[14].height =
      this.generalHeight + "px";
    this.tableThongTinNganHangThuHuongLeft[15].height =
      this.generalHeight + "px";
    this.tableThongTinNganHangThuHuongLeft[16].top =
      this.generalHeight * 8 + "px";
    this.tableThongTinNganHangThuHuongLeft[17].top =
      this.generalHeight * 8 + "px";
    this.flxThongTinNganHangThuHuong.height = this.generalHeight * 9 + "px";
    this.reRenderThongTinChuyenTienUI();
    this.form.tbSenderToReceiverInfor.isVisible = true;
    this.form.tbRegulatoryReporting.isVisible = true;
    this.flxButtons.top = $getElementTop(this.flxPhanHoi);
    if ((this.detailData.beneficiaryCountryCode || "") === "AE") {
      if ((this.detailData.transferPurposeName.moneySourceCode || "") === "PR0014") {
        this.form.tbRegulatoryReporting.text = "/BENEFRES/AE//FAM";
      } else {
        this.form.tbRegulatoryReporting.text = "/BENEFRES/AE//PRS";
      }
    }
    this.form.lbKetQuaKiemTra.selectedKey = "";
    this.form.txtMoTaLyDoChiTiet.text = "";
    this.form.lbKiemTraPCRT.selectedKey = "";
    this.form.txtSwiftMT103SentTo.text = "";
    if (this.detailUI.lbKenhGiaoDich.selectedKey === CHANNEL.Nostro) {
      // USD
      if (this.detailData.foreinCurrency === "USD") {
        if (
          this.bankNameChina.includes(
            $trim(this.detailData.intermediaryBankCode || "").toUpperCase()
          ) ||
          this.bankNameChina.includes(
            $trim(this.detailData.swiftCode || "").toUpperCase()
          )
        ) {
          this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.HabibBank;
          this.form.lblTenNostro.toolTip = this.getNostroName(
            NOSTRO_ACCOUNT_NUMBER.HabibBank
          );
        } else {
          this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.MashreqBank;
          this.form.lblTenNostro.toolTip = this.getNostroName(
            NOSTRO_ACCOUNT_NUMBER.MashreqBank
          );
        }
      }
      //AUD
      if (this.detailData.foreinCurrency === "AUD") {
        this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.AUD;
        this.form.lblTenNostro.toolTip = this.getNostroName(
          NOSTRO_ACCOUNT_NUMBER.AUD
        );
      }
      //GBP
      if (this.detailData.foreinCurrency === "GBP") {
        this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.GBP;
        this.form.lblTenNostro.toolTip = this.getNostroName(
          NOSTRO_ACCOUNT_NUMBER.GBP
        );
      }
      //EUR
      if (this.detailData.foreinCurrency === "EUR") {
        this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.EUR;
        this.form.lblTenNostro.toolTip = this.getNostroName(
          NOSTRO_ACCOUNT_NUMBER.EUR
        );
      }
      //SGD
      if (this.detailData.foreinCurrency === "SGD") {
        this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.SGD;
        this.form.lblTenNostro.toolTip = this.getNostroName(
          NOSTRO_ACCOUNT_NUMBER.SGD
        );
      }
      //JPY
      if (this.detailData.foreinCurrency === "JPY") {
        if (!$isNullOrEmpty(this.detailData.swiftCode) && this.detailData.swiftCode.includes("MHCBJPJT")) {
          this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.Mizuho;
          this.form.lblTenNostro.toolTip = this.getNostroName(
            NOSTRO_ACCOUNT_NUMBER.Mizuho
          );
        }
        else {
          this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.JPY;
          this.form.lblTenNostro.toolTip = this.getNostroName(
            NOSTRO_ACCOUNT_NUMBER.JPY
          );
        }
      }
    } else {
      this.form.txtTaiKhoanNostro.text = `${this.detailData.foreinCurrency}1259200010001`;
    }
    this.form.txtPhanHoiCuaDVKD.text = "";
    this.form.txtPhanHoiCuaTTTTQT.text = "";
  },
  getNostroName(nostroNum) {
    if ($isNullOrEmpty(nostroNum)) return "";
    const nostro = this.listNostro.filter(
      (nostro) => nostro.accountNumber === nostroNum
    );
    if (!nostro || nostro.length === 0) return "";
    return nostro[0].accountName;
  },
  showAddtionalInformation({
    nostroAcountNumber,
    isException,
    isDocumentsDebt,
    otherProblem,
    senderToReceiverInfo,
    regulatoryReporting,
    resultCheck,
    pcrtBranch,
    swiftMt103,
    feedbackDvkd,
    feedbackTtTtqt
  }) {
    if ($isNullOrEmpty(nostroAcountNumber)) {
      if (this.detailUI.lbKenhGiaoDich.selectedKey === CHANNEL.Nostro) {
        // USD
        if (this.detailData.foreinCurrency === "USD") {
          if (
            this.bankNameChina.includes(
              $trim(this.detailData.intermediaryBankCode || "").toUpperCase()
            ) ||
            this.bankNameChina.includes(
              $trim(this.detailData.swiftCode || "").toUpperCase()
            )
          ) {
            this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.HabibBank;
            this.form.lblTenNostro.toolTip = this.getNostroName(
              NOSTRO_ACCOUNT_NUMBER.HabibBank
            );
          } else {
            this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.MashreqBank;
            this.form.lblTenNostro.toolTip = this.getNostroName(
              NOSTRO_ACCOUNT_NUMBER.MashreqBank
            );
          }
        }
        //JPY
        if (this.detailData.foreinCurrency === "JPY") {
          if (!$isNullOrEmpty(this.detailData.swiftCode) && this.detailData.swiftCode.includes("MHCBJPJT")) {
            this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.Mizuho;
            this.form.lblTenNostro.toolTip = this.getNostroName(
              NOSTRO_ACCOUNT_NUMBER.Mizuho
            );
          }
          else {
            this.form.txtTaiKhoanNostro.text = NOSTRO_ACCOUNT_NUMBER.JPY;
            this.form.lblTenNostro.toolTip = this.getNostroName(
              NOSTRO_ACCOUNT_NUMBER.JPY
            );
          }
        }
      } else {
        this.form.txtTaiKhoanNostro.text = `${this.detailData.foreinCurrency}1259200010001`;
      }
    }
    else {
      this.form.txtTaiKhoanNostro.text = nostroAcountNumber;
      this.form.lblTenNostro.toolTip = this.getNostroName(
        this.form.txtTaiKhoanNostro.text
      );
    }
    this.form.cbHoSo.selectedKey =
      Boolean(isException) ? "NgoaiLe" : "KhongNgoaiLe";
    this.form.cbNoChungTu.selectedKey =
      Boolean(isDocumentsDebt) ? "No" : "Khong";
    this.form.txtMoTaLyDoChiTiet.text = otherProblem || "";
    const senderToReceiverInfor = (senderToReceiverInfo || "").split(
      SEPARATOR_OPERATOR
    );
    const f77B = (regulatoryReporting || "").split(SEPARATOR_OPERATOR);
    if (this.senderToReceiverInfoTextBoxs.length > 0) {
      this.senderToReceiverInfoTextBoxs.forEach((key, index) => {
        key.text = senderToReceiverInfor[index];
        key.isVisible = !$isNullOrEmpty(key.text);
      });
      let notEmptyTxtCount = 0;
      for (var i = this.senderToReceiverInfoTextBoxs.length - 1; i >= 1; i--) {
        if (!$isNullOrEmpty(this.senderToReceiverInfoTextBoxs[i].text))
          notEmptyTxtCount++;
      }
      this.tableThongTinNganHangThuHuongLeft[14].height =
        this.generalHeight * (notEmptyTxtCount + 1) + "px";
      this.tableThongTinNganHangThuHuongLeft[15].height =
        this.generalHeight * (notEmptyTxtCount + 1) + "px";
      this.tableThongTinNganHangThuHuongLeft[16].top =
        this.generalHeight * (notEmptyTxtCount + 8) + "px";
      this.tableThongTinNganHangThuHuongLeft[17].top =
        this.generalHeight * (notEmptyTxtCount + 8) + "px";
      this.flxThongTinNganHangThuHuong.height =
        this.generalHeight * (notEmptyTxtCount + 9) + "px";
      this.reRenderThongTinChuyenTienUI();
    }
    if (this.f77bTextBoxs.length > 0) {
      this.f77bTextBoxs.forEach((key, index) => {
        key.text = f77B[index];
        key.isVisible = !$isNullOrEmpty(key.text);
      });
      let notEmptyTxtCountF77B = 0;
      for (var i = this.f77bTextBoxs.length - 1; i >= 1; i--) {
        if (!$isNullOrEmpty(this.f77bTextBoxs[i].text)) notEmptyTxtCountF77B++;
      }
      this.tableThongTinNganHangThuHuongLeft[16].height =
        this.generalHeight * (notEmptyTxtCountF77B + 1) + "px";
      this.tableThongTinNganHangThuHuongLeft[17].height =
        this.generalHeight * (notEmptyTxtCountF77B + 1) + "px";
      this.flxThongTinNganHangThuHuong.height = $addUnit(
        this.flxThongTinNganHangThuHuong.height,
        this.generalHeight * notEmptyTxtCountF77B + "px"
      );
      this.reRenderThongTinChuyenTienUI();
    }
    this.form.tbSenderToReceiverInfor.isVisible = true;
    this.form.tbRegulatoryReporting.isVisible = true;
    this.form.lbKetQuaKiemTra.selectedKey = resultCheck || "";
    this.form.lbKiemTraPCRT.selectedKey = pcrtBranch || "";
    this.form.txtSwiftMT103SentTo.text = swiftMt103 || "";
    this.form.txtPhanHoiCuaDVKD.text = feedbackDvkd;
    this.form.txtPhanHoiCuaTTTTQT.text = feedbackTtTtqt;
  },
  createUI() {
    this.createUIDetailTab();
    this.createUIDocumentsTab();
    this.createUIFundTransferTab();
  },
  createUIDetailTab() {
    const self = this;
    //Thông tin chung
    const flxContainer = this.view.TabPanel.flxContainer;
    flxContainer.removeAll();
    this.createGeneralInformation(flxContainer, this.detailUI);
    const flxCustomInformationContainer = $createFlexContainer(flxContainer, {
      height: this.generalHeight * 17 + "px",
      top: this.generalHeight * 2 + "px"
    });
    const flxCustomInformation = $createFlexContainer(
      flxCustomInformationContainer,
      {
        width: "50%",
        left: "0"
      }
    );
    //Cột trái
    this.detailUI.txtMaKhachHang = $createLabel();
    this.detailUI.txtQuanHeNhanThan = $createLabel();
    this.detailUI.txtSoDienThoai = $createLabel();
    this.detailUI.txtEmail = $createLabel();
    this.detailUI.lbPhanLoaiKhachHang = $createListBox(
      Object.values(CUSTOMER_TYPES),
      Object.keys(CUSTOMER_TYPES),
      {
        skin: "skinListBoxContentTable",
        width: "100%",
        height: "100%"
      }
    );
    this.detailUI.txtQuanHeNhanThan = $createLabel();
    this.detailUI.txtMucDichChuyenTien = $createLabel();
    this.detailUI.txtMoHinhThanhToan = $createLabel();
    this.detailUI.txtTenKhachHang2 = $createLabel();
    this.detailUI.txtDiaChi2 = $createLabel();
    this.detailUI.txtCaiDatTuDongChuyenTien = $createLabel()
    this.detailUI.txtSoTienToiDaKHDongYChiTra = $createLabel()
    this.detailUI.txtMaUuDai = $createLabel()

    const contentForflxCustomInformation = [
      [
        $createLabel("Mã khách hàng (CIF)", { skin: "titleInforKey" }),
        this.detailUI.txtMaKhachHang
      ],
      [
        $createLabel("Tên khách hàng", { skin: "titleInforKey" }),
        this.detailUI.txtTenKhachHang2
      ],
      [
        $createLabel("Địa chỉ", { skin: "titleInforKey" }),
        this.detailUI.txtDiaChi2
      ],
      [
        $createLabel("Số điện thoại", { skin: "titleInforKey" }),
        this.detailUI.txtSoDienThoai
      ],
      [
        $createLabel("Email", { skin: "titleInforKey" }),
        this.detailUI.txtEmail
      ],
      [
        $createLabel("Phân loại khách hàng", { skin: "titleInforKey" }),
        this.detailUI.lbPhanLoaiKhachHang
      ],
      [
        $createLabel("Quan hệ nhân thân", { skin: "titleInforKey" }),
        this.detailUI.txtQuanHeNhanThan
      ],
      [
        $createLabel("Mục đích chuyển tiền", { skin: "titleInforKey" }),
        this.detailUI.txtMucDichChuyenTien
      ],
      [
        $createLabel("Mô hình thanh toán", { skin: "titleInforKey" }),
        this.detailUI.txtMoHinhThanhToan
      ],
      [
        $createLabel("Cài đặt tự động chuyển tiền", { skin: "titleInforKey" }),
        this.detailUI.txtCaiDatTuDongChuyenTien
      ],
      [
        $createLabel("Số tiền tối đa KH đồng ý chi trả", { skin: "titleInforKey" }),
        this.detailUI.txtSoTienToiDaKHDongYChiTra
      ],
      [
        $createLabel("Mã ưu đãi", { skin: "titleInforKey" }),
        this.detailUI.txtMaUuDai
      ],
    ];
    $createTable(
      flxCustomInformation,
      contentForflxCustomInformation,
      {
        oddColumnSkin: "rowTitleLeft",
        evenColumnSkin: "rowTitleRight",
        rowHeight: this.generalHeight + "px"
      }
    );
    //Cột phải
    const flxTransactionInfor = $createFlexContainer(
      flxCustomInformationContainer,
      {
        width: "50%",
        left: "50%",
        top: "0"
      }
    );
    const labelForLoaiTienTe = $createLabel("Loại tiền chuyển", {
      skin: "titleInforKey"
    });
    this.detailUI.txtLoaiTienGiaoDich = $createLabel();
    this.detailUI.txtSoTienGiaoDich = $createLabel();
    this.detailUI.txtSoTienGiaoDichThucTe = $createLabel();
    this.detailUI.txtNgayXacNhanGiaoDich = $createLabel();
    this.detailUI.txtNgayThucHienGiaoDich = $createLabel();
    this.detailUI.txtPhiTrongNuoc = $createLabel();
    this.detailUI.txtPhiNuocNgoai = $createLabel();
    this.detailUI.txtTaiKhoanChuyen = $createLabel();
    this.detailUI.txtTiGiaNgoaiTe = $createLabel();
    this.detailUI.txtTiGiaUSDNiemYet = $createLabel();
    this.detailUI.txtTiGiaApDung = $createLabel();
    this.detailUI.txtSoTienQuyDoi = $createLabel();
    this.detailUI.txtBenChiuPhi = $createLabel();
    this.detailUI.txtTaiKhoanChiuPhi = $createLabel();
    this.detailUI.txtDienPhi = $createLabel();
    this.detailUI.txtTongPhi = $createLabel();
    const contentForflxTransactionInfor = [
      [
        $createLabel("Ngày thực hiện giao dịch", { skin: "titleInforKey" }),
        this.detailUI.txtNgayThucHienGiaoDich
      ],
      [labelForLoaiTienTe, this.detailUI.txtLoaiTienGiaoDich],
      [
        $createLabel("Số tiền trong hồ sơ đăng kí", { skin: "titleInforKey" }),
        this.detailUI.txtSoTienGiaoDich
      ],
      [
        $createLabel("Số tiền giao dịch thực tế", { skin: "titleInforKey" }),
        this.detailUI.txtSoTienGiaoDichThucTe
      ],
      [
        $createLabel("Tài khoản nguồn", { skin: "titleInforKey" }),
        this.detailUI.txtTaiKhoanChuyen
      ],
      [
        $createLabel("Tỉ giá niêm yết", { skin: "titleInforKey" }),
        this.detailUI.txtTiGiaNgoaiTe
      ],
      [
        $createLabel("Tỉ giá USD niêm yết", { skin: "titleInforKey" }),
        this.detailUI.txtTiGiaUSDNiemYet
      ],
      [
        $createLabel("Tỉ giá áp dụng", { skin: "titleInforKey" }),
        this.detailUI.txtTiGiaApDung
      ],
      [
        $createLabel("Số tiền quy đổi VNĐ", { skin: "titleInforKey" }),
        this.detailUI.txtSoTienQuyDoi
      ],
      [
        $createLabel("Loại phí", { skin: "titleInforKey" }),
        this.detailUI.txtBenChiuPhi
      ],
      [
        $createLabel("Tài khoản thu phí", { skin: "titleInforKey" }),
        this.detailUI.txtTaiKhoanChiuPhi
      ],
      [
        $createLabel("Phí chuyển tiền - Pvcombank", { skin: "titleInforKey" }),
        this.detailUI.txtPhiTrongNuoc
      ],
      [
        $createLabel("Điện phí", { skin: "titleInforKey" }),
        this.detailUI.txtDienPhi
      ],
      [
        $createLabel("Phí ngân hàng nước ngoài/Đối tác", { skin: "titleInforKey" }),
        this.detailUI.txtPhiNuocNgoai
      ],
      [
        $createLabel("Tổng phí (bao gồm VAT)", { skin: "titleInforKey" }),
        this.detailUI.txtTongPhi
      ]
    ];
    $createTable(
      flxTransactionInfor,
      contentForflxTransactionInfor,
      {
        oddColumnSkin: "rowTitleLeft",
        evenColumnSkin: "rowTitleRight",
        rowHeight: this.generalHeight + "px"
      }
    );
  },
  createUIDocumentsTab() {
    var self = this;
    const flxContainer = this.view.TabPanel.flxContainerDocuments;
    flxContainer.removeAll();
    //Thông tin chung
    this.createGeneralInformation(flxContainer, this.detailUIDocuments);
    //Label thông tin hồ sơ
    const flxLabelThongTinHoSo = $createFlexContainer(flxContainer, {
      height: this.generalHeight + "px",
      top: this.generalHeight * 2 + "px",
      skin: "rowTitleLeft",
    });
    const contentFlxLabelThongTinHoSo = [
      [
        $createLabel("Thông tin hồ sơ", {
          skin: "titleInforKey"
        })
      ]
    ];
    $createTable(flxLabelThongTinHoSo, contentFlxLabelThongTinHoSo);
    //Thông tin hồ sơ
    this.form.cbHoSo = $createRadioGroup(
      ["Ngoại lệ", "Không ngoại lệ"],
      ["NgoaiLe", "KhongNgoaiLe"],
    );
    this.form.cbNoChungTu = $createRadioGroup(["Nợ", "Không"], ["No", "Khong"]);
    const content = [
      [$createLabel("Hồ sơ:", { right: "5px" }), this.form.cbHoSo],
      [$createLabel("Nợ chứng từ:", { right: "5px" }), this.form.cbNoChungTu]
    ];
    const flxHoSoChungTu = $createFlexContainer(flxContainer, {
      width: "100%",
      height: this.generalHeight * 2 + "px",
      top: $getElementTop(flxLabelThongTinHoSo),
      skin: "rowTitleRight",
    });
    $createTable(flxHoSoChungTu, content, {
      oddColumnWidth: "10%",
      evenColumnWidth: "90%",
      rowHeight: this.generalHeight + "px",
    });
    //Label danh mục hồ sơ
    const flxLabelDanhMucHoSo = $createFlexContainer(flxContainer, {
      height: this.generalHeight + "px",
      top: $addUnit($getElementTop(flxHoSoChungTu), this.generalHeight + "px"),
    });
    const contentFlxLabelDanhMucHoSo = [
      [
        $createLabel("Danh mục hồ sơ", {
          skin: "titleInfor"
        })
      ]
    ];
    $createTable(flxLabelDanhMucHoSo, contentFlxLabelDanhMucHoSo);
    //Tiêu đề cột
    const flxLabelTieuDeCot = $createFlexContainer(flxContainer, {
      height: this.generalHeight + "px",
      top: $getElementTop(flxLabelDanhMucHoSo),
      skin: "rowTitleLeft",
    });
    const contentFlxLabelTieuDeCot = [
      [
        $createLabel("Loại hồ sơ", {
          skin: "titleInforKey"
        }),
        $createLabel("Tên hồ sơ", {
          skin: "titleInforKey"
        }),
        $createLabel("UserUpload", {
          skin: "titleInforKey"
        }),
        $createLabel("Ngày giờ upload", {
          skin: "titleInforKey"
        })
      ],
    ];
    $createTable(flxLabelTieuDeCot, contentFlxLabelTieuDeCot, { customColumnsWidth: ["30%", "45.5%", "10.5%", "14%"] });
    //thông tin hồ sơ khách hàng
    this.flxCustomDocumentInformation = $createFlexContainer(flxContainer, {
      top: $getElementTop(flxLabelTieuDeCot),
      height: this.generalHeight + "px",
    });
    this.form.attachButton = $createButton(
      "Attach file",
      () => {
        var input = document.createElement("input");
        input.type = "file";
        input.multiple = true; // Thêm thuộc tính multiple vào đây
        input.addEventListener("change", function (event) {
          const newFiles = event.target.files;
          const duplicateFiles = self.checkDuplicateFiles(newFiles);
          if ([...duplicateFiles].length > 0) {
            self.showErrorMessage(
              "Các file sau đã tồn tại và sẽ không được tải lên: " +
              duplicateFiles.join(", ")
            );
          }
          const fileValid = [...newFiles].filter(
            (file) => !duplicateFiles.includes(file.name)
          );
          self.attachFiles = [...self.attachFiles, ...fileValid];
          if ([...self.attachFiles].length > 0) {
            self.createCustomerDocuments(self.flxCustomDocumentInformation);
          }
          self.view.forceLayout();
        });
        input.click();
      },
    );
    const contentForFlxAttachButton = [
      [
        this.form.attachButton
      ]
    ];
    this.flxAttachButton = $createFlexContainer(flxContainer, {
      top: $getElementTop(this.flxCustomDocumentInformation),
      height: this.generalHeight + "px"
    });
    $createTable(this.flxAttachButton, contentForFlxAttachButton, {
      rowHeight: this.generalHeight + "px"
    });
  },
  createUIFundTransferTab() {
    const flxContainer = this.view.TabPanel.flxContainerFundTransfer;
    flxContainer.removeAll();
    this.createGeneralInformation(flxContainer, this.detailUIFundTransfer);
    //Kênh giao dịch
    this.flxKenhGiaoDich = $createFlexContainer(flxContainer, {
      height: this.generalHeight + "px",
      top: this.generalHeight * 2 + "px",
      width: "50%"
    });
    //Label Thông tin giao dịch
    const flxLabelThongTinGiaoDich = $createFlexContainer(flxContainer, {
      height: this.generalHeight + "px",
      top: $getElementTop(this.flxKenhGiaoDich)
    });
    const contentFlxLabelThongTinGiaoDich = [
      [
        $createLabel("Thông tin giao dịch", {
          skin: "titleInfor"
        })
      ]
    ];
    $createTable(flxLabelThongTinGiaoDich, contentFlxLabelThongTinGiaoDich);
    //Thông tin giao dịch cột trái
    this.flxThongTinGiaoDich = $createFlexContainer(flxContainer, {
      height: this.generalHeight * 3 + "px",
      top: $getElementTop(flxLabelThongTinGiaoDich)
    });
    this.detailUI.txtLoaiTienGiaoDich2 = $createLabel();
    this.detailUI.txtSoTienGiaoDichThucTe2 = $createLabel();
    //Nội dung chuyển tiền
    const flxNoiDungChuyenTien = $createFlexContainer();
    flxNoiDungChuyenTien.height = this.generalHeight * 8 + "px";
    const flxNoiDungChuyenTienFirst = $createFlexContainer(flxNoiDungChuyenTien, {
      height: this.generalHeight + "px"
    });
    this.detailUI.txtNoiDungChuyenTien = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      skin: "skinSenderF72",
      height: "100%"
    });
    this.noiDungChuyenTienTextBoxs.push(this.detailUI.txtNoiDungChuyenTien);
    this.form.btnAddNoiDungChuyenTien = $createFlexContainer();
    this.form.btnDeleteNoiDungChuyenTien = $createFlexContainer();
    this.form.btnAddNoiDungChuyenTien.width = "10%";
    this.form.btnAddNoiDungChuyenTien.left = "80%";
    this.form.btnDeleteNoiDungChuyenTien.width = "10%";
    this.form.btnDeleteNoiDungChuyenTien.left = "90%";
    const btnAddNoiDungChuyenTien = $createLabel("", {
      skin: "addIconSkin"
    });
    const btnDeleteNoiDungChuyenTien = $createLabel("", {
      skin: "deleteIconSkin"
    });
    this.form.btnAddNoiDungChuyenTien.add(btnAddNoiDungChuyenTien);
    this.form.btnDeleteNoiDungChuyenTien.add(btnDeleteNoiDungChuyenTien);
    this.form.btnAddNoiDungChuyenTien.onClick = () => { this.onClickBtnAddNoiDungChuyenTien(); }
    this.form.btnDeleteNoiDungChuyenTien.onClick = () => {
      for (var i = this.amountOfLineNoiDungChuyenTien - 1; i >= 1; i--) {
        if (this.noiDungChuyenTienTextBoxs[i].isVisible) {
          this.noiDungChuyenTienTextBoxs[i].isVisible = false;
          this.noiDungChuyenTienTextBoxs[i].text = "";
          break;
        }
      }
      if ($isGreaterThanOrEqual(this.tableThongTinGiaoDichLeft[5].height, this.generalHeight * 2 + "px")) {
        this.tableThongTinGiaoDichLeft[4].height = $subtractUnit(
          this.tableThongTinGiaoDichLeft[4].height,
          this.generalHeight + "px"
        );
        this.tableThongTinGiaoDichLeft[5].height = $subtractUnit(
          this.tableThongTinGiaoDichLeft[5].height,
          this.generalHeight + "px"
        );
        if ($isGreaterThan(this.flxThongTinGiaoDich.height, this.generalHeight * 3 + "px")) {
          this.flxThongTinGiaoDich.height = $subtractUnit(
            this.flxThongTinGiaoDich.height,
            this.generalHeight + "px"
          );
          this.reRenderUIThongTinGiaoDich();
        }
      }
    };
    flxNoiDungChuyenTienFirst.add(this.detailUI.txtNoiDungChuyenTien);
    flxNoiDungChuyenTienFirst.add(this.form.btnAddNoiDungChuyenTien);
    flxNoiDungChuyenTienFirst.add(this.form.btnDeleteNoiDungChuyenTien);
    //dòng2
    const flxNoiDungChuyenTienSecond = $createFlexContainer(flxNoiDungChuyenTien, {
      top: this.generalHeight + "px",
      height: this.generalHeight + "px"
    });
    this.noiDungChuyenTien2 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxNoiDungChuyenTienSecond.add(this.noiDungChuyenTien2);
    //dòng 3
    const flxNoiDungChuyenTienThird = $createFlexContainer(flxNoiDungChuyenTien, {
      top: this.generalHeight * 2 + "px",
      height: this.generalHeight + "px"
    });
    this.noiDungChuyenTien3 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxNoiDungChuyenTienThird.add(this.noiDungChuyenTien3);
    //dòng 4
    const flxNoiDungChuyenTienFourth = $createFlexContainer(flxNoiDungChuyenTien, {
      top: this.generalHeight * 3 + "px",
      height: this.generalHeight + "px"
    });
    this.noiDungChuyenTien4 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxNoiDungChuyenTienFourth.add(this.noiDungChuyenTien4);
    //dòng 5
    const flxNoiDungChuyenTien5 = $createFlexContainer(flxNoiDungChuyenTien, {
      top: this.generalHeight * 4 + "px",
      height: this.generalHeight + "px"
    });
    this.noiDungChuyenTien5 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxNoiDungChuyenTien5.add(this.noiDungChuyenTien5);
    //dòng 6
    const flxNoiDungChuyenTien6 = $createFlexContainer(flxNoiDungChuyenTien, {
      top: this.generalHeight * 5 + "px",
      height: this.generalHeight + "px"
    });
    this.noiDungChuyenTien6 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxNoiDungChuyenTien6.add(this.noiDungChuyenTien6);
    //dòng 7
    const flxNoiDungChuyenTien7 = $createFlexContainer(flxNoiDungChuyenTien, {
      top: this.generalHeight * 6 + "px",
      height: this.generalHeight + "px"
    });
    this.noiDungChuyenTien7 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxNoiDungChuyenTien7.add(this.noiDungChuyenTien7);
    //dòng 8
    const flxNoiDungChuyenTien8 = $createFlexContainer(flxNoiDungChuyenTien, {
      top: this.generalHeight * 7 + "px",
      height: this.generalHeight + "px"
    });
    this.noiDungChuyenTien8 = $createTextBox({
      maxLength: 10,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxNoiDungChuyenTien8.add(this.noiDungChuyenTien8);

    this.noiDungChuyenTienTextBoxs.push(this.noiDungChuyenTien2);
    this.noiDungChuyenTienTextBoxs.push(this.noiDungChuyenTien3);
    this.noiDungChuyenTienTextBoxs.push(this.noiDungChuyenTien4);
    this.noiDungChuyenTienTextBoxs.push(this.noiDungChuyenTien5);
    this.noiDungChuyenTienTextBoxs.push(this.noiDungChuyenTien6);
    this.noiDungChuyenTienTextBoxs.push(this.noiDungChuyenTien7);
    this.noiDungChuyenTienTextBoxs.push(this.noiDungChuyenTien8);
    flxNoiDungChuyenTien.add(flxNoiDungChuyenTienFirst);
    flxNoiDungChuyenTien.add(flxNoiDungChuyenTienSecond);
    flxNoiDungChuyenTien.add(flxNoiDungChuyenTienThird);
    flxNoiDungChuyenTien.add(flxNoiDungChuyenTienFourth);
    flxNoiDungChuyenTien.add(flxNoiDungChuyenTien5);
    flxNoiDungChuyenTien.add(flxNoiDungChuyenTien6);
    flxNoiDungChuyenTien.add(flxNoiDungChuyenTien7);
    flxNoiDungChuyenTien.add(flxNoiDungChuyenTien8);
    //Nội dung bảng
    const flxThongTinGiaoDichLeftColumn = $createFlexContainer(
      this.flxThongTinGiaoDich,
      {
        width: "50%",
        left: "0"
      }
    );
    const contentFlxThongTinGiaoDichLeftColumn = [
      [
        $createLabel("Loại ngoại tệ", { skin: "titleInforKey" }),
        this.detailUI.txtLoaiTienGiaoDich2,
      ],
      [
        $createLabel("Số tiền chuyển", { skin: "titleInforKey" }),
        this.detailUI.txtSoTienGiaoDichThucTe2,
      ],
      [
        $createLabel("Nội dung chuyển tiền", { skin: "titleInforKey" }),
        flxNoiDungChuyenTien,
      ]
    ];
    this.tableThongTinGiaoDichLeft = $createTable(
      flxThongTinGiaoDichLeftColumn,
      contentFlxThongTinGiaoDichLeftColumn,
      {
        oddColumnSkin: "rowTitleLeft",
        evenColumnSkin: "rowTitleRight",
        rowHeight: this.generalHeight + "px"
      }
    );
    //Thông tin giao dịch cột phải
    const flxThongTinGiaoDichRightColumn = $createFlexContainer(
      this.flxThongTinGiaoDich,
      {
        width: "50%",
        left: "50%"
      }
    );
    this.detailUI.txtNgoaiTeChuyenDoi = $createLabel();
    this.detailUI.txtMucDichChuyenTien2 = $createLabel();
    this.form.txtTaiKhoanNostro = $createTextBox({
      skin: "skinTextBoxNoBorderGray",
      width: "90%",
      height: "100%"
    });
    this.form.txtTaiKhoanNostro.onTextChange = (txt) => {
      const text = $trim(txt.text);
      this.form.txtTaiKhoanNostro.text = text;
      const nostroValidate = this.listNostro.filter(
        (nostro) => nostro.accountNumber === text
      );
      if (this.detailUI.lbKenhGiaoDich.selectedKey === CHANNEL.Nostro && nostroValidate.length === 0) {
        this.showErrorMessage("Tài khoản Nostro/Đối tác không tồn tại");
        this.form.lblTenNostro.toolTip = "";
        return;
      }
    };
    this.form.lblTenNostro = $createLabel("👁", {
      width: "10%",
      height: "100%",
      left: "92%"
    });
    const flxTaiKhoanNostro = $createFlexContainer();
    flxTaiKhoanNostro.add(this.form.txtTaiKhoanNostro);
    flxTaiKhoanNostro.add(this.form.lblTenNostro);
    const contentFlxThongTinGiaoDichRightColumn = [
      [
        $createLabel("Ngoại tệ chuyển đổi", { skin: "titleInforKey" }),
        this.detailUI.txtNgoaiTeChuyenDoi
      ],
      [
        $createLabel("Tài Khoản Nostro/Đối tác", { skin: "titleInforKey" }),
        flxTaiKhoanNostro
      ],
      [
        $createLabel("Mục đích chuyển tiền", { skin: "titleInforKey" }),
        this.detailUI.txtMucDichChuyenTien2
      ]
    ];
    $createTable(
      flxThongTinGiaoDichRightColumn,
      contentFlxThongTinGiaoDichRightColumn,
      {
        oddColumnSkin: "rowTitleLeft",
        evenColumnSkin: "rowTitleRight",
        rowHeight: this.generalHeight + "px"
      }
    );
    //Label Thông tin người chuyển tiền
    this.flxLabelThongTinNguoiChuyenTien = $createFlexContainer(flxContainer, {
      height: this.generalHeight + "px",
      top: $getElementTop(this.flxThongTinGiaoDich)
    });
    const contentFlxLabelThongTinNguoiChuyenTien = [
      [
        $createLabel("Thông tin người chuyển tiền", {
          skin: "titleInfor"
        })
      ]
    ];
    $createTable(
      this.flxLabelThongTinNguoiChuyenTien,
      contentFlxLabelThongTinNguoiChuyenTien
    );
    //thông tin người chuyển tiền cột trái
    this.flxThongTinNguoiChuyen = $createFlexContainer(flxContainer, {
      top: $getElementTop(this.flxLabelThongTinNguoiChuyenTien),
      height: this.generalHeight * 7 + "px"
    });
    const flxThongTinNguoiChuyenLeft = $createFlexContainer(
      this.flxThongTinNguoiChuyen,
      {
        width: "50%",
        left: "0"
      }
    );
    this.detailUI.txtMaQuocGiaNguoiChuyen = $createLabel();
    this.detailUI.txtMaKhachHang2 = $createLabel();
    //Tên khách hàng
    const flxTenKhachHangContainer = $createFlexContainer();
    flxTenKhachHangContainer.height = this.generalHeight * 2 + "px";
    //---Tạo dòng đầu gồm txt và 2 buttons
    const flxTenKhachHangFirst = $createFlexContainer(flxTenKhachHangContainer, {
      height: this.generalHeight + "px"
    });
    this.detailUI.txtTenKhachHang = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      skin: "skinSenderF72",
      height: "100%"
    });
    this.detailUI.txtTenKhachHang.isFirst = true;
    this.tenKhachHangTextBoxs.push(this.detailUI.txtTenKhachHang);
    this.form.btnAddTenKhachHang = $createFlexContainer();
    this.form.btnDeleteTenKhachHang = $createFlexContainer();
    this.form.btnAddTenKhachHang.width = "10%";
    this.form.btnAddTenKhachHang.left = "80%";
    this.form.btnDeleteTenKhachHang.width = "10%";
    this.form.btnDeleteTenKhachHang.left = "90%";
    const btnAddTenKhachHang = $createLabel("", {
      skin: "addIconSkin"
    });
    const btnDeleteTenKhachHang = $createLabel("", {
      skin: "deleteIconSkin"
    });
    this.form.btnAddTenKhachHang.add(btnAddTenKhachHang);
    this.form.btnDeleteTenKhachHang.add(btnDeleteTenKhachHang);
    this.form.btnAddTenKhachHang.onClick = () => {
      for (var i = 0; i < this.tenKhachHangTextBoxs.length; i++) {
        if (!this.tenKhachHangTextBoxs[i].isVisible) {
          this.tenKhachHangTextBoxs[i].isVisible = true;
          break;
        }
      }
      const height = this.tableThongTinNguoiChuyenTienLeft[2].height;
      if ($isLessThan(height, this.generalHeight * 2 + "px")) {
        this.tableThongTinNguoiChuyenTienLeft[2].height = $addUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[3].height = $addUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[4].top = $addUnit(
          this.tableThongTinNguoiChuyenTienLeft[4].top,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[5].top = $addUnit(
          this.tableThongTinNguoiChuyenTienLeft[5].top,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[6].top = $addUnit(
          this.tableThongTinNguoiChuyenTienLeft[6].top,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[7].top = $addUnit(
          this.tableThongTinNguoiChuyenTienLeft[7].top,
          this.generalHeight + "px"
        );
        if ($isGreaterThan($getElementTop(this.tableThongTinNguoiChuyenTienLeft[7]), this.generalHeight * 7 + "px")) {
          this.flxThongTinNguoiChuyen.height = $addUnit(
            this.flxThongTinNguoiChuyen.height,
            this.generalHeight + "px"
          );
          this.reRenderUIThongTinNguoiChuyenTien();
        }
      }
    };
    this.form.btnDeleteTenKhachHang.onClick = () => {
      for (var i = this.tenKhachHangTextBoxs.length - 1; i >= 1; i--) {
        if (this.tenKhachHangTextBoxs[i].isVisible) {
          this.tenKhachHangTextBoxs[i].isVisible = false;
          this.tenKhachHangTextBoxs[i].text = "";
          break;
        }
      }
      const height = this.tableThongTinNguoiChuyenTienLeft[2].height;
      if ($isGreaterThanOrEqual(height, this.generalHeight * 2 + "px")) {
        this.tableThongTinNguoiChuyenTienLeft[2].height = $subtractUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[3].height = $subtractUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[4].top = $subtractUnit(
          this.tableThongTinNguoiChuyenTienLeft[4].top,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[5].top = $subtractUnit(
          this.tableThongTinNguoiChuyenTienLeft[5].top,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[6].top = $subtractUnit(
          this.tableThongTinNguoiChuyenTienLeft[6].top,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[7].top = $subtractUnit(
          this.tableThongTinNguoiChuyenTienLeft[7].top,
          this.generalHeight + "px"
        );
        if ($isGreaterThan($getElementTop(this.tableThongTinNguoiChuyenTienLeft[7]), this.generalHeight * 7 + "px"))
          this.flxThongTinNguoiChuyen.height = $subtractUnit(
            this.flxThongTinNguoiChuyen.height,
            this.generalHeight + "px"
          );
        this.reRenderUIThongTinNguoiChuyenTien();
      }
    };
    flxTenKhachHangFirst.add(this.detailUI.txtTenKhachHang);
    flxTenKhachHangFirst.add(this.form.btnAddTenKhachHang);
    flxTenKhachHangFirst.add(this.form.btnDeleteTenKhachHang);
    //dòng2
    const flxTenKhachHangSecond = $createFlexContainer(flxTenKhachHangContainer, {
      top: this.generalHeight + "px",
      height: this.generalHeight + "px"
    });
    const txtTenKhachHangg2 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxTenKhachHangSecond.add(txtTenKhachHangg2);
    this.tenKhachHangTextBoxs.push(txtTenKhachHangg2);
    this.tenKhachHangTextBoxs.forEach((textBox, index) => {
      textBox.onTextChange = (textBox) => {
        const text = $trim(textBox.text);
        if (text.length > 0 && text[0] === "-") {
          this.showErrorMessage("Vui lòng không nhập - ở đầu dòng.");
          return;
        }
        if (text && $isContainsVietnamese(text)) {
          this.showErrorMessage("Vui lòng không nhập tiếng Anh.");
          return;
        }
      };
      if (index === 0) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (txtTenKhachHangg2.isVisible === false) {
            txtTenKhachHangg2.isVisible = true;
            this.tableThongTinNguoiChuyenTienLeft[2].height = $addUnit(
              this.tableThongTinNguoiChuyenTienLeft[2].height,
              this.generalHeight + "px"
            );
            this.tableThongTinNguoiChuyenTienLeft[3].height = $addUnit(
              this.tableThongTinNguoiChuyenTienLeft[3].height,
              this.generalHeight + "px"
            );
            this.tableThongTinNguoiChuyenTienLeft[4].top = $addUnit(
              this.tableThongTinNguoiChuyenTienLeft[4].top,
              this.generalHeight + "px"
            );
            this.tableThongTinNguoiChuyenTienLeft[5].top = $addUnit(
              this.tableThongTinNguoiChuyenTienLeft[5].top,
              this.generalHeight + "px"
            );
            this.tableThongTinNguoiChuyenTienLeft[6].top = $addUnit(
              this.tableThongTinNguoiChuyenTienLeft[6].top,
              this.generalHeight + "px"
            );
            this.tableThongTinNguoiChuyenTienLeft[7].top = $addUnit(
              this.tableThongTinNguoiChuyenTienLeft[7].top,
              this.generalHeight + "px"
            );
            if ($isGreaterThan($getElementTop(this.tableThongTinNguoiChuyenTienLeft[7]), this.generalHeight * 7 + "px")) {
              this.flxThongTinNguoiChuyen.height = $addUnit(
                this.flxThongTinNguoiChuyen.height,
                this.generalHeight + "px"
              );
              this.reRenderUIThongTinNguoiChuyenTien();
            }
            this.view.forceLayout();
          }
          txtTenKhachHangg2.setFocus(true);
        }
      }
    });
    flxTenKhachHangContainer.add(flxTenKhachHangFirst);
    flxTenKhachHangContainer.add(flxTenKhachHangSecond);
    //Địa chỉ người chuyển
    const flxDiaChi = $createFlexContainer();
    flxDiaChi.height = this.generalHeight * 8 + "px";
    const flxDiaChiFirst = $createFlexContainer(flxDiaChi, {
      height: this.generalHeight + "px"
    });
    this.detailUI.txtDiaChi = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      skin: "skinSenderF72",
      height: "100%"
    });
    this.diaChiNguoiChuyenTextBoxs.push(this.detailUI.txtDiaChi);
    this.form.btnAddDiaChiNguoiChuyen = $createFlexContainer();
    this.form.btnDeleteDiaChiNguoiChuyen = $createFlexContainer();
    this.form.btnAddDiaChiNguoiChuyen.width = "10%";
    this.form.btnAddDiaChiNguoiChuyen.left = "80%";
    this.form.btnDeleteDiaChiNguoiChuyen.width = "10%";
    this.form.btnDeleteDiaChiNguoiChuyen.left = "90%";
    const btnAddDiaChiNguoiChuyen = $createLabel("", {
      skin: "addIconSkin"
    });
    const btnDeleteDiaChiNguoiChuyen = $createLabel("", {
      skin: "deleteIconSkin"
    });
    this.form.btnAddDiaChiNguoiChuyen.add(btnAddDiaChiNguoiChuyen);
    this.form.btnDeleteDiaChiNguoiChuyen.add(btnDeleteDiaChiNguoiChuyen);
    this.form.btnAddDiaChiNguoiChuyen.onClick = () => { this.onClickBtnAddDiaChiNguoiChuyen(); }
    this.form.btnDeleteDiaChiNguoiChuyen.onClick = () => {
      for (var i = this.amountOfAddressLine - 1; i >= 1; i--) {
        if (this.diaChiNguoiChuyenTextBoxs[i].isVisible) {
          this.diaChiNguoiChuyenTextBoxs[i].isVisible = false;
          this.diaChiNguoiChuyenTextBoxs[i].text = "";
          break;
        }
      }
      if ($isGreaterThanOrEqual(this.tableThongTinNguoiChuyenTienLeft[5].height, this.generalHeight * 2 + "px")) {
        this.tableThongTinNguoiChuyenTienLeft[4].height = $subtractUnit(
          this.tableThongTinNguoiChuyenTienLeft[4].height,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[5].height = $subtractUnit(
          this.tableThongTinNguoiChuyenTienLeft[5].height,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[6].top = $subtractUnit(
          this.tableThongTinNguoiChuyenTienLeft[6].top,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiChuyenTienLeft[7].top = $subtractUnit(
          this.tableThongTinNguoiChuyenTienLeft[7].top,
          this.generalHeight + "px"
        );
        if ($isGreaterThan(this.flxThongTinNguoiChuyen.height, this.generalHeight * 7 + "px")) {
          this.flxThongTinNguoiChuyen.height = $subtractUnit(
            this.flxThongTinNguoiChuyen.height,
            this.generalHeight + "px"
          );
          this.reRenderUIThongTinNguoiChuyenTien();
        }
      }
    };
    flxDiaChiFirst.add(this.detailUI.txtDiaChi);
    flxDiaChiFirst.add(this.form.btnAddDiaChiNguoiChuyen);
    flxDiaChiFirst.add(this.form.btnDeleteDiaChiNguoiChuyen);
    //dòng2
    const flxDiaChiSecond = $createFlexContainer(flxDiaChi, {
      top: this.generalHeight + "px",
      height: this.generalHeight + "px"
    });
    this.diaChi2 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChiSecond.add(this.diaChi2);
    //dòng 3
    const flxDiaChiThird = $createFlexContainer(flxDiaChi, {
      top: this.generalHeight * 2 + "px",
      height: this.generalHeight + "px"
    });
    this.diaChi3 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChiThird.add(this.diaChi3);
    //dòng 4
    const flxDiaChiFourth = $createFlexContainer(flxDiaChi, {
      top: this.generalHeight * 3 + "px",
      height: this.generalHeight + "px"
    });
    this.diaChi4 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChiFourth.add(this.diaChi4);
    //dòng 5
    const flxDiaChi5 = $createFlexContainer(flxDiaChi, {
      top: this.generalHeight * 4 + "px",
      height: this.generalHeight + "px"
    });
    this.diaChi5 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChi5.add(this.diaChi5);
    //dòng 6
    const flxDiaChi6 = $createFlexContainer(flxDiaChi, {
      top: this.generalHeight * 5 + "px",
      height: this.generalHeight + "px"
    });
    this.diaChi6 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChi6.add(this.diaChi6);
    //dòng 7
    const flxDiaChi7 = $createFlexContainer(flxDiaChi, {
      top: this.generalHeight * 6 + "px",
      height: this.generalHeight + "px"
    });
    this.diaChi7 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChi7.add(this.diaChi7);
    //dòng 8
    const flxDiaChi8 = $createFlexContainer(flxDiaChi, {
      top: this.generalHeight * 7 + "px",
      height: this.generalHeight + "px"
    });
    this.diaChi8 = $createTextBox({
      maxLength: 10,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChi8.add(this.diaChi8);

    this.diaChiNguoiChuyenTextBoxs.push(this.diaChi2);
    this.diaChiNguoiChuyenTextBoxs.push(this.diaChi3);
    this.diaChiNguoiChuyenTextBoxs.push(this.diaChi4);
    this.diaChiNguoiChuyenTextBoxs.push(this.diaChi5);
    this.diaChiNguoiChuyenTextBoxs.push(this.diaChi6);
    this.diaChiNguoiChuyenTextBoxs.push(this.diaChi7);
    this.diaChiNguoiChuyenTextBoxs.push(this.diaChi8);
    flxDiaChi.add(flxDiaChiFirst);
    flxDiaChi.add(flxDiaChiSecond);
    flxDiaChi.add(flxDiaChiThird);
    flxDiaChi.add(flxDiaChiFourth);
    flxDiaChi.add(flxDiaChi5);
    flxDiaChi.add(flxDiaChi6);
    flxDiaChi.add(flxDiaChi7);
    flxDiaChi.add(flxDiaChi8);
    //
    const contentFlxThongTinNguoiChuyenLeft = [
      [
        $createLabel("Số CIF KH/Tài khoản chuyển", { skin: "titleInforKey" }),
        this.detailUI.txtMaKhachHang2
      ],
      [
        $createLabel("Tên người chuyển", { skin: "titleInforKey" }),
        flxTenKhachHangContainer,
      ],
      [
        $createLabel("Địa chỉ người chuyển", { skin: "titleInforKey" }),
        flxDiaChi
      ],
      [
        $createLabel("Mã quốc gia người chuyển", { skin: "titleInforKey" }),
        this.detailUI.txtMaQuocGiaNguoiChuyen
      ]
    ];
    this.tableThongTinNguoiChuyenTienLeft = $createTable(
      flxThongTinNguoiChuyenLeft,
      contentFlxThongTinNguoiChuyenLeft,
      {
        oddColumnSkin: "rowTitleLeft",
        evenColumnSkin: "rowTitleRight",
        rowHeight: this.generalHeight + "px"
      }
    );
    //Thông tin người chuyển tiền cột phải
    const flxThongTinNguoiChuyenRight = $createFlexContainer(
      this.flxThongTinNguoiChuyen,
      {
        width: "50%",
        left: "50%"
      }
    );
    this.detailUI.txtLoaiTaiKhoanNguoiChuyen = $createLabel();
    this.detailUI.txtThanhPhoNguoiChuyen = $createLabel();
    this.detailUI.txtMaBuuChinhNguoiChuyen = $createLabel();
    this.detailUI.txtQuanHuyenNguoiChuyen = $createLabel();
    this.detailUI.txtLoaiGiayToTuyThan = $createLabel();
    this.detailUI.txtSoGiayToTuyThan = $createLabel();
    this.detailUI.txtNgaySinhCuaNguoiChuyen = $createLabel();

    const contentFlxThongTinNguoiChuyenRight = [
      [
        $createLabel("Loại tài khoản người chuyển", { skin: "titleInforKey" }),
        this.detailUI.txtLoaiTaiKhoanNguoiChuyen
      ],
      [
        $createLabel("Thành phố người chuyển", { skin: "titleInforKey" }),
        this.detailUI.txtThanhPhoNguoiChuyen
      ],
      [
        $createLabel("Mã bưu chính người chuyển", { skin: "titleInforKey" }),
        this.detailUI.txtMaBuuChinhNguoiChuyen
      ],
      [
        $createLabel("Quận/Huyện người chuyển", { skin: "titleInforKey" }),
        this.detailUI.txtQuanHuyenNguoiChuyen
      ],
      [
        $createLabel("Loại giấy tờ tùy thân", { skin: "titleInforKey" }),
        this.detailUI.txtLoaiGiayToTuyThan
      ],
      [
        $createLabel("Số giấy tờ tùy thân", { skin: "titleInforKey" }),
        this.detailUI.txtSoGiayToTuyThan
      ],
      [
        $createLabel("Ngày sinh người chuyển tiền", { skin: "titleInforKey" }),
        this.detailUI.txtNgaySinhCuaNguoiChuyen
      ]
    ];
    $createTable(
      flxThongTinNguoiChuyenRight,
      contentFlxThongTinNguoiChuyenRight,
      {
        oddColumnSkin: "rowTitleLeft",
        evenColumnSkin: "rowTitleRight",
        rowHeight: this.generalHeight + "px"
      }
    );
    //Label Thông tin người thụ hưởng
    this.flxLabelThongTinNguoiThuHuong = $createFlexContainer(flxContainer, {
      height: this.generalHeight + "px",
      top: $getElementTop(this.flxThongTinNguoiChuyen)
    });
    const contentFlxLabelThongTinNguoiThuHuong = [
      [
        $createLabel("Thông tin người thụ hưởng", {
          skin: "titleInfor"
        })
      ]
    ];
    $createTable(
      this.flxLabelThongTinNguoiThuHuong,
      contentFlxLabelThongTinNguoiThuHuong
    );
    //Thông tin người thụ hưởng cột trái
    this.flxThongTinNguoiThuHuong = $createFlexContainer(flxContainer, {
      top: $getElementTop(this.flxLabelThongTinNguoiThuHuong),
      height: this.generalHeight * 5 + "px"
    });
    this.detailUI.txtSoTaiKhoanNguoiHuong = $createLabel();
    //---Tên người hưởng
    const flxTenNguoiThuHuongContainer = $createFlexContainer();
    flxTenNguoiThuHuongContainer.height = this.generalHeight * 2 + "px";
    //---Tạo dòng đầu gồm txt và 2 buttons
    const flxTenNguoiThuHuongFirst = $createFlexContainer(flxTenNguoiThuHuongContainer, {
      height: this.generalHeight + "px"
    });
    this.detailUI.txtTenNguoiThuHuong = $createLabel();
    this.tenNguoiThuHuongTextBoxs.push(this.detailUI.txtTenNguoiThuHuong);
    flxTenNguoiThuHuongFirst.add(this.detailUI.txtTenNguoiThuHuong);
    //dòng2
    const flxTenNguoiThuHuongSecond = $createFlexContainer(flxTenNguoiThuHuongContainer, {
      top: this.generalHeight + "px",
      height: this.generalHeight + "px"
    });
    const txtTenNguoiThuHuongg2 = $createLabel();
    flxTenNguoiThuHuongSecond.add(txtTenNguoiThuHuongg2);
    this.tenNguoiThuHuongTextBoxs.push(txtTenNguoiThuHuongg2);
    flxTenNguoiThuHuongContainer.add(flxTenNguoiThuHuongFirst);
    flxTenNguoiThuHuongContainer.add(flxTenNguoiThuHuongSecond);
    //Địa chỉ người thụ hưởng
    const flxDiaChiNguoiHuong = $createFlexContainer();
    flxDiaChiNguoiHuong.height = this.generalHeight * 8 + "px";
    const flxDiaChiNguoiHuongFirst = $createFlexContainer(flxDiaChiNguoiHuong, {
      height: this.generalHeight + "px"
    });
    this.detailUI.txtDiaChiNguoiThuHuong = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      skin: "skinSenderF72",
      height: "100%"
    });
    this.diaChiNguoiHuongTextBoxs.push(this.detailUI.txtDiaChiNguoiThuHuong);
    this.form.btnAddDiaChiNguoiHuong = $createFlexContainer();
    this.form.btnDeleteDiaChiNguoiHuong = $createFlexContainer();
    this.form.btnAddDiaChiNguoiHuong.width = "10%";
    this.form.btnAddDiaChiNguoiHuong.left = "80%";
    this.form.btnDeleteDiaChiNguoiHuong.width = "10%";
    this.form.btnDeleteDiaChiNguoiHuong.left = "90%";
    const btnAddDiaChiNguoiHuong = $createLabel("", {
      skin: "addIconSkin"
    });
    const btnDeleteDiaChiNguoiHuong = $createLabel("", {
      skin: "deleteIconSkin"
    });
    this.form.btnAddDiaChiNguoiHuong.add(btnAddDiaChiNguoiHuong);
    this.form.btnDeleteDiaChiNguoiHuong.add(btnDeleteDiaChiNguoiHuong);
    this.form.btnAddDiaChiNguoiHuong.onClick = () => { this.onClickBtnAddDiaChiNguoiHuong(); }
    this.form.btnDeleteDiaChiNguoiHuong.onClick = () => {
      for (var i = this.amountOfAddressLineNguoiHuong - 1; i >= 1; i--) {
        if (this.diaChiNguoiHuongTextBoxs[i].isVisible) {
          this.diaChiNguoiHuongTextBoxs[i].isVisible = false;
          this.diaChiNguoiHuongTextBoxs[i].text = "";
          break;
        }
      }
      if ($isGreaterThanOrEqual(this.tableThongTinNguoiThuHuongLeft[5].height, this.generalHeight * 2 + "px")) {
        this.tableThongTinNguoiThuHuongLeft[4].height = $subtractUnit(
          this.tableThongTinNguoiThuHuongLeft[4].height,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiThuHuongLeft[5].height = $subtractUnit(
          this.tableThongTinNguoiThuHuongLeft[5].height,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiThuHuongLeft[6].top = $subtractUnit(
          this.tableThongTinNguoiThuHuongLeft[6].top,
          this.generalHeight + "px"
        );
        this.tableThongTinNguoiThuHuongLeft[7].top = $subtractUnit(
          this.tableThongTinNguoiThuHuongLeft[7].top,
          this.generalHeight + "px"
        );
        if ($isGreaterThan(this.flxThongTinNguoiThuHuong.height, this.generalHeight * 5 + "px")) {
          this.flxThongTinNguoiThuHuong.height = $subtractUnit(
            this.flxThongTinNguoiThuHuong.height,
            this.generalHeight + "px"
          );
          this.reRenderUIThongTinNguoiThuHuong();
        }
      }
    };
    flxDiaChiNguoiHuongFirst.add(this.detailUI.txtDiaChiNguoiThuHuong);
    flxDiaChiNguoiHuongFirst.add(this.form.btnAddDiaChiNguoiHuong);
    flxDiaChiNguoiHuongFirst.add(this.form.btnDeleteDiaChiNguoiHuong);
    //dòng2
    const flxDiaChiNguoiHuongSecond = $createFlexContainer(flxDiaChiNguoiHuong, {
      top: this.generalHeight + "px",
      height: this.generalHeight + "px"
    });
    this.diaChiNguoiHuong2 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChiNguoiHuongSecond.add(this.diaChiNguoiHuong2);
    //dòng 3
    const flxDiaChiNguoiHuongThird = $createFlexContainer(flxDiaChiNguoiHuong, {
      top: this.generalHeight * 2 + "px",
      height: this.generalHeight + "px"
    });
    this.diaChiNguoiHuong3 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChiNguoiHuongThird.add(this.diaChiNguoiHuong3);
    //dòng 4
    const flxDiaChiNguoiHuongFourth = $createFlexContainer(flxDiaChiNguoiHuong, {
      top: this.generalHeight * 3 + "px",
      height: this.generalHeight + "px"
    });
    this.diaChiNguoiHuong4 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChiNguoiHuongFourth.add(this.diaChiNguoiHuong4);
    //dòng 5
    const flxDiaChiNguoiHuong5 = $createFlexContainer(flxDiaChiNguoiHuong, {
      top: this.generalHeight * 4 + "px",
      height: this.generalHeight + "px"
    });
    this.diaChiNguoiHuong5 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChiNguoiHuong5.add(this.diaChiNguoiHuong5);
    //dòng 6
    const flxDiaChiNguoiHuong6 = $createFlexContainer(flxDiaChiNguoiHuong, {
      top: this.generalHeight * 5 + "px",
      height: this.generalHeight + "px"
    });
    this.diaChiNguoiHuong6 = $createTextBox({
      maxLength: 25,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChiNguoiHuong6.add(this.diaChiNguoiHuong6);

    this.diaChiNguoiHuongTextBoxs.push(this.diaChiNguoiHuong2);
    this.diaChiNguoiHuongTextBoxs.push(this.diaChiNguoiHuong3);
    this.diaChiNguoiHuongTextBoxs.push(this.diaChiNguoiHuong4);
    this.diaChiNguoiHuongTextBoxs.push(this.diaChiNguoiHuong5);
    this.diaChiNguoiHuongTextBoxs.push(this.diaChiNguoiHuong6);

    flxDiaChiNguoiHuong.add(flxDiaChiNguoiHuongFirst);
    flxDiaChiNguoiHuong.add(flxDiaChiNguoiHuongSecond);
    flxDiaChiNguoiHuong.add(flxDiaChiNguoiHuongThird);
    flxDiaChiNguoiHuong.add(flxDiaChiNguoiHuongFourth);
    flxDiaChiNguoiHuong.add(flxDiaChiNguoiHuong5);
    flxDiaChiNguoiHuong.add(flxDiaChiNguoiHuong6);
    //Quốc gia người thụ hưởng
    this.detailUI.txtQuocGiaNguoiThuHuong = $createLabel();
    const flxThongTinNguoiThuHuongLeft = $createFlexContainer(
      this.flxThongTinNguoiThuHuong,
      {
        width: "50%",
        left: "0"
      }
    );
    const contentFlxThongTinNguoiThuHuongLeft = [
      [
        $createLabel("Số tài khoản người hưởng", { skin: "titleInforKey" }),
        this.detailUI.txtSoTaiKhoanNguoiHuong
      ],
      [
        $createLabel("Tên người thụ hưởng", { skin: "titleInforKey" }),
        flxTenNguoiThuHuongContainer
      ],
      [
        $createLabel("Địa chỉ người thụ hưởng", { skin: "titleInforKey" }),
        flxDiaChiNguoiHuong
      ],
      [
        $createLabel("Quốc gia người thụ hưởng", { skin: "titleInforKey" }),
        this.detailUI.txtQuocGiaNguoiThuHuong
      ]
    ];
    this.tableThongTinNguoiThuHuongLeft = $createTable(
      flxThongTinNguoiThuHuongLeft,
      contentFlxThongTinNguoiThuHuongLeft,
      {
        oddColumnSkin: "rowTitleLeft",
        evenColumnSkin: "rowTitleRight",
        rowHeight: this.generalHeight + "px"
      }
    );
    //Thông tin người thụ hưởng cột phải
    const flxThongTinNguoiThuHuongRight = $createFlexContainer(
      this.flxThongTinNguoiThuHuong,
      {
        width: "50%",
        left: "50%"
      }
    );
    this.detailUI.txtLoaiTaiKhoanNganHangNguoiHuong = $createLabel();
    this.detailUI.txtLoaiTaiKhoanNguoiHuong = $createLabel();
    this.detailUI.txtThanhPhoNguoiThuHuong = $createLabel();
    this.detailUI.txtBangNguoiThuHuong = $createLabel();
    this.detailUI.txtMaBuuChinhNguoiHuong = $createLabel();
    const contentFlxThongTinNguoiThuHuongRight = [
      [
        $createLabel("Loại TK ngân hàng người hưởng", {
          skin: "titleInforKey"
        }),
        this.detailUI.txtLoaiTaiKhoanNganHangNguoiHuong
      ],
      [
        $createLabel("Loại tài khoản người thụ hưởng", {
          skin: "titleInforKey"
        }),
        this.detailUI.txtLoaiTaiKhoanNguoiHuong
      ],
      [
        $createLabel("Thành phố người thụ hưởng", { skin: "titleInforKey" }),
        this.detailUI.txtThanhPhoNguoiThuHuong
      ],
      [
        $createLabel("Bang người thụ hưởng", { skin: "titleInforKey" }),
        this.detailUI.txtBangNguoiThuHuong
      ],
      [
        $createLabel("Mã bưu chính người thụ hưởng", { skin: "titleInforKey" }),
        this.detailUI.txtMaBuuChinhNguoiHuong
      ]
    ];
    $createTable(
      flxThongTinNguoiThuHuongRight,
      contentFlxThongTinNguoiThuHuongRight,
      {
        oddColumnSkin: "rowTitleLeft",
        evenColumnSkin: "rowTitleRight",
        rowHeight: this.generalHeight + "px"
      }
    );
    //Label Thông tin ngân hàng thụ hưởng
    this.flxLabelThongTinNganHangThuHuong = $createFlexContainer(
      flxContainer,
      {
        height: this.generalHeight + "px",
        top: $getElementTop(this.flxThongTinNguoiThuHuong)
      }
    );
    const contentFlxLabelThongTinNganHangThuHuong = [
      [
        $createLabel("Thông tin ngân hàng thụ hưởng", {
          skin: "titleInfor"
        })
      ]
    ];
    $createTable(
      this.flxLabelThongTinNganHangThuHuong,
      contentFlxLabelThongTinNganHangThuHuong
    );
    //Thông tin ngân hàng thụ hưởng cột trái
    this.flxThongTinNganHangThuHuong = $createFlexContainer(flxContainer, {
      height: this.generalHeight * 10 + "px",
      top: $getElementTop(this.flxLabelThongTinNganHangThuHuong)
    });
    this.flxThongTinNganHangThuHuongLeft = $createFlexContainer(
      this.flxThongTinNganHangThuHuong,
      {
        width: "50%",
        left: "0"
      }
    );
    this.detailUI.txtHinhThucNhap = $createLabel();
    //flxswiftcode
    const flxSwiftCode = $createFlexContainer();
    this.detailUI.txtSwiftCodeNganHangThuHuong = $createLabel("", {
      width: "50%"
    });
    this.detailUI.lblSwiftCodeNganHangThuHuong = $createLabel("", {
      width: "50%",
      left: "50%"
    });
    flxSwiftCode.add(this.detailUI.txtSwiftCodeNganHangThuHuong);
    flxSwiftCode.add(this.detailUI.lblSwiftCodeNganHangThuHuong);
    this.detailUI.txtTenNganHangThuHuong = $createTextBox({
      maxLength: 70,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      skin: "skinSenderF72",
      height: "100%",
      width: "100%",
    });
    this.detailUI.txtTenNganHangThuHuong.onTextChange = (textBox) => {
      const text = $trim(textBox.text);
      this.detailUI.txtTenNganHangThuHuong.text = text;
      if (text.length > 0 && text[0] === "-") {
        this.showErrorMessage("Vui lòng không nhập - ở đầu dòng.");
        return;
      }
      if (text && $isContainsVietnamese(text)) {
        this.showErrorMessage("Vui lòng không nhập tiếng Anh.");
        return;
      }
    };
    //flx country
    const flxCountry = $createFlexContainer();
    this.detailUI.lbCountry = $createListBox([], [], {
      left: "50%",
      width: "50%",
      height: "100%",
      skin: "skinListBoxContentTable"
    });
    this.detailUI.lbCountry.onSelection = (lb) => {
      this.detailUI.lblCountry.text = this.getDisplayCountry(lb.selectedKey);
      this.detailUI.lblCountry.toolTip = this.detailUI.lblCountry.text;
      if (this.detailUI.lbKenhGiaoDich.selectedKey.includes("NIUM") && !$isNullOrEmpty(this.detailUI.txtSwiftCodeNganHangThuHuong.text) && lb.selectedKey !== this.detailData.countryCode) {
        this.showWarningMessage(
          "Giá trị Quốc gia (theo ngân hàng) đang khác giá trị Quốc gia người thụ hưởng."
        );
      }
      else {
        $hideToastMessage(this.view.flxToastMessage);
      }
    };
    this.detailUI.lblCountry = $createLabel("", {
      width: "50%"
    });
    flxCountry.add(this.detailUI.lbCountry);
    flxCountry.add(this.detailUI.lblCountry);
    this.detailUI.txtSwiftCodeNganHangTrungGian = $createLabel();
    this.detailUI.txtNganHangTrungGian = $createLabel();
    this.form.txtSwiftMT103SentTo = $createTextBox({
      skin: "skinListBoxContentTable",
      width: "100%",
      height: "100%"
    });
    //--Sender to receiver
    const flxSenderToReceiverInfor = $createFlexContainer();
    flxSenderToReceiverInfor.height = this.generalHeight * 4 + "px";
    //---Tạo dòng đầu gồm txt và 2 buttons
    const flxSenderF72First = $createFlexContainer(flxSenderToReceiverInfor, {
      height: this.generalHeight + "px"
    });
    this.form.tbSenderToReceiverInfor = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      skin: "skinSenderF72",
      height: "100%"
    });
    this.form.tbSenderToReceiverInfor.isFirst = true;
    this.senderToReceiverInfoTextBoxs.push(this.form.tbSenderToReceiverInfor);
    this.form.btnAdd = $createFlexContainer();
    this.form.btnDelete = $createFlexContainer();
    this.form.btnAdd.width = "10%";
    this.form.btnAdd.left = "80%";
    this.form.btnDelete.width = "10%";
    this.form.btnDelete.left = "90%";
    const btnAdd = $createLabel("", {
      skin: "addIconSkin"
    });
    const btnDelete = $createLabel("", {
      skin: "deleteIconSkin"
    });
    this.form.btnAdd.add(btnAdd);
    this.form.btnDelete.add(btnDelete);
    this.form.btnAdd.onClick = () => {
      for (var i = 0; i < this.senderToReceiverInfoTextBoxs.length; i++) {
        if (!this.senderToReceiverInfoTextBoxs[i].isVisible) {
          this.senderToReceiverInfoTextBoxs[i].isVisible = true;
          break;
        }
      }
      const height = this.tableThongTinNganHangThuHuongLeft[14].height;
      if ($isLessThanOrEqual(height, this.generalHeight * 3 + "px")) {
        this.tableThongTinNganHangThuHuongLeft[14].height = $addUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNganHangThuHuongLeft[15].height = $addUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNganHangThuHuongLeft[16].top = $addUnit(
          this.tableThongTinNganHangThuHuongLeft[16].top,
          this.generalHeight + "px"
        );
        this.tableThongTinNganHangThuHuongLeft[17].top = $addUnit(
          this.tableThongTinNganHangThuHuongLeft[17].top,
          this.generalHeight + "px"
        );
        this.flxThongTinNganHangThuHuong.height = $addUnit(
          this.flxThongTinNganHangThuHuong.height,
          this.generalHeight + "px"
        );
        this.reRenderThongTinChuyenTienUI();
      }
    };
    this.form.btnDelete.onClick = () => {
      for (var i = this.senderToReceiverInfoTextBoxs.length - 1; i >= 1; i--) {
        if (this.senderToReceiverInfoTextBoxs[i].isVisible) {
          this.senderToReceiverInfoTextBoxs[i].isVisible = false;
          this.senderToReceiverInfoTextBoxs[i].text = "";
          break;
        }
      }
      const height = this.tableThongTinNganHangThuHuongLeft[14].height;
      if ($isGreaterThanOrEqual(height, this.generalHeight * 2 + "px")) {
        this.tableThongTinNganHangThuHuongLeft[14].height = $subtractUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNganHangThuHuongLeft[15].height = $subtractUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNganHangThuHuongLeft[16].top = $subtractUnit(
          this.tableThongTinNganHangThuHuongLeft[16].top,
          this.generalHeight + "px"
        );
        this.tableThongTinNganHangThuHuongLeft[17].top = $subtractUnit(
          this.tableThongTinNganHangThuHuongLeft[17].top,
          this.generalHeight + "px"
        );
        this.flxThongTinNganHangThuHuong.height = $subtractUnit(
          this.flxThongTinNganHangThuHuong.height,
          this.generalHeight + "px"
        );
        this.reRenderThongTinChuyenTienUI();
      }
    };
    flxSenderF72First.add(this.form.tbSenderToReceiverInfor);
    flxSenderF72First.add(this.form.btnAdd);
    flxSenderF72First.add(this.form.btnDelete);
    //dòng2
    const flxSenderF72Second = $createFlexContainer(flxSenderToReceiverInfor, {
      top: this.generalHeight + "px",
      height: this.generalHeight + "px"
    });
    const sender2 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxSenderF72Second.add(sender2);
    //dòng 3
    const flxSenderF72Third = $createFlexContainer(flxSenderToReceiverInfor, {
      top: this.generalHeight * 2 + "px",
      height: this.generalHeight + "px"
    });
    const sender3 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxSenderF72Third.add(sender3);
    //dòng 4
    const flxSenderF72Fourth = $createFlexContainer(flxSenderToReceiverInfor, {
      top: this.generalHeight * 3 + "px",
      height: this.generalHeight + "px"
    });
    const sender4 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxSenderF72Fourth.add(sender4);

    this.senderToReceiverInfoTextBoxs.push(sender2);
    this.senderToReceiverInfoTextBoxs.push(sender3);
    this.senderToReceiverInfoTextBoxs.push(sender4);
    this.senderToReceiverInfoTextBoxs.forEach((textBox) => {
      textBox.onTextChange = ({ text, isFirst }) => {
        if (text.length > 0 && text[0] !== "/") {
          if (isFirst) {
            this.showErrorMessage("Vui lòng nhập code theo format /");
            return;
          }
          this.showErrorMessage("Vui lòng nhập code theo format //");
          return;
        }
        if (
          text.length > 1 &&
          !isFirst &&
          (text[0] !== "/" || text[1] !== "/")
        ) {
          this.showErrorMessage("Vui lòng nhập code theo format //");
          return;
        }
        let isHasText = false;
        this.senderToReceiverInfoTextBoxs.forEach((key) => {
          if (!$isNullOrEmpty(key.text)) {
            isHasText = true;
          }
        });
        this.form.txtSwiftMT103SentTo.text =
          isHasText
            ? "Crcust" : "";
        if ($isContainsVietnamese($trim(text))) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh.");
          return;
        }
      };
    });
    flxSenderToReceiverInfor.add(flxSenderF72First);
    flxSenderToReceiverInfor.add(flxSenderF72Second);
    flxSenderToReceiverInfor.add(flxSenderF72Third);
    flxSenderToReceiverInfor.add(flxSenderF72Fourth);

    //--regulatory
    const flxRegulatory = $createFlexContainer();
    flxRegulatory.height = this.generalHeight * 4 + "px";
    //---Tạo dòng đầu gồm txt và 2 buttons
    const flxF77BFirst = $createFlexContainer(flxRegulatory, {
      height: this.generalHeight + "px"
    });
    this.form.tbRegulatoryReporting = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      skin: "skinSenderF72",
      height: "100%"
    });
    this.form.tbRegulatoryReporting.isFirst = true;
    this.f77bTextBoxs.push(this.form.tbRegulatoryReporting);
    this.form.btnAddF77B = $createFlexContainer();
    this.form.btnDeleteF77B = $createFlexContainer();
    this.form.btnAddF77B.width = "10%";
    this.form.btnAddF77B.left = "80%";
    this.form.btnDeleteF77B.width = "10%";
    this.form.btnDeleteF77B.left = "90%";
    const btnAddF77B = $createLabel("", {
      skin: "addIconSkin"
    });
    const btnDeleteF77B = $createLabel("", {
      skin: "deleteIconSkin"
    });
    this.form.btnAddF77B.add(btnAddF77B);
    this.form.btnDeleteF77B.add(btnDeleteF77B);
    this.form.btnAddF77B.onClick = () => {
      for (var i = 0; i < this.f77bTextBoxs.length; i++) {
        if (!this.f77bTextBoxs[i].isVisible) {
          this.f77bTextBoxs[i].isVisible = true;
          break;
        }
      }
      const height = this.tableThongTinNganHangThuHuongLeft[16].height;
      if ($isLessThanOrEqual(height, this.generalHeight * 3 + "px")) {
        this.tableThongTinNganHangThuHuongLeft[16].height = $addUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNganHangThuHuongLeft[17].height = $addUnit(
          height,
          this.generalHeight + "px"
        );
        this.flxThongTinNganHangThuHuong.height = $addUnit(
          this.flxThongTinNganHangThuHuong.height,
          this.generalHeight + "px"
        );
        this.reRenderThongTinChuyenTienUI();
      }
    };
    this.form.btnDeleteF77B.onClick = () => {
      for (var i = this.f77bTextBoxs.length - 1; i >= 1; i--) {
        if (this.f77bTextBoxs[i].isVisible) {
          this.f77bTextBoxs[i].isVisible = false;
          this.f77bTextBoxs[i].text = "";
          break;
        }
      }
      const height = this.tableThongTinNganHangThuHuongLeft[16].height;
      if ($isGreaterThanOrEqual(height, this.generalHeight * 2 + "px")) {
        this.tableThongTinNganHangThuHuongLeft[16].height = $subtractUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNganHangThuHuongLeft[17].height = $subtractUnit(
          height,
          this.generalHeight + "px"
        );
        this.flxThongTinNganHangThuHuong.height = $subtractUnit(
          this.flxThongTinNganHangThuHuong.height,
          this.generalHeight + "px"
        );
        this.reRenderThongTinChuyenTienUI();
      }
    };
    flxF77BFirst.add(this.form.tbRegulatoryReporting);
    flxF77BFirst.add(this.form.btnAddF77B);
    flxF77BFirst.add(this.form.btnDeleteF77B);
    //dòng2
    const flxF77BSecond = $createFlexContainer(flxRegulatory, {
      top: this.generalHeight + "px",
      height: this.generalHeight + "px"
    });
    const f77B2 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxF77BSecond.add(f77B2);
    //dòng 3
    const flxF77BThird = $createFlexContainer(flxRegulatory, {
      top: this.generalHeight * 2 + "px",
      height: this.generalHeight + "px"
    });
    const f77B3 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxF77BThird.add(f77B3);
    //dòng 4
    const flxF77BFourth = $createFlexContainer(flxRegulatory, {
      top: this.generalHeight * 3 + "px",
      height: this.generalHeight + "px"
    });
    const f77B4 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxF77BFourth.add(f77B4);

    this.f77bTextBoxs.push(f77B2);
    this.f77bTextBoxs.push(f77B3);
    this.f77bTextBoxs.push(f77B4);

    this.f77bTextBoxs.forEach((textBox) => {
      textBox.onTextChange = ({ text, isFirst }) => {
        if (text.length > 0 && text[0] !== "/") {
          if (isFirst) {
            this.showErrorMessage("Vui lòng nhập code theo format /");
            return;
          }
          this.showErrorMessage("Vui lòng nhập code theo format //");
          return;
        }
        if (
          text.length > 1 &&
          !isFirst &&
          (text[0] !== "/" || text[1] !== "/")
        ) {
          this.showErrorMessage("Vui lòng nhập code theo format //");
          return;
        }
        if ($isContainsVietnamese($trim(text))) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh.");
          return;
        }
      };
    });
    flxRegulatory.add(flxF77BFirst);
    flxRegulatory.add(flxF77BSecond);
    flxRegulatory.add(flxF77BThird);
    flxRegulatory.add(flxF77BFourth);
    //tạo table
    const contentFlxThongTinNganHangThuHuongLeft = [
      [
        $createLabel("Hình thức nhập", { skin: "titleInforKey" }),
        this.detailUI.txtHinhThucNhap
      ],
      [$createLabel("Mã Swift", { skin: "titleInforKey" }), flxSwiftCode],
      [
        $createLabel("Tên ngân hàng thụ hưởng", { skin: "titleInforKey" }),
        this.detailUI.txtTenNganHangThuHuong
      ],
      [
        $createLabel("Quốc gia (theo ngân hàng)", { skin: "titleInforKey" }),
        flxCountry
      ],
      [
        $createLabel("Swift code ngân hàng trung gian", {
          skin: "titleInforKey"
        }),
        this.detailUI.txtSwiftCodeNganHangTrungGian
      ],
      [
        $createLabel("Tên ngân hàng trung gian", { skin: "titleInforKey" }),
        this.detailUI.txtNganHangTrungGian
      ],
      [
        $createLabel("Swift MT103 sent to:", { skin: "titleInforKey" }),
        this.form.txtSwiftMT103SentTo
      ],
      [
        $createLabel("Sender to Receiver Info (F72):", {
          skin: "titleInforKey"
        }),
        flxSenderToReceiverInfor
      ],
      [
        $createLabel("Regulatory Reporting (F77B):", { skin: "titleInforKey" }),
        flxRegulatory
      ]
    ];
    this.tableThongTinNganHangThuHuongLeft = $createTable(
      this.flxThongTinNganHangThuHuongLeft,
      contentFlxThongTinNganHangThuHuongLeft,
      {
        oddColumnSkin: "rowTitleLeft",
        evenColumnSkin: "rowTitleRight",
        rowHeight: this.generalHeight + "px"
      }
    );
    // Thông tin ngân hàng thụ hưởng cột phải
    this.flxThongTinNganHangThuHuongRight = $createFlexContainer(
      this.flxThongTinNganHangThuHuong,
      {
        width: "50%",
        left: "50%"
      }
    );
    this.detailUI.txtLoaiMaNganHangHuong = $createLabel();
    this.detailUI.txtBSBorRouting = $createTextBox({
      width: "100%",
      height: "100%",
      skin: "skinTextBoxNoBorderGray",
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      maxLength: 35
    });

    // === Địa chỉ ngân hàng thụ hưởng
    const flxDiaChiNganHangHuongContainer = $createFlexContainer();
    flxDiaChiNganHangHuongContainer.height = this.generalHeight * 2 + "px";
    //---Tạo dòng đầu gồm txt và 2 buttons
    const flxDiaChiNganHangHuongFirst = $createFlexContainer(flxDiaChiNganHangHuongContainer, {
      height: this.generalHeight + "px"
    });
    this.detailUI.txtDiaChiNganHangHuong = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      skin: "skinSenderF72",
      height: "100%"
    });
    this.detailUI.txtDiaChiNganHangHuong.isFirst = true;
    this.nganHangThuHuongTextBoxs.push(this.detailUI.txtDiaChiNganHangHuong);
    this.form.btnAddDiaChiNganHangHuong = $createFlexContainer();
    this.form.btnDeleteDiaChiNganHangHuong = $createFlexContainer();
    this.form.btnAddDiaChiNganHangHuong.width = "10%";
    this.form.btnAddDiaChiNganHangHuong.left = "80%";
    this.form.btnDeleteDiaChiNganHangHuong.width = "10%";
    this.form.btnDeleteDiaChiNganHangHuong.left = "90%";
    const btnAddDiaChiNganHangHuong = $createLabel("", {
      skin: "addIconSkin"
    });
    const btnDeleteDiaChiNganHangHuong = $createLabel("", {
      skin: "deleteIconSkin"
    });
    this.form.btnAddDiaChiNganHangHuong.add(btnAddDiaChiNganHangHuong);
    this.form.btnDeleteDiaChiNganHangHuong.add(btnDeleteDiaChiNganHangHuong);
    this.form.btnAddDiaChiNganHangHuong.onClick = () => {
      for (var i = 0; i < this.nganHangThuHuongTextBoxs.length; i++) {
        if (!this.nganHangThuHuongTextBoxs[i].isVisible) {
          this.nganHangThuHuongTextBoxs[i].isVisible = true;
          break;
        }
      }
      const height = this.tableThongTinNganHangThuHuongRight[5].height;
      if ($isLessThan(height, this.generalHeight * 2 + "px")) {
        this.tableThongTinNganHangThuHuongRight[4].height = $addUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNganHangThuHuongRight[5].height = $addUnit(
          height,
          this.generalHeight + "px"
        );
      }
    };
    this.form.btnDeleteDiaChiNganHangHuong.onClick = () => {
      for (var i = this.nganHangThuHuongTextBoxs.length - 1; i >= 1; i--) {
        if (this.nganHangThuHuongTextBoxs[i].isVisible) {
          this.nganHangThuHuongTextBoxs[i].isVisible = false;
          this.nganHangThuHuongTextBoxs[i].text = "";
          break;
        }
      }
      const height = this.tableThongTinNganHangThuHuongRight[5].height;
      if ($isGreaterThanOrEqual(height, this.generalHeight * 2 + "px")) {
        this.tableThongTinNganHangThuHuongRight[4].height = $subtractUnit(
          height,
          this.generalHeight + "px"
        );
        this.tableThongTinNganHangThuHuongRight[5].height = $subtractUnit(
          height,
          this.generalHeight + "px"
        );
      }
    };
    flxDiaChiNganHangHuongFirst.add(this.detailUI.txtDiaChiNganHangHuong);
    flxDiaChiNganHangHuongFirst.add(this.form.btnAddDiaChiNganHangHuong);
    flxDiaChiNganHangHuongFirst.add(this.form.btnDeleteDiaChiNganHangHuong);
    //dòng2
    const flxDiaChiNganHangHuongSecond = $createFlexContainer(flxDiaChiNganHangHuongContainer, {
      top: this.generalHeight + "px",
      height: this.generalHeight + "px"
    });
    const txtDiaChiNganHangHuongg2 = $createTextBox({
      maxLength: 35,
      restrictCharactersSet: T24_RESTRICT_CHARACTER,
      height: "100%",
      skin: "skinSenderF72"
    });
    flxDiaChiNganHangHuongSecond.add(txtDiaChiNganHangHuongg2);
    this.nganHangThuHuongTextBoxs.push(txtDiaChiNganHangHuongg2);
    this.nganHangThuHuongTextBoxs.forEach((textBox, index) => {
      textBox.onTextChange = ({ text }) => {
        if (text.length > 0 && text[0] === "-") {
          this.showErrorMessage("Vui lòng không nhập - ở đầu dòng.");
          return;
        }
      };
      if (index === 0) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (txtDiaChiNganHangHuongg2.isVisible === false) {
            txtDiaChiNganHangHuongg2.isVisible = true;
            this.tableThongTinNganHangThuHuongRight[4].height = $addUnit(
              this.tableThongTinNganHangThuHuongRight[4].height,
              this.generalHeight + "px"
            );
            this.tableThongTinNganHangThuHuongRight[5].height = $addUnit(
              this.tableThongTinNganHangThuHuongRight[5].height,
              this.generalHeight + "px"
            );
            this.view.forceLayout();
          }
          txtDiaChiNganHangHuongg2.setFocus(true);
        }
      }
    });
    flxDiaChiNganHangHuongContainer.add(flxDiaChiNganHangHuongFirst);
    flxDiaChiNganHangHuongContainer.add(flxDiaChiNganHangHuongSecond);
    //BSB
    this.detailUI.lblBSBorRouting = $createLabel("", {
      skin: "titleInforKey"
    });
    const contentFlxThongTinNganHangThuHuongRight = [
      [
        $createLabel("Loại mã ngân hàng hưởng", { skin: "titleInforKey" }),
        this.detailUI.txtLoaiMaNganHangHuong
      ],
      [this.detailUI.lblBSBorRouting, this.detailUI.txtBSBorRouting],
      [
        $createLabel("Địa chỉ ngân hàng hưởng", { skin: "titleInforKey" }),
        flxDiaChiNganHangHuongContainer
      ]
    ];
    this.tableThongTinNganHangThuHuongRight = $createTable(
      this.flxThongTinNganHangThuHuongRight,
      contentFlxThongTinNganHangThuHuongRight,
      {
        oddColumnSkin: "rowTitleLeft",
        evenColumnSkin: "rowTitleRight",
        rowHeight: this.generalHeight + "px"
      }
    );
    //Label Thông tin Kiểm tra
    this.flxLabelThongTinKiemTra = $createFlexContainer(flxContainer, {
      height: this.generalHeight + "px",
      top: $getElementTop(this.flxThongTinNganHangThuHuong)
    });
    const contentFlxLabelThongTinKiemTra = [
      [$createLabel("Thông tin kiểm tra", { skin: "titleInfor" })]
    ];
    $createTable(this.flxLabelThongTinKiemTra, contentFlxLabelThongTinKiemTra);
    //Thông tin kiểm tra
    const displayLbKiemTraPCRT = Object.values(CHECK_PCRT);
    this.form.lbKiemTraPCRT = $createListBox(
      displayLbKiemTraPCRT,
      Object.keys(CHECK_PCRT),
      { width: "30%" }
    );
    this.form.lbKetQuaKiemTra = $createListBox(
      ["Hồ sơ hợp lệ", "Bổ sung hồ sơ", "Từ chối hồ sơ"],
      Object.values(CHECK_RESULT),
      { width: "30%" }
    );
    this.form.lbKetQuaKiemTra.onSelection = ({ selectedkey }) => {
      const isValid = selectedkey === CHECK_RESULT.ValidRecords;
      this.setEnabledForUserTable(isValid);
      this.setEnabledToFormBoSung(isValid);
      if (isValid) {
        this.form.txtMoTaLyDoChiTiet.text = "";
        this.form.txtMoTaLyDoChiTiet.setEnabled(false);
      } else {
        this.form.txtMoTaLyDoChiTiet.text = `+ Chất lượng hồ sơ không đạt yêu cầu:\n+ Danh mục hồ sơ chưa đầy đủ theo quy định của PVcomBank:\n+ Chứng từ chưa đúng quy định của PVcomBank:\n+ Có sự sai biệt/không khớp đúng thông tin giữa các hồ sơ:\n+ Lý do khác:`;
        const roleCanUpdateMoTaLyDo = this.paymentModel === PAYMENT_MODEL.Decentralized ?
          ROLE_CAN_UPDATE_FIELD.txtMoTaLyDoChiTiet_Decentrelize :
          ROLE_CAN_UPDATE_FIELD.txtMoTaLyDoChiTiet_Centrelize;
        if ($isHasCommonElement(this.infoUser.roleId, roleCanUpdateMoTaLyDo)) {
          this.form.txtMoTaLyDoChiTiet.setEnabled(true);
        }
      }
      this.form.cbHoSo.setEnabled(true);
      this.form.cbNoChungTu.setEnabled(true);
      this.form.lbKiemTraPCRT.setEnabled(true);
      this.form.attachButton.setEnabled(true);
    };
    const contentForKQ = [
      [
        $createLabel("Kiểm tra PCRT", { right: "5px" }),
        this.form.lbKiemTraPCRT
      ],
      [
        $createLabel("Kết quả kiểm tra:", { right: "5px" }),
        this.form.lbKetQuaKiemTra
      ]
    ];
    this.flxKQKT = $createFlexContainer(flxContainer, {
      height: this.generalHeight * 2 + "px",
      top: $getElementTop(this.flxLabelThongTinKiemTra)
    });
    $createTable(this.flxKQKT, contentForKQ, {
      oddColumnWidth: "20%",
      evenColumnWidth: "80%"
    });
    this.form.txtMoTaLyDoChiTiet = $createTextArea({ width: "92.5%" });
    this.form.lblMoTaChiTietLyDo = $createLabel(`Mô tả lý do chi tiết:`, {
      right: "5px"
    });
    const labelND = $createLabel(`(Nội dung phản hồi cho KH)`, {
      right: "5px",
      skin: "skinRedLabel"
    });
    const containerLabelND = $createFlexContainer();
    const containerForLblMoTa = $createFlexContainer(containerLabelND, {
      width: "100%",
      height: "50%",
      top: "15%"
    });
    containerForLblMoTa.add(this.form.lblMoTaChiTietLyDo);
    const containerForND = $createFlexContainer(containerLabelND, {
      width: "100%",
      height: "50%",
      top: "40%"
    });
    containerForND.add(labelND);
    containerLabelND.add(containerForLblMoTa);
    containerLabelND.add(containerForND);
    const contentForMoTaChiTiet = [
      [containerLabelND, this.form.txtMoTaLyDoChiTiet]
    ];
    this.flxColMoTaLyDoChiTiet = $createFlexContainer(flxContainer, {
      height: this.generalHeight * 2 + "px",
      top: $getElementTop(this.flxKQKT)
    });
    $createTable(this.flxColMoTaLyDoChiTiet, contentForMoTaChiTiet, {
      oddColumnWidth: "20%",
      evenColumnWidth: "80%",
      rowHeight: this.generalHeight * 2 + "px"
    });
    //Tạo UI cho phản hồi
    this.flxPhanHoi = $createFlexContainer(flxContainer, {
      height: this.generalHeight * 4 + "px",
      top: $getElementTop(this.flxColMoTaLyDoChiTiet)
    });
    this.form.txtPhanHoiCuaDVKD = $createTextArea({ width: "92.5%" });
    this.form.txtPhanHoiCuaTTTTQT = $createTextArea({ width: "92.5%" });
    const contentForPhanHoi = [
      [
        $createLabel("Ghi chú của ĐVKD (nếu có):", {
          right: "5px"
        }),
        this.form.txtPhanHoiCuaDVKD
      ],
      [
        $createLabel("Phản hồi của TT TTQT:", {
          right: "5px"
        }),
        this.form.txtPhanHoiCuaTTTTQT
      ]
    ];
    $createTable(this.flxPhanHoi, contentForPhanHoi, {
      oddColumnWidth: "20%",
      evenColumnWidth: "80%",
      rowHeight: this.generalHeight * 2 + "px"
    });
    //buttons
    this.flxButtons = $createFlexContainer(flxContainer, {
      height: this.generalHeight + "px",
      top: $getElementTop(this.flxPhanHoi)
    });
    //Khoảng trống hai dòng
    this.flxSpace = $createFlexContainer(flxContainer, {
      height: this.generalHeight * 2 + "px",
      top: $getElementTop(this.flxButtons)
    });
  },
  createGeneralInformation(flxContainer, uiSaver) {
    flxContainer.removeAll();
    const flxGeneralInformation = $createFlexContainer(flxContainer, {
      height: this.generalHeight * 2 + "px",
      top: "0"
    });
    uiSaver.txtMaHoSo = $createLabel("Mã hồ sơ: ");
    uiSaver.txtTrangThai = $createLabel("Trạng thái: ");
    uiSaver.txtMaGiaoDich = $createLabel("Mã giao dịch: ");
    uiSaver.txtThoiDiemHetHan = $createLabel("Thời điểm hết hạn: ");
    uiSaver.txtThoiGianKhoiTaoYeuCau = $createLabel(
      "Thời gian bắt đầu xử lý: "
    );
    uiSaver.txtMaGiaoDichFX = $createLabel("Mã giao dịch FX: ");
    const contentForFlxGeneralInfo = [
      [uiSaver.txtMaHoSo, uiSaver.txtTrangThai, uiSaver.txtThoiDiemHetHan],
      [
        uiSaver.txtMaGiaoDich,
        uiSaver.txtMaGiaoDichFX,
        uiSaver.txtThoiGianKhoiTaoYeuCau
      ]
    ];
    return $createTable(flxGeneralInformation, contentForFlxGeneralInfo);
  },
  reRenderUIThongTinGiaoDich() {
    this.flxLabelThongTinNguoiChuyenTien.top = $getElementTop(this.flxThongTinGiaoDich);
    this.flxThongTinNguoiChuyen.top = $getElementTop(this.flxLabelThongTinNguoiChuyenTien);
    this.reRenderUIThongTinNguoiChuyenTien();
  },
  reRenderUIThongTinNguoiChuyenTien() {
    this.flxLabelThongTinNguoiThuHuong.top = $getElementTop(this.flxThongTinNguoiChuyen);
    this.flxThongTinNguoiThuHuong.top = $getElementTop(this.flxLabelThongTinNguoiThuHuong);
    this.flxLabelThongTinNganHangThuHuong.top = $getElementTop(this.flxThongTinNguoiThuHuong);
    this.flxThongTinNganHangThuHuong.top = $getElementTop(this.flxLabelThongTinNganHangThuHuong);
    this.reRenderThongTinChuyenTienUI();
  },
  reRenderUIThongTinNguoiThuHuong() {
    this.flxLabelThongTinNganHangThuHuong.top = $getElementTop(this.flxThongTinNguoiThuHuong);
    this.flxThongTinNganHangThuHuong.top = $getElementTop(this.flxLabelThongTinNganHangThuHuong);
    this.reRenderThongTinChuyenTienUI();
  },
  reRenderThongTinChuyenTienUI() {
    this.flxLabelThongTinKiemTra.top = $getElementTop(
      this.flxThongTinNganHangThuHuong
    );
    this.flxKQKT.top = $getElementTop(this.flxLabelThongTinKiemTra);
    this.flxColMoTaLyDoChiTiet.top = $getElementTop(this.flxKQKT);
    this.flxPhanHoi.top = $getElementTop(this.flxColMoTaLyDoChiTiet);
    this.flxButtons.top = $getElementTop(this.flxPhanHoi);
    this.flxSpace.top = $getElementTop(this.flxButtons);
    this.view.forceLayout();
  },
  checkDuplicateFiles(newFiles) {
    const duplicateFiles = [];
    for (let i = 0; i < newFiles.length; i++) {
      const newFile = newFiles[i];
      const isDuplicate = this.attachFiles.some(
        (file) => file.name === newFile.name && file.size === newFile.size
      );
      if (isDuplicate) {
        duplicateFiles.push(newFile.name);
      }
    }
    return duplicateFiles;
  },
  createApprovalStep(body) {
    this.presenter.createApprovalStep(body);
  },
  createButtonForForm() {
    var self = this;
    this.flxButtons.removeAll();
    this.roleCanUpdate = [];
    this.buttons = {};
    this.buttons.btnHuy = $createButton(
      "Đóng",
      () => {
        this.backToListPage();
      },
    );
    const contentForflxButtons = [];
    const buttons = [];
    buttons.push(this.buttons.btnHuy);
    this.buttons.btnDuyet = {};
    const levels = this.responseData.approvalLevelMap || [];
    const avaiableLevels = levels.map((level) => level.avaiableLevel);
    const isExpired = this.detailData.status === FUND_TRANSFER_STATUS.Expired;
    if (this.detailData.assigne === this.infoUser.id.toString() && !isExpired) {
      const levelDuyet = 0;
      const levelTuChoi = -1;
      const isDisabledBtnChuyenCap =
        avaiableLevels.includes(levelTuChoi) &&
        this.form.lbKetQuaKiemTra.selectedKey !== CHECK_RESULT.ValidRecords;
      if (levels.length > 0) {
        levels.forEach((level) => {
          if (this.infoUser.roleId.includes(level.roleId)) {
            if (!this.roleCanUpdate.includes(level.roleId))
              this.roleCanUpdate.push(level.roleId);
            if (level.avaiableLevel === levelDuyet) {
              this.buttons.btnDuyet = $createButton(
                level.displayText,
                () => {
                  if (
                    this.form.lbKetQuaKiemTra.selectedKey ===
                    CHECK_RESULT.ValidRecords
                  ) {
                    this.validateChannel(
                      this.detailUI.lbKenhGiaoDich.selectedKey,
                      () => {
                        this.finalApproval(
                          FUND_TRANSFER_STATUS.Accepted,
                          APPROVAL_LEVEL_STATUS.Resolved
                        );
                      }
                    );
                  } else if (
                    this.form.lbKetQuaKiemTra.selectedKey ===
                    CHECK_RESULT.RejectedRecords
                  ) {
                    this.validateChannel(
                      this.detailUI.lbKenhGiaoDich.selectedKey,
                      () => {
                        this.finalApproval(
                          FUND_TRANSFER_STATUS.Rejected,
                          APPROVAL_LEVEL_STATUS.Rejected
                        );
                      }
                    );
                  } else if (
                    this.form.lbKetQuaKiemTra.selectedKey ===
                    CHECK_RESULT.SupplementalRecords
                  ) {
                    this.validateChannel(
                      this.detailUI.lbKenhGiaoDich.selectedKey,
                      () => {
                        this.finalApproval(
                          FUND_TRANSFER_STATUS.OnHold,
                          APPROVAL_LEVEL_STATUS.Rejected
                        );
                      }
                    );
                  }
                },
              );
            } else if (
              level.avaiableLevel === levelTuChoi &&
              this.form.lbKetQuaKiemTra.selectedKey !==
              CHECK_RESULT.ValidRecords
            ) {
              this.buttons.btnDuyet = $createButton(
                level.displayText,
                () => {
                  if (
                    this.form.lbKetQuaKiemTra.selectedKey ===
                    CHECK_RESULT.RejectedRecords
                  ) {
                    this.validateChannel(
                      this.detailUI.lbKenhGiaoDich.selectedKey,
                      () => {
                        this.finalApproval(
                          FUND_TRANSFER_STATUS.Rejected,
                          APPROVAL_LEVEL_STATUS.Rejected
                        );
                      }
                    );
                  } else if (
                    this.form.lbKetQuaKiemTra.selectedKey ===
                    CHECK_RESULT.SupplementalRecords
                  ) {
                    this.validateChannel(
                      this.detailUI.lbKenhGiaoDich.selectedKey,
                      () => {
                        this.finalApproval(
                          FUND_TRANSFER_STATUS.OnHold,
                          APPROVAL_LEVEL_STATUS.Rejected
                        );
                      }
                    );
                  }
                },
              );
            } else if (
              level.avaiableLevel !== levelDuyet &&
              level.avaiableLevel !== levelTuChoi
            ) {
              if (isDisabledBtnChuyenCap) {
                if (level.avaiableLevel < this.detailData.approvalLevel) {
                  const button = $createButton(
                    level.displayText,
                    () => {
                      this.levelPhanHoi = level.avaiableLevel;
                      self.preLevel(
                        level.avaiableLevel,
                        level.lastAssignee || ""
                      );
                    },
                  );
                  buttons.push(button);
                  this.buttons[button.id] = button;
                }
              } else {
                const func =
                  level.avaiableLevel < this.detailData.approvalLevel
                    ? () => {
                      this.levelPhanHoi = level.avaiableLevel;
                      self.preLevel(
                        level.avaiableLevel,
                        level.lastAssignee || ""
                      );
                    }
                    : () => {
                      self.level = level.avaiableLevel;
                      const channelSelected = self.detailUI.lbKenhGiaoDich.selectedKey;
                      const diaChiNguoiHuong = [];
                      self.diaChiNguoiHuongTextBoxs.forEach((key) => {
                        if (!$isNullOrEmpty($trim(key.text)))
                          diaChiNguoiHuong.push($trim(key.text));
                      });
                      const diaChiNH = diaChiNguoiHuong.join('');
                      const isOverLengthNostroDCNH = channelSelected === CHANNEL.Nostro && diaChiNH.length > 70;
                      const isOverLengthNiumDCNH = channelSelected !== CHANNEL.Nostro && diaChiNH.length > 200;
                      if (isOverLengthNostroDCNH || isOverLengthNiumDCNH) {
                        self.showErrorMessage("Vượt quá số lượng kí tự trường Địa chỉ người thụ hưởng.");
                        return;
                      }
                      const diaChiNganHangHuong = [];
                      self.nganHangThuHuongTextBoxs.forEach((key) => {
                        if (!$isNullOrEmpty($trim(key.text)))
                          diaChiNganHangHuong.push($trim(key.text));
                      });
                      if ([CHANNEL.Nostro, CHANNEL.NiumSwift].includes(channelSelected) && $isNullOrEmpty(self.detailUI.txtSwiftCodeNganHangThuHuong)) {
                        self.showErrorMessage("Không được để trống trường Mã Swift.");
                        return;
                      }
                      const isRequiredBSB = channelSelected === CHANNEL.Nostro &&
                        self.detailData.foreinCurrency === "AUD" &&
                        self.detailData.countryCode === "AU" &&
                        $isNullOrEmpty(self.detailUI.txtBSBorRouting.text);
                      if (isRequiredBSB) {
                        self.showErrorMessage("Không được để trống trường " + self.detailUI.lblBSBorRouting.text);
                        return;
                      }
                      if (self.detailData.channelCode === CHANNEL.NiumLocal &&
                        channelSelected === CHANNEL.Nostro &&
                        ["AUD", "GBP"].includes(self.detailData.foreinCurrency) &&
                        $isNullOrEmpty(self.detailUI.txtSwiftCodeNganHangThuHuong.text) &&
                        $isNullOrEmpty(diaChiNganHangHuong.join(""))
                      ) {
                        self.showErrorMessage("Không được để trống cả Mã swift và Địa chỉ ngân hàng hưởng.");
                        return;
                      }
                      const required = channelSelected === CHANNEL.Nostro ||
                        self.detailData.foreinCurrency === "AUD" ||
                        (channelSelected === CHANNEL.NiumSwift && self.detailData.foreinCurrency === "GBP") ||
                        (channelSelected === CHANNEL.NiumLocal && self.detailData.foreinCurrency === "USD") ||
                        (channelSelected === CHANNEL.NiumLocal && self.detailData.foreinCurrency === "SGD") ||
                        self.detailData.foreinCurrency === "CAD" ||
                        (channelSelected === CHANNEL.NiumLocal && self.detailData.foreinCurrency === "JPY");
                      if (required && $isNullOrEmpty(diaChiNguoiHuong)) {
                        self.showErrorMessage("Không được để trống trường địa chỉ người hưởng.");
                        return;
                      }
                      //Nếu là đồng JPY thì hiển thị popup comfirn
                      if (channelSelected === CHANNEL.Nostro && self.detailData.foreinCurrency === "JPY") {
                        self.showPopup(
                          `Bạn có chắc chắn chọn tài khoản Nostro/Đối tác: ${self.form.txtTaiKhoanNostro.text} - ${self.form.lblTenNostro.toolTip}`,
                          () => {
                            self.validateChannel(
                              self.detailUI.lbKenhGiaoDich.selectedKey,
                              () => {
                                self.nextLevel(
                                  level.avaiableLevel,
                                  level.lastAssignee || ""
                                );
                              }
                            );
                          },
                          () => { },
                        );
                      } else {
                        self.validateChannel(
                          self.detailUI.lbKenhGiaoDich.selectedKey,
                          () => {
                            self.nextLevel(
                              level.avaiableLevel,
                              level.lastAssignee || ""
                            );
                          }
                        );
                      }
                    };
                const button = $createButton(level.displayText, func);
                buttons.push(button);
                this.buttons[button.id] = button;
              }
            }
          }
        });
      }
      if (!$isEmptyObject(this.buttons.btnDuyet)) {
        buttons.push(this.buttons.btnDuyet);
      }
    }
    if (
      STATUS_ADD_DOCUMENT.includes(this.detailData.status) &&
      !this.infoUser.roleId.includes(ROLE.ADMIN) && !this.infoUser.roleId.includes(ROLE.VIEW)
    ) {
      this.buttons.btnBoSung = $createButton(
        "Lưu hồ sơ",
        () => {
          self.addDocument();
        },
      );
      if (!$isEmptyObject(this.buttons.btnBoSung)) {
        buttons.push(this.buttons.btnBoSung);
      }
    }
    contentForflxButtons.push(buttons);
    $createTable(this.flxButtons, contentForflxButtons);
    if (isExpired) {
      this.showWarningMessage(
        "Hồ sơ đã quá thời hạn bổ sung! Quý khách vui lòng tạo hồ sơ mới để thực hiện giao dịch."
      );
      return;
    }
    if ($isNullOrEmpty(this.detailData.assigne)) {
      this.showWarningMessage(
        "Để thực hiện các thao tác với hồ sơ này, vui lòng gán hồ sơ về mình hoặc cho người khác."
      );
      return;
    }
    if (this.detailUI.lbKenhGiaoDich.selectedKey.includes("NIUM") && !$isNullOrEmpty(this.detailData.swiftCode) && this.detailData.beneficiaryCountryCode !== this.detailData.countryCode) {
      this.showWarningMessage(
        "Giá trị Quốc gia (theo ngân hàng) đang khác giá trị Quốc gia người thụ hưởng."
      );
      return;
    }
  },
  addDocument() {
    if (this.attachFiles.length === 0) {
      this.showErrorMessage("Vui lòng chọn file để bổ sung.");
      return;
    }
    this.files = [...this.attachFiles].map((file) => ({
      name: $getFileName(file.name),
      type: $getFileExtension(file.name)
    }));
    $showLoading(this.view);
    this.uploadDocumentsToS3();
  },
  logChangeAdditionalData() {
    const body = {
      action: this.action,
      data: this.changeAdditionalData,
      additionalDataId: this.responseData.fundTransferAdditional
        ? this.responseData.fundTransferAdditional.id
        : null,
      pvbFundTransferId: this.detailData.id
    };
    if (this.dataForLogAssign.fundTransferId) {
      body.pvbFundTransferId = this.dataForLogAssign.fundTransferId;
      body.additionalDataId = null;
    }
    this.createApprovalStep(body);
  },
  setEnabledForUserTable(isEnable) {
    this.tenKhachHangTextBoxs.forEach((key) => {
      key.setEnabled(isEnable);
    });
    this.form.btnAddTenKhachHang.setEnabled(isEnable);
    this.form.btnDeleteTenKhachHang.setEnabled(isEnable);
    this.form.btnAddDiaChiNguoiChuyen.setEnabled(isEnable);
    this.form.btnDeleteDiaChiNguoiChuyen.setEnabled(isEnable);
    this.form.btnAddDiaChiNguoiHuong.setEnabled(isEnable);
    this.form.btnDeleteDiaChiNguoiHuong.setEnabled(isEnable);
    this.form.btnAddNoiDungChuyenTien.setEnabled(isEnable);
    this.form.btnDeleteNoiDungChuyenTien.setEnabled(isEnable);
    this.diaChiNguoiHuongTextBoxs.forEach((key) => {
      key.setEnabled(isEnable);
    });
    this.nganHangThuHuongTextBoxs.forEach((key) => {
      key.setEnabled(isEnable);
    });
    this.form.btnAddDiaChiNganHangHuong.setEnabled(isEnable);
    this.form.btnDeleteDiaChiNganHangHuong.setEnabled(isEnable);
    this.diaChiNguoiChuyenTextBoxs.forEach((key) => {
      key.setEnabled(isEnable);
    });
    this.detailUI.txtBSBorRouting.setEnabled(isEnable);
    this.detailUI.txtTenNganHangThuHuong.setEnabled(isEnable && this.detailData.manualSwiftCode);
    this.noiDungChuyenTienTextBoxs.forEach((key) => {
      key.setEnabled(isEnable);
    });
    this.detailUI.lbCountry.setEnabled(isEnable);
    this.detailUI.lbPhanLoaiKhachHang.setEnabled(isEnable);
    if (isEnable && this.infoUser.roleId.includes(ROLE.CVTTQT))
      this.detailUI.lbKenhGiaoDich.setEnabled(true);
    else this.detailUI.lbKenhGiaoDich.setEnabled(false);
  },
  setEnabledWhenIsUpdateLevel(isEnable) {
    //Thông tin
    this.setEnabledForUserTable(isEnable);
    //form
    const element = [
      "cbHoSo",
      "cbNoChungTu",
      "tbSenderToReceiverInfor",
      "btnAdd",
      "btnDelete",
      "btnAddF77B",
      "btnDeleteF77B",
      "tbRegulatoryReporting",
      "attachButton",
      "lbKiemTraPCRT",
      "txtTaiKhoanNostro"
    ];
    element.forEach((key) => {
      this.form[key].setEnabled(isEnable);
    });
    this.senderToReceiverInfoTextBoxs.forEach((key) => {
      key.setEnabled(isEnable);
    });
    this.f77bTextBoxs.forEach((key) => {
      key.setEnabled(isEnable);
    });
    this.form.txtPhanHoiCuaDVKD.setEnabled(false);
    this.form.txtPhanHoiCuaTTTTQT.setEnabled(false);
    if (this.form.lbKetQuaKiemTra.selectedKey === CHECK_RESULT.ValidRecords) {
      this.form.txtMoTaLyDoChiTiet.setEnabled(false);
    }
    const roleCanUpdateKetQuaKiemTra = this.paymentModel === PAYMENT_MODEL.Decentralized ?
      ROLE_CAN_UPDATE_FIELD.lbKetQuaKiemTra_Decentrelize :
      ROLE_CAN_UPDATE_FIELD.lbKetQuaKiemTra_Centrelize;
    if (
      $isHasCommonElement(
        this.infoUser.roleId,
        roleCanUpdateKetQuaKiemTra
      ) &&
      isEnable
    ) {
      this.form.lbKetQuaKiemTra.setEnabled(true);
    } else {
      this.form.lbKetQuaKiemTra.setEnabled(false);
    }
  },
  updateFundTransfer(payload, action) {
    const body = { ...payload };
    $showLoading(this.view);
    this.presenter.updateFundTransfer(body, false, action);
  },
  createFundTransferDocument(s3path) {
    const body = {
      documentType: DOCUMENT_TYPE.StaffUpload,
      fileName: $getFileName(this.fileUploadToS3.name),
      fileSize: this.fileUploadToS3.size,
      mimeType: $getFileExtension(this.fileUploadToS3.name),
      s3Path: s3path,
      pvbFundTransferId: this.detailData.id,
      pvbDocumentId: null
    };
    this.presenter.createFundTransferDocument(body);
  },
  setEnabledToFormBoSung(isEnable = true) {
    const element = [
      "cbHoSo",
      "cbNoChungTu",
      "tbSenderToReceiverInfor",
      "btnDelete",
      "btnAdd",
      "btnDeleteF77B",
      "btnAddF77B",
      "tbRegulatoryReporting",
      "attachButton",
      "lbKiemTraPCRT",
      "txtTaiKhoanNostro"
    ];
    element.forEach((key) => {
      this.form[key].setEnabled(isEnable);
    });
    if (
      $isHasCommonElement(
        ROLE_CAN_UPDATE_FIELD.txtPhanHoiCuaDVKD,
        this.infoUser.roleId
      )
    ) {
      this.form.txtPhanHoiCuaDVKD.setEnabled(true);
    } else {
      this.form.txtPhanHoiCuaDVKD.setEnabled(false);
    }
    if (
      $isHasCommonElement(
        ROLE_CAN_UPDATE_FIELD.txtPhanHoiCuaTTTTQT,
        this.infoUser.roleId
      )
    ) {
      this.form.txtPhanHoiCuaTTTTQT.setEnabled(true);
    } else {
      this.form.txtPhanHoiCuaTTTTQT.setEnabled(false);
    }
    this.senderToReceiverInfoTextBoxs.forEach((key) => {
      key.setEnabled(isEnable);
    });
    this.f77bTextBoxs.forEach((key) => {
      key.setEnabled(isEnable);
    });
  },
  getGroupDocuments(array) {
    if (array.length === 0) return array;
    return array.reduce((acc, item) => {
      const key = item.documentType === DOCUMENT_TYPE.CustomerUpload ? item.name : KEY_STAFF_UPLOAD;
      if (!acc.find(obj => obj.name === key)) {
        acc.push({
          name: key,
          items: [item],
        });
      } else {
        const existingObj = acc.find(obj => obj.name === key);
        existingObj.items.push(item);
      }
      return acc;
    }, []);
  },
  createCustomerDocuments(flxContainer) {
    flxContainer.removeAll();
    const self = this;
    const responseFundTransferDocs =
      self.responseData.fundTransferDocument || [];
    let documents = responseFundTransferDocs.map((doc) => ({
      ...doc,
      isSaveInDB: true
    }));
    if ([...this.attachFiles].length > 0)
      documents = [...documents, ...this.attachFiles];
    documents = this.getGroupDocuments(documents);
    let totalDocument = 0;
    for (let i = 0; i < documents.length; i++) {
      this.createOneBlockDocument(documents[i], flxContainer, totalDocument, self);
      if (documents[i].items.length > 0)
        totalDocument += documents[i].items.length;
      else totalDocument += 1;
    }
    flxContainer.height = totalDocument * this.generalHeight + "px";
    this.flxAttachButton.top = $getElementTop(this.flxCustomDocumentInformation);
  },
  createOneBlockDocument(document, flxContainer, index, self) {
    const name = document.name;
    const documents = document.items;
    const data = [];
    for (let i = 0; i < documents.length; i++) {
      const container = $createFlexContainer();
      const buttonWrapper = $createScrollFlexContainer();
      buttonWrapper.width = "90%";
      buttonWrapper.left = "0";
      container.add(buttonWrapper);
      let button = {};
      if (documents[i].isSaveInDB) {
        const nameButton =
          documents[i].documentType === DOCUMENT_TYPE.StaffUpload
            ? `${documents[i].fileName}.${documents[i].mimeType}`
            : documents[i].s3Path;
        button = $createButton(
          nameButton,
          (btn) => {
            if (!documents[i].s3Path) {
              self.showErrorMessage("Đường dẫn file không tồn tại.");
              return;
            }
            if (documents[i].documentType === DOCUMENT_TYPE.StaffUpload) {
              self.downloadFileFromS3(
                documents[i].s3Path,
                documents[i].fileName,
                documents[i].mimeType
              );
            } else if (
              documents[i].documentType === DOCUMENT_TYPE.CustomerUpload
            ) {
              const fileInfor = $parseFilePath(documents[i].s3Path);
              self.downloadFileFromS3(
                this.detailData.cifNumber,
                fileInfor.name,
                fileInfor.type
              );
            } else {
              self.showErrorMessage();
            }
          },
          {
            isLink: true,
            toolTip: nameButton,
            centerX: null,
            maxWidth: null,
            minWidth: null,
            width: "100%",
          }
        );
      } else {
        const nameButton =
          documents[i].documentType === DOCUMENT_TYPE.StaffUpload
            ? `${documents[i].fileName}.${documents[i].mimeType}`
            : documents[i].name;
        button = $createButton(
          nameButton,
          (btn) => {
            const file = documents[i];
            const url = URL.createObjectURL(file);
            const a = document.createElement("a");
            a.href = url;
            a.download = file.name;
            a.style.display = "none";
            document.body.appendChild(a);
            a.click();
            // Sau khi tải xuống, giải phóng blob URL
            URL.revokeObjectURL(url);
            document.body.removeChild(a);
          },
          {
            isLink: true,
            toolTip: nameButton,
            centerX: null,
            maxWidth: null,
            minWidth: null,
            width: "100%",
          }
        );
      }
      buttonWrapper.add(button);
      const btnX = $createLabel("X", {
        left: "93%",
        width: "7%",
        skin: "Xlabel"
      });
      btnX.onClick = () => {
        this.attachFiles = [...this.attachFiles].filter(
          (file) => file.name !== documents[i].name
        );
        this.createCustomerDocuments(this.flxCustomDocumentInformation);
      };
      if (!documents[i].isSaveInDB) container.add(btnX);
      const nguoiTai = documents[i].createdby;
      const ngayTaiLen = $convertToHmsDDMMYYYY(
        documents[i].createdts
      );
      data.push({
        tenHoSo: container,
        nguoiTai: $createLabel(nguoiTai, { toolTip: nguoiTai }),
        ngayTaiLen: $createLabel(ngayTaiLen, { toolTip: ngayTaiLen })
      });
    }
    const flxOneBlock = $createFlexContainer(flxContainer, {
      height: this.generalHeight * data.length + "px",
      top: (index * this.generalHeight) + "px"
    });
    $createListTable(
      flxOneBlock,
      data,
      {
        title: name,
        skin: "rowTitleRight",
        lengthLimit: 50,
        toolTip: name,
        width: "30%",
      },
      {
        customColumnsWidth: ["65%", "15%", "20%"],
        skin: "rowTitleRight",
      }
    );
  },
  setCSSstyle() {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach(function (checkbox) {
      checkbox.style.height = "20px";
      checkbox.style.width = "20px";
    });
  },
  uploadDocumentsToS3() {
    const file = this.files.shift();
    if (file) {
      const body = {
        cif: `${this.detailData.cifNumber}/${this.detailData.transferCode}`,
        file: [file]
      };
      this.presenter.uploadDocumentsToS3(body);
    }
  },
  downloadFileFromS3(path, name, type) {
    const body = {
      path,
      file: [
        {
          name,
          type
        }
      ]
    };
    this.presenter.downloadFileFromS3(body);
  },
  uploadFile(url, file) {
    const self = this;
    var xhr = new XMLHttpRequest();
    xhr.open("PUT", url, true);
    xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          self.changeAdditionalData = [];
          self.action = ACTION_STEP_NAME.taiLenHoSo;
          self.changeAdditionalData.push({
            field: "attachFiles",
            oldValue: "",
            newValue: file.name
          });
          const s3PathToSave = `${self.detailData.cifNumber}/${self.detailData.transferCode}`;
          self.createFundTransferDocument(s3PathToSave);
          self.logChangeAdditionalData();
        } else {
          $hideLoading(self.view);
          self.showErrorMessage("Error uploading the document");
        }
      }
    };
    xhr.setRequestHeader("Content-Type", file.type);
    xhr.send(file);
  },
  downloadFile(url) {
    try {
      const link = document.createElement("a");
      link.href = url;
      link.download = ""; // Để trống tên file để tải về với tên mặc định
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return true;
    } catch (error) {
      return false;
    }
  },
  getListNostro() {
    const notrosCategory = "5003 ; 5001";
    this.presenter.getNostros({ category: notrosCategory });
  },
  //==== form list =====
  creatHeader() {
    const flxMainContainer = new kony.ui.FlexScrollContainer({
      id: "flxMainHeaderTH",
      isVisible: true,
      width: "100%",
      height: "100%",
      top: "0",
      left: "0"
    });
    this.dataHeader.map((item, index) => {
      var width = (index * 100) / this.dataHeader.length;
      var column = new kony.ui.FlexContainer({
        isVisible: true,
        width:
          (index === this.dataHeader.length - 2
            ? 11.25
            : 100 / this.dataHeader.length) + "%",
        height: "55px",
        top: "0",
        skin: "boxLabel_style"
      });
      var label = new kony.ui.Label({
        text: item,
        width: "100%",
        height: "100%",
        skin: "recordManager__headerLabel"
      });
      column.add(label);
      flxMainContainer.add(column);
    });
    this.view.flxHeader.add(flxMainContainer);
  },
  setCustomersSegmentData(recordListKSV) {
    var self = this;
    const response = recordListKSV ? recordListKSV : this.recordList;
    //render trạng thái enable của select user assign
    const checkEnableSelect = (itemCurrent, approvalLevel) => {
      if (
        approvalLevel !== LIST_STATUS_APPROVAL.Gdv &&
        approvalLevel !== LIST_STATUS_APPROVAL.Ksv &&
        approvalLevel !== LIST_STATUS_APPROVAL.Cvttqt &&
        approvalLevel !== LIST_STATUS_APPROVAL.C1 &&
        approvalLevel !== LIST_STATUS_APPROVAL.Lddv &&
        approvalLevel !== LIST_STATUS_APPROVAL.C2 &&
        itemCurrent.assigne !== undefined
      ) {
        return false;
      } else if (
        (approvalLevel === LIST_STATUS_APPROVAL.Gdv &&
          (self.infoUser.roleId.includes(ROLE.KSV) || self.infoUser.roleId.includes(ROLE.LDDV))) ||
        (approvalLevel === LIST_STATUS_APPROVAL.Ksv &&
          self.infoUser.roleId.includes(ROLE.KSV)) ||
        (approvalLevel === LIST_STATUS_APPROVAL.Cvttqt &&
          self.infoUser.roleId.includes(ROLE.CVTTQT)) ||
        (approvalLevel === LIST_STATUS_APPROVAL.C1 &&
          self.infoUser.roleId.includes(ROLE.C1)) ||
        (approvalLevel === LIST_STATUS_APPROVAL.Lddv &&
          self.infoUser.roleId.includes(ROLE.LDDV)) ||
        (approvalLevel === LIST_STATUS_APPROVAL.C2 &&
          self.infoUser.roleId.includes(ROLE.C2))
      ) {
        return true;
      }
    };
    //render tên trạng thái phê duyệt
    const renderApprovalName = (curentItem) => {
      const checkStatusApprovalName = (approval) => {
        switch (approval) {
          case "Chờ GDV Cập nhật hồ sơ":
            return LIST_STATUS_APPROVAL.Gdv;
          case "Chờ KSV kiểm soát":
            return LIST_STATUS_APPROVAL.Ksv;
          case "Chờ duyệt cấp 1":
            return LIST_STATUS_APPROVAL.C1;
          case "Chờ GĐV duyệt" || "Chờ PD của LĐ chi nhánh":
            return LIST_STATUS_APPROVAL.Lddv;
          case "Đã duyệt":
            return "Đã duyệt";
          case "Chờ CV TT TTQT kiểm tra" ||
            "Chờ CV TT TTQT phê duyệt " ||
            "Chờ CV TT TTQT phê duyệt":
            return LIST_STATUS_APPROVAL.Cvttqt;
          case "Chờ duyệt cấp 2":
            return LIST_STATUS_APPROVAL.C2;
        }
      };

      let approvalLevelName = "-";
      const dataApprovalLevel = self.approvalLevelsList.filter(
        (item) => item.approvalLevel === curentItem.approvalLevel
      );
      const checkApprovalLevel = self.getApprovalStatus(curentItem);
      if (dataApprovalLevel.length) {
        approvalLevelName = checkApprovalLevel
          ? checkStatusApprovalName(dataApprovalLevel[0].approvalName.trim())
          : checkStatusApprovalName(
            dataApprovalLevel[0].approvalNameCenterlized.trim()
          );
      }
      return approvalLevelName;
    };
    //render danh sách user có thể assign
    const renderListUserAssign = (approvalLevelName, curentItem) => {
      const listUserAssign = (roleId, filterBranch = false) => {
        const dataList = self.listAllUser
          .filter((item) => {
            const listBranchCode = item.branchCode.split(",");
            return (
              (filterBranch
                ? listBranchCode.includes(curentItem.branchCode)
                : true) && item.roleId === roleId
            );
          })
          .map((item, index) => [
            item.id,
            `${$getFullName(item.firstName, item.lastName)}`
          ]);
        return dataList;
      };
      const renderListUser = (dataRoleId, filterBranchCode = false) => {
        const listRoleId = self.infoUser.roleId;
        const listRoleIdSlice = listRoleId.slice(1);
        const duplicateRoleId =
          listRoleId.length > 1 ? listRoleIdSlice : listRoleId;
        const checkMultiUser = duplicateRoleId.filter(
          (item) => item === dataRoleId
        );
        if (listRoleId.length > 1 && checkMultiUser.length) {
          //trường hợp hồ sơ là c1 được assign cho c2 được view bởi account c2
          return [
            ...listUserAssign(dataRoleId, filterBranchCode),
            [
              self.infoUser.id,
              `${$getFullName(self.infoUser.firstName, self.infoUser.lastName)}`
            ]
          ];
        } else if (
          curentItem.assigne &&
          dataRoleId === ROLE.C1 &&
          !listUserAssign(dataRoleId, filterBranchCode).filter(
            (item) => item[0] == curentItem.assigne
          ).length
        ) {
          //trường hợp hồ sơ là C1 được assign cho C2 được view bởi account c1
          const userAssign = self.listAllUser.filter(
            (item) => item.id == curentItem.assigne
          )[0];
          return [
            ...listUserAssign(dataRoleId, filterBranchCode),
            [
              userAssign.id,
              `${(
                (userAssign.lastName || "") +
                " " +
                (userAssign.firstName || "")
              ).trim()}`
            ]
          ];
        } else {
          return listUserAssign(dataRoleId, filterBranchCode);
        }
      };
      switch (approvalLevelName) {
        case LIST_STATUS_APPROVAL.Gdv:
          return renderListUser(ROLE.GDV, true);
        case LIST_STATUS_APPROVAL.Ksv:
          return renderListUser(ROLE.KSV, true);
        case LIST_STATUS_APPROVAL.Lddv:
          return renderListUser(ROLE.LDDV, true);
        case LIST_STATUS_APPROVAL.Cvttqt:
          return renderListUser(ROLE.CVTTQT);
        case LIST_STATUS_APPROVAL.C1:
          return renderListUser(ROLE.C1);
        case LIST_STATUS_APPROVAL.C2:
          return renderListUser(ROLE.C2);
      }
      return ["", ""];
    };

    //render email của người được gán
    const renderEmail = (userId) => {
      const data = self.listAllUser.filter(
        (item) => item.id === parseInt(userId)
      );
      return data.length ? data[0].email : "";
    };
    if (response.length > 0) {
      var dataMap = {
        label0: "label0",
        label1: "label1",
        label2: "label2",
        label3: "label3",
        label4: "label4",
        label5: "label5",
        label6: "label6",
        label17: "label17",
        label7: "label7",
        label8: "label8",
        label16: "label16",
        label10: "label10",
        label11: "label11",
        label12: "label12",
        label13: "label13",
        label14: "label14",
        userSelect: "userSelect",
        icon15: "icon15"
      };
      var data = [];
      if (typeof response !== "undefined") {
        data = response.map(function (row, index) {
          //render tên chi nhánh và ĐVKD
          const renderBranchCompany = (currentItem) => {
            if (currentItem) {
              const getBranchCompany = self.listBranchCompany.length
                ? self.listBranchCompany.filter(
                  (item) =>
                    currentItem.branchCode === item.branchCode &&
                    item.leadCompany
                )
                : [];
              const currentBranchCompany = getBranchCompany.length
                ? self.listBranchCompany.filter(
                  (item) =>
                    item.branchCode === getBranchCompany[0].leadCompany
                )
                : [];
              return currentBranchCompany || "-";
            }
            return "-";
          };

          //render trạng thái hồ sơ
          const checkStatus = (status) => {
            const convertStatusExpired =
              status === FUND_TRANSFER_STATUS.Expired
                ? FUND_TRANSFER_STATUS.Closed
                : status;
            const data = STATUS_RECORD.filter(
              (item) => item[0] === convertStatusExpired
            );
            return data.length ? data[0][1] : "-";
          };
          //xử lý thêm data export hồ sơ
          self.listDataRecordsFilter = self.recordListExport.map(
            (item, indexChild) => {
              const fx = item.fx ? item.fx.split(",") : [];
              return [
                indexChild + 1 || "-",
                (renderBranchCompany(item).length &&
                  renderBranchCompany(item)[0].branchName +
                  ` (${renderBranchCompany(item)[0].branchCode})`) ||
                "-",
                item.branchName + ` (${item.branchCode})` || "-",
                item.transferCode || "-",
                item.customerName || "-",
                item.cifNumber || "-",
                item.ft || "-",
                fx.length ? fx[0] : "-",
                fx.length > 1 ? fx[1] : "-",
                item.executionDate ? $convertToDDMMYYYY(item.executionDate) : "-",
                self.isHoSoCompleted(item.status) ? item.transferAmount : item.foreinAmount.toLocaleString() || "-",
                item.foreinCurrency || "-",
                $convertToHmsDDMMYYYY(item.createdts || "") || "-",
                item.channelCode || "-",
                checkStatus(item.status) || "-",
                renderApprovalName(item) || "-",
                "-" || "-"
              ]
            }
          );
          const checkUserExists = renderListUserAssign(
            renderApprovalName(row),
            row
          ).filter((item) => item[0] == row.assigne);
          return {
            label0: index + 1 || "-",
            label1:
              (renderBranchCompany(row).length &&
                renderBranchCompany(row)[0].branchName +
                ` (${renderBranchCompany(row)[0].branchCode})`) ||
              "-",
            label2: row.branchName + ` (${row.branchCode})` || "-",
            label3: row.transferCode || "-",
            label4: row.customerName || "-",
            label5: row.cifNumber || "-",
            label6: row.ft || "-",
            label17: row.fx || "-",
            label7: row.executionDate
              ? $convertToDDMMYYYY(row.executionDate)
              : "-",
            label8: self.isHoSoCompleted(row.status) ? row.transferAmount.toLocaleString() : row.foreinAmount.toLocaleString() || "-",
            label16: row.foreinCurrency || "-",
            label10: $convertToHmsDDMMYYYY(row.createdts || "") || "-",
            label11: row.channelCode || "-",
            label12: checkStatus(row.status) || "-",
            label13: renderApprovalName(row) || "-",
            label14: "-" || "-",
            userSelect: {
              masterData: [
                ["", "Hồ sơ chưa gán"],
                ...renderListUserAssign(renderApprovalName(row), row)
              ],
              skin: `userSelectRecord ${!row.assigne || (checkUserExists.length === 0 && row.assigne)
                ? "disableRed"
                : ""
                } userSelectRecord-onclick-${row.id}`,
              onSelection: (listBox) => {
                if (
                  row.assigne &&
                  renderApprovalName(row) === "Chờ GDV cập nhật" &&
                  checkUserExists.length
                ) {
                  const oldGdv = self.listAllUser.filter(
                    (item) => item.id === parseInt(row.assigne)
                  )[0];
                  const newGdv = self.listAllUser.filter(
                    (item) => item.id === parseInt(listBox.selectedkey)
                  )[0];
                  self.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = true;
                  self.view.CopylblPopUpMainMessage0g3eda8bde3854e.text = `Hồ sơ đã được gán cho GDV ${$getFullName(
                    oldGdv.firstName,
                    oldGdv.lastName
                  )}. Bạn có chắc chắn thực hiện gán lại cho GDV ${$getFullName(
                    newGdv.firstName,
                    newGdv.lastName
                  )}?`;
                  self.view.CopybtnPopUpSave0cabfb6db5c5347.text = "Đồng ý";
                  self.view.CopybtnPopUpSave0cabfb6db5c5347.onClick = () => {
                    self.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
                    self.view.CopylblPopUpMainMessage0g3eda8bde3854e.text =
                      "Cập nhật thủ công";
                    self.assignTo(
                      {
                        ...row,
                        assigne: listBox.selectedkey
                      },
                      renderEmail(listBox.selectedkey),
                      listBox.selectedkey && listBox.selectedkeyvalue[1],
                      row.assigne
                    );
                  };
                  self.view.CopybtnPopUpCancel0f3298c2214fe47.onClick = () => {
                    self.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
                    self.view.CopylblPopUpMainMessage0g3eda8bde3854e.text =
                      "Cập nhật thủ công";
                    self.handleSearchAllRecords();
                  };
                  self.view.CopyflxPopUpClose0b9f4641e1b4845.onClick = () => {
                    self.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
                    self.view.CopylblPopUpMainMessage0g3eda8bde3854e.text =
                      "Cập nhật thủ công";
                    self.handleSearchAllRecords();
                  };
                  self.view.forceLayout();
                } else {
                  self.assignTo(
                    {
                      ...row,
                      assigne: listBox.selectedkey
                    },
                    renderEmail(listBox.selectedkey),
                    listBox.selectedkey && listBox.selectedkeyvalue[1],
                    row.assigne
                  );
                }
              },
              enable:
                row.status !== FUND_TRANSFER_STATUS.Resolved &&
                row.status !== FUND_TRANSFER_STATUS.Rejected &&
                !self.infoUser.roleId.includes(ROLE.GDV) &&
                checkEnableSelect(row, renderApprovalName(row)),
              selectedKey: row.assigne
            },
            icon15: {
              onClick: () => {
                self.recordSelected.id = row.id;
                self.presenter.getDetail({
                  id: row.id
                });
                self.hideListView();
                $showLoading(self.view);
                self.view.Button0a8863fe63a4e45.isVisible = true;
              }
            }
          };
        });
      }
      this.view.Segment0fce7675ad5dc40.widgetDataMap = dataMap;
      this.view.Label0i1c757d4231a4d.isVisible = false;
      this.view.Segment0fce7675ad5dc40.isVisible = true;
      this.view.Segment0fce7675ad5dc40.setData(data);
    } else {
      this.view.Segment0fce7675ad5dc40.isVisible = false;
      this.view.Label0i1c757d4231a4d.isVisible = true;
    }
  },
  setStyleForList() {
    const customStyleLabel = document.querySelectorAll(
      "#frmDetailAndLog_flxMainHeaderTH .recordManager__headerLabel .recordManager__headerLabel"
    );
    const customLabelStyleRow = document.querySelectorAll(
      "#frmDetailAndLog_Segment0fce7675ad5dc40 .middlecenteralignrecordLabelRowImage"
    );
    customStyleLabel.forEach((item, index) => {
      item.style.borderRight =
        index + 1 === customStyleLabel.length ? "1px solid black" : "0";
    });
    customLabelStyleRow.forEach((item) => {
      item.style.position = "static";
      item.style.height = "100%";
    });
  },
  assignTo(record, email, assigneName, oldAssigne) {
    const self = this;
    this.changeAdditionalData = [];
    this.action = ACTION_STEP_NAME.ganHoSo;
    if (record.approvalLevel === 1 && this.infoUser.roleId.includes(ROLE.KSV)) {
      this.changeAdditionalData.push({
        field: "assignLog",
        oldValue: null,
        newValue: JSON.stringify({
          approvalLevel: 2,
          assigne: this.infoUser.id.toString()
        })
      });
    }
    this.changeAdditionalData.push({
      field: "assigne",
      oldValue: oldAssigne,
      newValue: record.assigne
    });
    this.dataForLogAssign.fundTransferId = record.id;
    this.dataForLogAssign.fundTransferAdditionalId = null;
    const bodyLogAssign = {
      action: this.action,
      data: this.changeAdditionalData,
      additionalDataId: null,
      pvbFundTransferId: record.id
    };
    assigneName &&
      this.presenter.assignFundTransfer({
        email: email,
        assigneName: assigneName,
        idRecord: record.id,
        assigneId: record.assigne,
        steps: bodyLogAssign
      });
  },
  getApprovalLevels() {
    this.presenter.getApprovalLevels({});
  },
  handleSearchAllRecords(approvalLevelFirst, paramCustom) {
    const self = this;
    $showLoading(this.view);
    let timeStart = this.view.Calendar0aaf27851c73640.formatteddate
      .split("/")
      .reverse()
      .join("-");
    let timeEnd = this.view.CopyCalendar0c4d712c5b9d741.formatteddate
      .split("/")
      .reverse()
      .join("-");

    function addOneDayToDate(dateString) {
      const dateArray = dateString.split("-");
      const dateObject = new Date(dateArray[0], dateArray[1] - 1, dateArray[2]);
      dateObject.setDate(dateObject.getDate() + 1);
      const newDate =
        dateObject.getFullYear() +
        "-" +
        (dateObject.getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        dateObject.getDate().toString().padStart(2, "0");
      return newDate;
    }
    const newDate = addOneDayToDate(timeEnd);

    if (timeStart === timeEnd) {
      var dateObject = new Date(timeEnd);
      dateObject.setDate(dateObject.getDate() + 1);
      timeEnd = dateObject.toISOString().slice(0, 10);
    } else {
      timeEnd = newDate;
    }
    const branchCode = this.view.CopyListBox0bcd39854d88847.selectedKey;
    const listDVKD = this.listBranchCodeCurrent;
    const checkBranchCode = () => {
      if (
        branchCode === FUND_TRANSFER_STATUS.All &&
        listDVKD.length &&
        (self.infoUser.roleId.includes(ROLE.CVTTQT) ||
          self.infoUser.roleId.includes(ROLE.C1) ||
          self.infoUser.roleId.includes(ROLE.C2) ||
          self.infoUser.roleId.includes(ROLE.ADMIN) || self.infoUser.roleId.includes(ROLE.VIEW))
      ) {
        return JSON.stringify(listDVKD) || "";
      } else {
        return branchCode && branchCode !== FUND_TRANSFER_STATUS.All
          ? JSON.stringify([branchCode])
          : "";
      }
    };
    const approvalLevelListSelected = this.view.CopyListBox0a6ce31cd0e8d4b
      .selectedkeys
      ? this.view.CopyListBox0a6ce31cd0e8d4b.selectedkeys
      : [this.view.CopyListBox0a6ce31cd0e8d4b.selectedkey];
    const checkApprovalStatus = (selected) => {
      const checkBranchIsDecentralized = (compare) => {
        let checkIsBranch = "(";
        this.listBranchCodeIsDecenterlized.map((item, index) => {
          if (
            index >= 0 &&
            index + 1 < this.listBranchCodeIsDecenterlized.length
          ) {
            return (checkIsBranch += `branch_code ${compare} ${item} ${compare === "eq" ? "or" : "and"
              } `);
          } else if (index + 1 === this.listBranchCodeIsDecenterlized.length) {
            return (checkIsBranch += `branch_code ${compare} ${item})`);
          }
        });
        return checkIsBranch;
      };
      switch (selected) {
        case "1":
          return ["approval_level eq 1"];
        case "2":
          return ["approval_level eq 2"];
        case "4":
          return [
            `(approval_level eq 4 and forein_amount le 50000 and ${checkBranchIsDecentralized(
              "eq"
            )} and forein_currency eq USD)`,
            `(approval_level eq 5 and forein_amount le 50000 and ${checkBranchIsDecentralized(
              "ne"
            )} and forein_currency eq USD)`,
            "(approval_level eq 5 and forein_amount gt 50000 and forein_currency eq USD)",
            `(approval_level eq 4 and payment_model eq DECENTRALIZED)`,
            "(approval_level eq 5 and (payment_model eq CENTRALIZED1 or payment_model eq CENTRALIZED2))"
          ];
        case "5":
          return [
            `(approval_level eq 5 and forein_amount le 50000 and ${checkBranchIsDecentralized(
              "eq"
            )} and forein_currency eq USD)`,
            `(approval_level eq 3 and forein_amount le 50000 and ${checkBranchIsDecentralized(
              "ne"
            )} and forein_currency eq USD)`,
            "(approval_level eq 3 and forein_amount gt 50000 and forein_currency eq USD)",
            `(approval_level eq 5 and payment_model eq DECENTRALIZED)`,
            "(approval_level eq 3 and (payment_model eq CENTRALIZED1 or payment_model eq CENTRALIZED2))"
          ];
        case "6":
          return ["(approval_level eq 0 or approval_level eq -1)"];
        case "7":
          return [
            `(approval_level eq 3 and forein_amount le 50000 and ${checkBranchIsDecentralized(
              "eq"
            )} and forein_currency eq USD)`,
            `(approval_level eq 4 and forein_amount le 50000 and ${checkBranchIsDecentralized(
              "ne"
            )} and forein_currency eq USD)`,
            "(approval_level eq 4 and forein_amount gt 50000 and forein_currency eq USD)",
            `(approval_level eq 3 and payment_model eq DECENTRALIZED)`,
            "(approval_level eq 4 and (payment_model eq CENTRALIZED1 or payment_model eq CENTRALIZED2))"
          ];
        case "8":
          return [
            "(approval_level eq 6 and forein_amount gt 50000 and forein_currency eq USD)",
            `(approval_level eq 6 and forein_amount le 50000 and ${checkBranchIsDecentralized(
              "ne"
            )} and forein_currency eq USD)`,
            "(approval_level eq 6 and (payment_model eq CENTRALIZED1 or payment_model eq CENTRALIZED2))"
          ];
      }
    };
    const approvalLevelStatus =
      this.view.CopyListBox0a6ce31cd0e8d4b.selectedkey !==
      FUND_TRANSFER_STATUS.All &&
      approvalLevelListSelected.reduce((init, item) => {
        init.push(...checkApprovalStatus(item));
        return init;
      }, []);
    let params = {
      transferCode: this.view.CopyTextField0ff4d45e8e47044._text || "",
      cifNumber: this.view.CopyTextField0d304989ac93044._text || "",
      fileCode: this.view.CopyTextField0f1dcf0074f0048._text || "",
      status:
        this.view.CopyListBox0b82f50ec77904e.selectedkey !==
          FUND_TRANSFER_STATUS.All
          ? this.view.CopyListBox0b82f50ec77904e.selectedkey || ""
          : "",
      approvalLevelStatus:
        this.view.CopyListBox0a6ce31cd0e8d4b.selectedkey !==
          FUND_TRANSFER_STATUS.All
          ? JSON.stringify(approvalLevelStatus) || ""
          : "",
      timeFrom: `${timeStart}T00:00:00`,
      timeTo: `${timeEnd}T00:00:00`,
      approvalLevelFirst: approvalLevelFirst || "",
      branchCode: checkBranchCode(),
      limitRecord: self.paginationRecords.limitRecord,
      offsetRecord: self.paginationRecords.offsetRecord
    };
    this.paramsListRecords = paramCustom ? paramCustom : params;
    this.presenter.getAllRecordsManagement(paramCustom ? paramCustom : params);
  },
  createApprovalLevelList(data) {
    const dataSelectDecenterlized = data.map((item) => [
      item.approvalLevel,
      item.approvalName
    ]);
    const dataSelectCenterlized = data.map((item) => [
      item.approvalLevel,
      item.approvalNameCenterlized
    ]);

    let arr1 = dataSelectDecenterlized;
    let arr2 = dataSelectCenterlized;

    let result = {};

    arr1.forEach((item) => {
      let key = item[1];
      if (result[key]) {
        result[key].push(item[0]);
      } else {
        result[key] = [item[0]];
      }
    });
    arr2.forEach((item) => {
      let key = item[1];
      if (result[key]) {
        result[key].push(item[0]);
      } else {
        result[key] = [item[0]];
      }
    });
    let finalResult = Object.entries(result).map(([key, value]) => [
      `[${value.join(", ")}]`,
      key
    ]);
    const dataSelectApproveLevel = [
      ["1", LIST_STATUS_APPROVAL.Gdv],
      ["2", LIST_STATUS_APPROVAL.Ksv],
      ["4", LIST_STATUS_APPROVAL.C1],
      ["5", LIST_STATUS_APPROVAL.Lddv],
      ["6", "Đã duyệt"],
      ["7", LIST_STATUS_APPROVAL.Cvttqt],
      ["8", LIST_STATUS_APPROVAL.C2]
    ];
    this.view.CopyListBox0a6ce31cd0e8d4b.masterData = [
      [FUND_TRANSFER_STATUS.All, "Tất cả"],
      ...dataSelectApproveLevel
    ];
  },
  createBranchList(listBranch) {
    const self = this;
    //map data select trạng thái hồ sơ
    this.view.CopyListBox0b82f50ec77904e.masterData = STATUS_RECORD;
    //map data branch code
    const dataSelectBranchCompanyCode = listBranch.filter(
      (item) => item.leadCompany === item.branchCode
    );

    self.view.CopyListBox0i6dd65c185a64a.masterData = [
      [FUND_TRANSFER_STATUS.All, "Tất cả"],
      ...dataSelectBranchCompanyCode.map((item) => [
        item.branchCode,
        item.branchName
      ])
    ];

    const currentBranch = listBranch.filter(
      (item) => item.branchCode === self.infoUser.branchCode[0]
    );
    const dataDVKD = this.listBranchCompany.filter(
      (item) => item.leadCompany === currentBranch[0].leadCompany
    );

    dataDVKD.length
      ? (self.view.CopyListBox0bcd39854d88847.masterData = [
        [FUND_TRANSFER_STATUS.All, "Tất cả"],
        ...dataDVKD.map((item) => [item.branchCode, item.branchName])
      ])
      : null;

    self.view.CopyListBox0bcd39854d88847.onSelection = (listBox) => {
      const dataDVKD = self.listBranchCompany.filter(
        (item) => item.leadCompany === self.view.CopyListBox0i6dd65c185a64a.selectedkey
      );
      self.listBranchCodeCurrent =
        listBox.selectedkey === FUND_TRANSFER_STATUS.All
          ? dataDVKD.map((item) => item.branchCode)
          : [];
    };

    self.view.CopyListBox0i6dd65c185a64a.onSelection = (listBox) => {
      const dataDVKD = listBranch.filter(
        (item) => item.leadCompany === listBox.selectedkey
      );
      dataDVKD.length
        ? (self.view.CopyListBox0bcd39854d88847.masterData = [
          [FUND_TRANSFER_STATUS.All, "Tất cả"],
          ...dataDVKD.map((item) => [item.branchCode, item.branchName])
        ])
        : (self.view.CopyListBox0bcd39854d88847.masterData = [
          [FUND_TRANSFER_STATUS.All, "Tất cả"]
        ]);
      self.listBranchCodeCurrent = dataDVKD.length
        ? dataDVKD.map((item) => item.branchCode)
        : [];
    };

    //check load lần đầu tự select sang chi nhánh và đvkd
    if (
      (self.infoUser.roleId.includes(ROLE.GDV) ||
        self.infoUser.roleId.includes(ROLE.KSV) ||
        self.infoUser.roleId.includes(ROLE.LDDV)) &&
      self.infoUser.branchCode.length === 1
    ) {
      self.view.CopyListBox0i6dd65c185a64a.selectedKey =
        currentBranch[0].leadCompany;
      self.view.CopyListBox0bcd39854d88847.selectedKey =
        currentBranch[0].branchCode;
      self.view.CopyListBox0i6dd65c185a64a.enable = false;
      self.view.CopyListBox0bcd39854d88847.enable = false;
    } else if (self.infoUser.roleId.includes(ROLE.LDDV) && self.infoUser.branchCode.length > 1) {
      const currentBranch = self.infoUser.branchCode.map(itemBranchInfo => {
        const resultCurrentBranch = listBranch.filter(
          (item) => item.branchCode === itemBranchInfo
        );
        return resultCurrentBranch[0]
      })
      const dataDVKD = currentBranch.filter(itemDVKD => {
        const resultDVKD = this.listBranchCompany.filter(
          (item) => item.leadCompany === itemDVKD.leadCompany
        );
        return resultDVKD[0];
      })

      self.view.CopyListBox0i6dd65c185a64a.selectedKey = currentBranch[0].leadCompany;
      self.view.CopyListBox0i6dd65c185a64a.enable = false;

      dataDVKD.length
        ? (self.view.CopyListBox0bcd39854d88847.masterData = [
          [FUND_TRANSFER_STATUS.All, "Tất cả"],
          ...dataDVKD.map((item) => [item.branchCode, item.branchName])
        ])
        : null;
    }
  },
  checkLoadFirst() {
    //setDateTimeDefault
    const self = this;
    var currentDate = new Date();
    var firstDay = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      1
    );
    var formattedFirstDay =
      firstDay.getDate() +
      "/" +
      (firstDay.getMonth() == 0 ? firstDay.getMonth() + 1 : firstDay.getMonth()) +
      "/" +
      firstDay.getFullYear();
    var lastDay = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth() + 1,
      0
    );
    var formattedLastDay =
      lastDay.getDate() +
      "/" +
      (lastDay.getMonth() + 1) +
      "/" +
      lastDay.getFullYear();

    //
    let approvalLevelSelectedList = [];
    const filterFirst = (firstKSV) => {
      this.view.Calendar0aaf27851c73640.date = formattedFirstDay;
      this.view.CopyCalendar0c4d712c5b9d741.date = formattedLastDay;
      this.handleSearchAllRecords(firstKSV);
    };

    self.infoUser.roleId.length &&
      self.infoUser.roleId.map((item) => {
        if (!self.statusFilterFirstKSV && item === ROLE.KSV) {
          self.statusFilterFirstKSV = true;
          approvalLevelSelectedList.push("1", "2");
          self.view.CopyListBox0a6ce31cd0e8d4b.selectedkeys =
            approvalLevelSelectedList;
          self.view.CopyListBox0a6ce31cd0e8d4b.selectedkey = "2";
        } else if (!self.statusFilterFirstGDV && item === ROLE.GDV) {
          self.statusFilterFirstGDV = true;
          approvalLevelSelectedList.push("1");
          self.view.CopyListBox0b82f50ec77904e.selectedKey =
            STATUS_RECORD[1][0];
          self.view.CopyListBox0a6ce31cd0e8d4b.selectedKey = "1";
          self.view.CopyListBox0a6ce31cd0e8d4b.selectedkeys =
            approvalLevelSelectedList;
        } else if (!self.statusFilterFirstLDDV && item === ROLE.LDDV) {
          self.statusFilterFirstLDDV = true;
          approvalLevelSelectedList.push("5");
          self.view.CopyListBox0a6ce31cd0e8d4b.selectedKey = "5";
          self.view.CopyListBox0a6ce31cd0e8d4b.selectedkeys =
            approvalLevelSelectedList;
        } else if (
          item === ROLE.CVTTQT ||
          item === ROLE.C1 ||
          item === ROLE.C2
        ) {
          self.view.CopyListBox0i6dd65c185a64a.selectedKey =
            FUND_TRANSFER_STATUS.All;
          self.view.CopyListBox0bcd39854d88847.selectedKey =
            FUND_TRANSFER_STATUS.All;
          if (!self.statusFilterFirstCVTTQT && item === ROLE.CVTTQT) {
            self.statusFilterFirstCVTTQT = true;
            approvalLevelSelectedList.push("7");
            self.view.CopyListBox0a6ce31cd0e8d4b.selectedKey = "7";
            self.view.CopyListBox0a6ce31cd0e8d4b.selectedkeys =
              approvalLevelSelectedList;
          } else if (!self.statusFilterFirstC1 && item === ROLE.C1) {
            self.statusFilterFirstC1 = true;
            approvalLevelSelectedList.push("4");
            self.view.CopyListBox0a6ce31cd0e8d4b.selectedKey = "4";
            self.view.CopyListBox0a6ce31cd0e8d4b.selectedkeys =
              approvalLevelSelectedList;
          } else if (!self.statusFilterFirstC2 && item === ROLE.C2) {
            self.statusFilterFirstC2 = true;
            approvalLevelSelectedList.push("8");
            self.view.CopyListBox0a6ce31cd0e8d4b.selectedKey = "8";
            self.view.CopyListBox0a6ce31cd0e8d4b.selectedkeys =
              approvalLevelSelectedList;
          }
        }
      });

    var selectElement = document.querySelector(".CopyslListBox0g5b9365821c444");
    var optionElements = selectElement.getElementsByTagName("option");
    for (var i = 0; i < optionElements.length; i++) {
      if (approvalLevelSelectedList.includes(optionElements[i].value)) {
        optionElements[i].selected = true;
      }
    }
    filterFirst();
  },
  addOneLineDiaChi() {
    this.tableThongTinNguoiChuyenTienLeft[4].height = $addUnit(
      this.tableThongTinNguoiChuyenTienLeft[4].height,
      this.generalHeight + "px"
    );
    this.tableThongTinNguoiChuyenTienLeft[5].height = $addUnit(
      this.tableThongTinNguoiChuyenTienLeft[5].height,
      this.generalHeight + "px"
    );
    this.tableThongTinNguoiChuyenTienLeft[6].top = $addUnit(
      this.tableThongTinNguoiChuyenTienLeft[6].top,
      this.generalHeight + "px"
    );
    this.tableThongTinNguoiChuyenTienLeft[7].top = $addUnit(
      this.tableThongTinNguoiChuyenTienLeft[7].top,
      this.generalHeight + "px"
    );
    if ($isGreaterThan($getElementTop(this.tableThongTinNguoiChuyenTienLeft[7]), this.generalHeight * 7 + "px")) {
      this.flxThongTinNguoiChuyen.height = $addUnit(
        this.flxThongTinNguoiChuyen.height,
        this.generalHeight + "px"
      );
      this.reRenderUIThongTinNguoiChuyenTien();
    }
    this.view.forceLayout();
  },
  addOneLineNoiDungThanhToan() {
    this.tableThongTinGiaoDichLeft[4].height = $addUnit(
      this.tableThongTinGiaoDichLeft[4].height,
      this.generalHeight + "px"
    );
    this.tableThongTinGiaoDichLeft[5].height = $addUnit(
      this.tableThongTinGiaoDichLeft[5].height,
      this.generalHeight + "px"
    );
    if ($isGreaterThan($getElementTop(this.tableThongTinGiaoDichLeft[5]), this.generalHeight * 3 + "px")) {
      this.flxThongTinGiaoDich.height = $addUnit(
        this.flxThongTinGiaoDich.height,
        this.generalHeight + "px"
      );
      this.reRenderUIThongTinGiaoDich();
    }
    this.view.forceLayout();
  },
  addOneLineDiaChiNguoiHuong() {
    this.tableThongTinNguoiThuHuongLeft[4].height = $addUnit(
      this.tableThongTinNguoiThuHuongLeft[4].height,
      this.generalHeight + "px"
    );
    this.tableThongTinNguoiThuHuongLeft[5].height = $addUnit(
      this.tableThongTinNguoiThuHuongLeft[5].height,
      this.generalHeight + "px"
    );
    this.tableThongTinNguoiThuHuongLeft[6].top = $addUnit(
      this.tableThongTinNguoiThuHuongLeft[6].top,
      this.generalHeight + "px"
    );
    this.tableThongTinNguoiThuHuongLeft[7].top = $addUnit(
      this.tableThongTinNguoiThuHuongLeft[7].top,
      this.generalHeight + "px"
    );
    if ($isGreaterThan($getElementTop(this.tableThongTinNguoiThuHuongLeft[7]), this.generalHeight * 5 + "px")) {
      this.flxThongTinNguoiThuHuong.height = $addUnit(
        this.flxThongTinNguoiThuHuong.height,
        this.generalHeight + "px"
      );
      this.reRenderUIThongTinNguoiThuHuong();
    }
    this.view.forceLayout();
  },
  getApprovalStatus(fundtransfer) {
    return fundtransfer.paymentModel === PAYMENT_MODEL.Decentralized;
  },
  createPagination(totalRecord) {
    const self = this;
    const totalPage = Math.ceil(totalRecord / self.limitRecord);
    let listPagination = Array.apply(null, Array(totalPage)).map(
      (item, index) => [index + 1, `Trang ${index + 1} / ${totalPage}`]
    );
    this.view.lbxPagination.masterData = listPagination;

    const handleNextPrev = (action, page) => {
      $showLoading(self.view);
      const handleAction =
        action === "next"
          ? this.view.lbxPagination.selectedKey + 1
          : this.view.lbxPagination.selectedKey - 1;
      this.handleSearchAllRecords(null, {
        ...self.paramsListRecords,
        limitRecord: self.limitRecord,
        offsetRecord:
          self.limitRecord * (action !== null ? handleAction : page) -
          self.limitRecord
      });
      self.paginationRecords = {
        ...self.paginationRecords,
        limitRecord: self.limitRecord,
        offsetRecord:
          self.limitRecord * (action !== null ? handleAction : page) -
          self.limitRecord
      };
    };
    this.view.lbxPagination.onSelection = (item) => {
      handleNextPrev(null, item.selectedkey);
      this.currentSelectPage = parseFloat(item.selectedkey);
    };
    this.view.flxNext.onClick = () => {
      if (
        this.view.lbxPagination.selectedKey >= 1 &&
        this.view.lbxPagination.selectedKey < totalPage
      ) {
        handleNextPrev("next");
        this.currentSelectPage = this.currentSelectPage + 1;
      }
    };
    this.view.flxPrevious.onClick = () => {
      if (
        this.view.lbxPagination.selectedKey > 1 &&
        this.view.lbxPagination.selectedKey <= totalPage
      ) {
        handleNextPrev("prev");
        this.currentSelectPage = this.currentSelectPage - 1;
      }
    };
    this.view.lbxPagination.selectedKey = this.currentSelectPage;
  },
  isValidBody() {
    const tenKhachHang = [];
    this.tenKhachHangTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        tenKhachHang.push($trim(key.text));
    });
    const tenKH = tenKhachHang.join(SEPARATOR_OPERATOR);
    if (tenKH.length === 0) {
      this.showErrorMessage(
        "Vui lòng nhập Tên khách hàng."
      );
      return false;
    }
    const noiDungChuyenTien = [];
    this.noiDungChuyenTienTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        noiDungChuyenTien.push($trim(key.text));
    });
    const noiDungThanhToan = noiDungChuyenTien.join(SEPARATOR_OPERATOR);
    if (noiDungThanhToan.length === 0) {
      this.showErrorMessage(
        "Vui lòng nhập Nội dung chuyển tiền."
      );
      return false;
    }
    const diaChiNguoiChuyen = [];
    this.diaChiNguoiChuyenTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        diaChiNguoiChuyen.push($trim(key.text));
    });
    const diaChiKH = diaChiNguoiChuyen.join(SEPARATOR_OPERATOR);
    if (diaChiKH.length === 0) {
      this.showErrorMessage(
        "Vui lòng nhập Địa chỉ người chuyển."
      );
      return false;
    }
    const valideField = {
      // txtSoGiayTo:
      //   "Số giấy tờ của du học sinh/người bệnh/người đi du lịch/thân nhân ở nước ngoài",
      txtBSBorRouting: this.detailUI.lblBSBorRouting.text,
    };

    let foundError = false;
    const notRequired = [
      // "txtSoGiayTo",
      "txtBSBorRouting"
    ];
    Object.keys(valideField).forEach((key) => {
      if (!foundError) {
        if (
          $isNullOrEmpty($trim(this.detailUI[key].text)) &&
          !notRequired.includes(key)
        ) {
          this.showErrorMessage(
            `Vui lòng nhập thông tin tại trường ${valideField[key]}.`
          );
          foundError = true;
        } else {
          if ($isContainsVietnamese($trim(this.detailUI[key].text))) {
            this.showErrorMessage(
              `Vui lòng nhập tiếng Anh tại trường ${valideField[key]}.`
            );
            foundError = true;
          }
        }
      }
    });
    if (foundError) {
      return false;
    }
    const lbRequired = {
      lbPhanLoaiKhachHang: "Phân loại khách hàng",
      lbKenhGiaoDich: "Kênh giao dịch"
    };
    let error = false;
    Object.keys(lbRequired).forEach((key) => {
      if (!error) {
        if ($isNullOrEmpty($trim(this.detailUI[key].selectedKey))) {
          this.showErrorMessage(
            `Vui lòng chọn giá trị tại trường ${lbRequired[key]}.`
          );
          error = true;
        }
      }
    });
    if (error) {
      return false;
    }
    let isValidF72 = true;
    this.senderToReceiverInfoTextBoxs.forEach((txt) => {
      if ($isContainsVietnamese($trim(txt.text))) isValidF72 = false;
    });
    if (!isValidF72) {
      this.showErrorMessage(
        "Vui lòng nhập tiếng Anh tại trường Sender to Receiver Info (F72)."
      );
      return false;
    }

    let isValidF77B = true;
    this.f77bTextBoxs.forEach((txt) => {
      if ($isContainsVietnamese($trim(txt.text))) isValidF77B = false;
    });
    if (!isValidF77B) {
      this.showErrorMessage(
        "Vui lòng nhập tiếng Anh tại trường Regulatory Reporting (F77B)."
      );
      return false;
    }
    return true;
  },
  nextLevel(avaiableLevel, assigne = "") {
    if (this.form.lbKiemTraPCRT.selectedKey === "") {
      this.showErrorMessage("Vui lòng chọn kết quả kiểm tra PCRT để tiếp tục.");
      return;
    }
    if (this.form.lbKetQuaKiemTra.selectedKey === "") {
      this.showErrorMessage("Vui lòng chọn kết quả kiểm tra để tiếp tục.");
      return;
    }
    if ($isNullOrEmpty($trim(this.detailUI.lbPhanLoaiKhachHang.selectedKey)) && this.form.lbKetQuaKiemTra.selectedKey === CHECK_RESULT.ValidRecords) {
      this.showErrorMessage("Vui lòng không để trống trường Phân loại khách hàng tại tab Thông tin cơ bản.");
      return;
    }
    if ($isNullOrEmpty($trim(this.form.txtTaiKhoanNostro.text))) {
      this.showErrorMessage("Vui lòng không để trống trường Tài khoản Nostro/Đối tác.");
      return;
    }
    const nostroValidate = this.listNostro.filter(
      (nostro) => nostro.accountNumber === this.form.txtTaiKhoanNostro.text
    );
    if (this.detailUI.lbKenhGiaoDich.selectedKey === CHANNEL.Nostro && nostroValidate.length === 0) {
      this.showErrorMessage("Tài khoản Nostro/Đối tác không tồn tại.");
      return;
    }
    if (this.detailUI.lbKenhGiaoDich.selectedKey === CHANNEL.Nostro && nostroValidate[0].currency !== this.detailData.foreinCurrency) {
      this.showErrorMessage("Loại tiền tài khoản Nostro khác loại ngoại tệ chuyển.");
      return;
    }
    //Tên khách hàng
    let foundErrorTenNganHang = false;
    this.tenKhachHangTextBoxs.forEach((textBox, index) => {
      if (!foundErrorTenNganHang) {
        const text = $trim(textBox.text);
        if (text.length > 0 && text[0] === "-") {
          this.showErrorMessage("Vui lòng không nhập - ở đầu dòng tại trường Tên khách hàng thứ " + (index + 1));
          foundErrorTenNganHang = true;
        }
        if ($isContainsVietnamese(text)) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh tại trường Tên khách hàng thứ " + (index + 1));
          foundErrorTenNganHang = true;
        }
      }
    });
    if (foundErrorTenNganHang) {
      return;
    }
    //Nội dung chuyển tiền
    let foundErrorNoiDungThanhToan = false;
    this.noiDungChuyenTienTextBoxs.forEach((textBox, index) => {
      if (!foundErrorNoiDungThanhToan) {
        const text = $trim(textBox.text);
        if (text.length > 0 && text[0] === "-") {
          this.showErrorMessage(
            "Không nhập dấu - ở đầu dòng Nội dung thanh toán thứ " + (index + 1)
          );
          foundErrorNoiDungThanhToan = true;
        }
        if (!foundErrorNoiDungThanhToan && $isContainsVietnamese(text)) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh tại trường Nội dung thanh toán thứ " + (index + 1));
          foundErrorNoiDungThanhToan = true;
        }
      }
    });
    if (foundErrorNoiDungThanhToan) {
      return;
    }
    const noiDungChuyenTien = [];
    this.noiDungChuyenTienTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        noiDungChuyenTien.push($trim(key.text));
    });
    const noiDungCT = noiDungChuyenTien.join('');
    const isOverLengthNostro = this.detailData.channelCode === CHANNEL.Nostro && noiDungCT.length > 140;
    const isOverLengthNium = this.detailData.channelCode !== CHANNEL.Nostro && noiDungCT.length > 255;
    if (isOverLengthNostro || isOverLengthNium) {
      this.showErrorMessage("Vượt quá số lượng kí tự trường Nội dung thanh toán");
      return;
    }
    //Địa chỉ người chuyển
    let foundErrorDiaChi = false;
    this.diaChiNguoiChuyenTextBoxs.forEach((textBox, index) => {
      if (!foundErrorDiaChi) {
        const text = $trim(textBox.text);
        if (text.length > 0 && text[0] === "-") {
          this.showErrorMessage(
            "Không nhập dấu - ở đầu dòng Địa chỉ người chuyển thứ " + (index + 1)
          );
          foundErrorDiaChi = true;
        }
        if (!foundErrorDiaChi && $isContainsVietnamese(text)) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh tại trường Địa chỉ người chuyển thứ " + (index + 1));
          foundErrorDiaChi = true;
        }
      }
    });
    if (foundErrorDiaChi) {
      return;
    }
    const diaChi = [];
    this.diaChiNguoiChuyenTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        diaChi.push($trim(key.text));
    });
    const diaChiKH = diaChi.join('');
    const isOverLengthNostroDC = this.detailData.channelCode === CHANNEL.Nostro && diaChiKH.length > 70;
    let isOverLengthNiumDC = false;
    if (this.detailData.channelCode !== CHANNEL.Nostro) {
      if (["AUD", "GBP", "USD", "SGD", "CAD", "JPY"].includes(this.detailData.foreinCurrency) && diaChiKH.length > 255) {
        isOverLengthNiumDC = true;
      }
      if (this.detailData.foreinCurrency === "NZD" && diaChiKH.length > 70) {
        isOverLengthNiumDC = true;
      }
      if (this.detailData.foreinCurrency === "EUR" && diaChiKH.length > 140) {
        isOverLengthNiumDC = true;
      }
    }
    if (isOverLengthNostroDC || isOverLengthNiumDC) {
      this.showErrorMessage("Vượt quá số lượng kí tự trường Địa chỉ người chuyển.");
      return;
    }
    //Địa chỉ người thụ hưởng
    let foundErrorDiaChiNguoiHuong = false;
    this.diaChiNguoiHuongTextBoxs.forEach((textBox, index) => {
      if (!foundErrorDiaChiNguoiHuong) {
        const text = $trim(textBox.text);
        if (text.length > 0 && text[0] === "-") {
          this.showErrorMessage(
            "Không nhập dấu - ở đầu dòng Địa chỉ người thụ hưởng thứ " + (index + 1)
          );
          foundErrorDiaChiNguoiHuong = true;
        }
        if (!foundErrorDiaChiNguoiHuong && $isContainsVietnamese(text)) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh tại trường Địa chỉ người chuyển thứ " + (index + 1));
          foundErrorDiaChiNguoiHuong = true;
        }
      }
    });
    if (foundErrorDiaChiNguoiHuong) {
      return;
    }
    const diaChiNguoiHuong = [];
    this.diaChiNguoiHuongTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        diaChiNguoiHuong.push($trim(key.text));
    });
    const diaChiNH = diaChiNguoiHuong.join('');
    const isOverLengthNostroDCNH = this.detailData.channelCode === CHANNEL.Nostro && diaChiNH.length > 70;
    const isOverLengthNiumDCNH = this.detailData.channelCode !== CHANNEL.Nostro && diaChiNH.length > 200;
    if (isOverLengthNostroDCNH || isOverLengthNiumDCNH) {
      this.showErrorMessage("Vượt quá số lượng kí tự trường Địa chỉ người thụ hưởng.");
      return;
    }
    //Tên ngân hàng hưởng
    const tenNganHangHuong = this.detailUI.txtTenNganHangThuHuong.text;
    if (tenNganHangHuong.length > 0 && tenNganHangHuong[0] === "-") {
      this.showErrorMessage("Vui lòng không nhập - ở đầu dòng trường Tên ngân hàng thụ hưởng.");
      return;
    }
    if ($isContainsVietnamese(tenNganHangHuong)) {
      this.showErrorMessage("Vui lòng nhập tiếng Anh tại trường Tên ngân hàng thụ hưởng.");
      return;
    }
    // địa chỉ ngân hàng hưởng
    let foundErrorNganHangThuHuong = false;
    this.nganHangThuHuongTextBoxs.forEach((textBox, index) => {
      if (!foundErrorNganHangThuHuong) {
        const text = $trim(textBox.text);
        if (text.length > 0 && text[0] === "-") {
          this.showErrorMessage("Vui lòng không nhập - ở đầu dòng trường Địa chỉ ngân hàng người thụ hưởng thứ " + (index + 1));
          foundErrorNganHangThuHuong = true;
        }
        if (!foundErrorDiaChi && $isContainsVietnamese(text)) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh tại trường Địa chỉ ngân hàng người thụ hưởng thứ " + (index + 1));
          foundErrorNganHangThuHuong = true;
        }
      }
    });
    if (foundErrorNganHangThuHuong) {
      return;
    }
    //validate trường BSB/Transit/Sortcode
    const channelSelected = this.detailUI.lbKenhGiaoDich.selectedKey;
    if (channelSelected === CHANNEL.NiumLocal &&
      ["GBP", "JPY", "CAD", "AUD"].includes(this.detailData.foreinCurrency) && this.detailUI.txtBSBorRouting.text.length === 0) {
      this.showErrorMessage("Vui lòng không để trống trường BSB/Transit/Sortcode");
      return;
    }
    //F72
    let error = false;
    this.senderToReceiverInfoTextBoxs.forEach((textBox, index) => {
      if (!error) {
        const text = textBox.text;
        const isFirst = textBox.isFirst;
        if (text) {
          if (text[0] !== "/") {
            if (isFirst) {
              this.showErrorMessage(
                "Vui lòng nhập code theo format / tại ô Sender to Receiver Info (F72) đầu tiên."
              );
              error = true;
            } else {
              this.showErrorMessage(
                "Vui lòng nhập code theo format // tại ô Sender to Receiver Info (F72) thứ " +
                (index + 1)
              );
              error = true;
            }
          }
          if (
            !error &&
            text.length > 1 &&
            !isFirst &&
            (text[0] !== "/" || text[1] !== "/")
          ) {
            this.showErrorMessage(
              "Vui lòng nhập code theo format // tại ô Sender to Receiver Info (F72) thứ " +
              (index + 1)
            );
            error = true;
          }
        }
        if (!error && $isContainsVietnamese($trim(text))) {
          this.showErrorMessage(
            "Vui lòng nhập tiếng Anh tại ô Sender to Receiver Info (F72) thứ " +
            (index + 1)
          );
          error = true;
        }
      }
    });
    if (error) {
      return;
    }
    //F77B
    let foundError = false;
    this.f77bTextBoxs.forEach((textBox, index) => {
      if (!foundError) {
        const text = textBox.text;
        const isFirst = textBox.isFirst;
        if (text) {
          if (text[0] !== "/") {
            if (isFirst) {
              this.showErrorMessage(
                "Vui lòng nhập code theo format / tại ô Regulatory Reporting (F77B) đầu tiên."
              );
              foundError = true;
            } else {
              this.showErrorMessage(
                "Vui lòng nhập code theo format // tại ô Regulatory Reporting (F77B) thứ " +
                (index + 1)
              );
              foundError = true;
            }
          }
          if (
            !foundError &&
            text.length > 1 &&
            !isFirst &&
            (text[0] !== "/" || text[1] !== "/")
          ) {
            this.showErrorMessage(
              "Vui lòng nhập code theo format // tại ô Regulatory Reporting (F77B) thứ " +
              (index + 1)
            );
            foundError = true;
          }
        }
        if (!foundError && $isContainsVietnamese($trim(text))) {
          this.showErrorMessage(
            "Vui lòng nhập tiếng Anh tại ô Regulatory Reporting (F77B) thứ " +
            (index + 1)
          );
          foundError = true;
        }
      }
    });
    if (foundError) {
      return;
    }

    const isValidResult =
      this.form.lbKetQuaKiemTra.selectedkey === CHECK_RESULT.ValidRecords;
    if (isValidResult) {
      if (!this.isValidBody()) {
        return;
      }
    } else {
      if ($isNullOrEmpty(this.form.txtMoTaLyDoChiTiet.text)) {
        this.showErrorMessage(
          "Vui lòng nhập lý do tại trường Mô tả lý do chi tiết (Phản hồi cho KH)."
        );
        return;
      }
    }
    this.files = [...this.attachFiles].map((file) => ({
      name: $getFileName(file.name),
      type: $getFileExtension(file.name)
    }));
    // fundTransferAdditional
    const {
      txtTaiKhoanNostro,
      cbHoSo,
      cbNoChungTu,
      txtMoTaLyDoChiTiet,
      lbKetQuaKiemTra,
      lbKiemTraPCRT,
      txtSwiftMT103SentTo,
      txtPhanHoiCuaDVKD,
      txtPhanHoiCuaTTTTQT
    } = this.form;
    const { fundTransferAdditional = {} } = this.responseData;
    delete fundTransferAdditional.pvbFundTransferId;
    const senderToReceiverInfor = [];
    this.senderToReceiverInfoTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        senderToReceiverInfor.push($trim(key.text));
    });
    const f77B = [];
    this.f77bTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text))) f77B.push($trim(key.text));
    });

    const payload = {
      nostroAcountNumber: txtTaiKhoanNostro.text,
      isException: cbHoSo.selectedKey === "NgoaiLe",
      isDocumentsDebt: cbNoChungTu.selectedKey === "No",
      paymentModel: this.paymentModel,
      otherProblem: $trim(txtMoTaLyDoChiTiet.text),
      pvbFundTransferId: this.detailData.id,
      senderToReceiverInfo: senderToReceiverInfor.join(
        SEPARATOR_OPERATOR
      ),
      regulatoryReporting: f77B.join(SEPARATOR_OPERATOR),
      resultCheck: lbKetQuaKiemTra.selectedKey,
      pcrtBranch: lbKiemTraPCRT.selectedKey,
      swiftMt103: $trim(txtSwiftMT103SentTo.text),
      feedbackDvkd: $trim(txtPhanHoiCuaDVKD.text),
      feedbackTtTtqt: $trim(txtPhanHoiCuaTTTTQT.text)
    };
    if (this.detailUI.lbKenhGiaoDich.selectedKey === CHANNEL.Nostro) {
      if (Boolean(this.detailData.manualSwiftCode)) {
        payload.beneficiaryBankIdentifierCode = this.detailUI.txtBSBorRouting.text;
      }
      else {
        payload.extraCode = this.detailUI.txtBSBorRouting.text;
      }
    }
    else {
      payload.routingCode = this.detailUI.txtBSBorRouting.text;
    }
    this.action = ACTION_STEP_NAME.chuyenCapDuyet;
    let fundTransferAdditionalData = {};
    const isNew = $isEmptyObject(fundTransferAdditional);
    if (isNew) {
      this.changeAdditionalData = [
        ...this.changeAdditionalData,
        ...$findDifferentFields({
          beneficiaryBankIdentifierCode: this.detailData.beneficiaryBankIdentifierCode || "",
          extraCode: this.detailData.extraCode || "",
          routingCode: this.detailData.routingCode || "",
        }, payload)
      ];
      fundTransferAdditionalData = $findDifferentFields({}, payload, true);
    } else {
      const payloadUpdate = {
        ...fundTransferAdditional,
        ...payload
      };
      this.changeAdditionalData = [
        ...this.changeAdditionalData,
        ...$findDifferentFields(fundTransferAdditional, payloadUpdate)
      ];
      fundTransferAdditionalData = {
        ...fundTransferAdditional,
        ...payloadUpdate
      };
    }

    // fundTransfer
    let fundTransfer = {};
    const diaChiNganHangThuHuong = [];
    this.nganHangThuHuongTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        diaChiNganHangThuHuong.push($trim(key.text));
    });
    const tenKhachHang = [];
    this.tenKhachHangTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        tenKhachHang.push($trim(key.text));
    });
    if (isValidResult) {
      fundTransfer = {
        id: this.detailData.id,
        assigne,
        approvalLevel: avaiableLevel,
        additionalAssigne: this.isHasRoleUpdateDocument
          ? this.detailData.assigne
          : this.detailUI.additionalAssigne,
        customerNameEn: tenKhachHang.join(SEPARATOR_OPERATOR),
        customerAddressEn: diaChi.join(SEPARATOR_OPERATOR),
        beneficiaryAddressEn: diaChiNguoiHuong.join(SEPARATOR_OPERATOR),
        beneficiaryBankAddress: diaChiNganHangThuHuong.join(SEPARATOR_OPERATOR),
        // beneficiaryIdNumber: this.detailUI.txtSoGiayTo.text,
        paymentNoteEn: noiDungChuyenTien.join(SEPARATOR_OPERATOR),
        beneficiaryCountryCode:
          this.detailUI.lbCountry.selectedKey === ""
            ? this.detailData.beneficiaryCountryCode || ""
            : this.detailUI.lbCountry.selectedKey,
        customerType: this.detailUI.lbPhanLoaiKhachHang.selectedKey,
        customerAccountType: this.detailUI.txtLoaiTaiKhoanNguoiChuyen.text,
        customerCountryCode: this.detailUI.txtMaQuocGiaNguoiChuyen.text,
        customerPostcode: this.detailUI.txtMaBuuChinhNguoiChuyen.text,
        customerIdentificationType: this.detailUI.txtLoaiGiayToTuyThan.text,
        channelCode: this.detailUI.lbKenhGiaoDich.selectedKey,
        localConversionCurrency: this.detailUI.txtNgoaiTeChuyenDoi.text,
        beneficiaryBank: this.detailUI.txtTenNganHangThuHuong.text,
      };
    } else {
      fundTransfer = {
        id: this.detailData.id,
        assigne,
        approvalLevel: avaiableLevel,
        additionalAssigne: this.isHasRoleUpdateDocument
          ? this.detailData.assigne
          : this.detailUI.additionalAssigne
      };
    }
    const changeDetail = $findDifferentFields(this.detailData, {
      ...this.detailData,
      ...fundTransfer
    });
    this.changeAdditionalData = [...this.changeAdditionalData, ...changeDetail];
    this.changeAdditionalData.push({
      field: "assignLog",
      oldValue: null,
      newValue: JSON.stringify({
        approvalLevel: this.detailData.approvalLevel,
        assigne: this.infoUser.id
      })
    });
    // steps
    const data = this.changeAdditionalData.map((data) => $toStringObj(data));
    const approvalSteps = {
      action: this.action,
      data,
      additionalDataId: this.responseData.fundTransferAdditional
        ? this.responseData.fundTransferAdditional.id
        : null,
      pvbFundTransferId: this.detailData.id
    };
    // payload
    const body = {
      fundTransfer,
      fundTransferAdditional: fundTransferAdditionalData,
      approvalSteps,
      paymentModel: this.paymentModel
    };
    $showLoading(this.view);
    if (!this.isHasRoleUpdateDocument) {
      this.presenter.chuyenCap(body);
      return;
    }
    const fieldCheckNonPrinable = [
      { "Địa chỉ người chuyển": diaChi.join(SEPARATOR_OPERATOR) },
      { "Địa chỉ người thụ hưởng": diaChiNguoiHuong.join(SEPARATOR_OPERATOR) },
      { "Địa chỉ ngân hàng hưởng": diaChiNganHangThuHuong.join(SEPARATOR_OPERATOR), }
    ];
    const textAlert = this.checkNonPrinable(fieldCheckNonPrinable);
    if ($isNullOrEmpty(textAlert)) {
      this.presenter.chuyenCap(body);
      return;
    }
    $hideLoading(this.view);
    this.showPopup(textAlert, () => { this.presenter.chuyenCap(body); }, () => { });
  },
  checkNonPrinable(texts) {
    debugger
    let textAlert = "";
    texts.forEach(text => {
      const value = Object.values(text);
      const field = Object.keys(text);
      const checkNonPrinable = $findNonASCIICharacter(value[0]);
      if (checkNonPrinable.position !== -1) {
        textAlert += `Có kí tự đặc biệt "${checkNonPrinable.specialCharacter}" ở vị trí thứ ${checkNonPrinable.position} đằng sau chuỗi "${checkNonPrinable.characters}" tại trường ${field[0]}. `;
      }
    });
    if (!$isNullOrEmpty(textAlert)) { textAlert += `Nếu không sửa lại thì có thể bị lỗi khi tạo điện. Bạn có chắc chắn chuyển cấp không?` };
    return textAlert;
  },
  preLevel(avaiableLevel, assigne = "") {
    this.files = [...this.attachFiles].map((file) => ({
      name: $getFileName(file.name),
      type: $getFileExtension(file.name)
    }));
    // fundTransferAdditional
    const { fundTransferAdditional } = this.responseData;
    delete fundTransferAdditional.pvbFundTransferId;
    const { txtPhanHoiCuaDVKD, txtPhanHoiCuaTTTTQT, txtMoTaLyDoChiTiet } =
      this.form;
    this.action = ACTION_STEP_NAME.phanHoi;
    const fundTransferAdditionalData = {
      ...fundTransferAdditional,
      feedbackDvkd: $trim(txtPhanHoiCuaDVKD.text),
      feedbackTtTtqt: $trim(txtPhanHoiCuaTTTTQT.text),
      otherProblem: $trim(txtMoTaLyDoChiTiet.text)
    };
    if (fundTransferAdditional.feedbackDvkd !== $trim(txtPhanHoiCuaDVKD.text))
      this.changeAdditionalData.push({
        field: "feedbackDvkd",
        oldValue: fundTransferAdditional.feedbackDvkd || "",
        newValue: $trim(txtPhanHoiCuaDVKD.text)
      });
    if (
      fundTransferAdditional.feedbackTtTtqt !== $trim(txtPhanHoiCuaTTTTQT.text)
    )
      this.changeAdditionalData.push({
        field: "feedbackTtTtqt",
        oldValue: fundTransferAdditional.feedbackTtTtqt || "",
        newValue: $trim(txtPhanHoiCuaTTTTQT.text)
      });

    // fundTransfer
    const fundTransfer = {
      assigne,
      approvalLevel: avaiableLevel,
      id: this.detailData.id,
      additionalAssigne: this.detailUI.additionalAssigne
    };
    this.changeAdditionalData.push({
      field: "approvalLevel",
      oldValue: this.detailData.approvalLevel,
      newValue: avaiableLevel
    });
    if (this.detailData.assigne !== this.detailData.additionalAssigne)
      this.changeAdditionalData.push({
        field: "assigne",
        oldValue: this.detailData.assigne || "",
        newValue: this.detailData.additionalAssigne || ""
      });
    this.changeAdditionalData.push({
      field: "assignLog",
      oldValue: null,
      newValue: JSON.stringify({
        approvalLevel: this.detailData.approvalLevel,
        assigne: this.infoUser.id
      })
    });
    // steps
    const data = this.changeAdditionalData.map((data) => $toStringObj(data));
    const approvalSteps = {
      action: this.action,
      data,
      additionalDataId: this.responseData.fundTransferAdditional
        ? this.responseData.fundTransferAdditional.id
        : null,
      pvbFundTransferId: this.detailData.id
    };
    // payload
    const body = {
      fundTransfer,
      fundTransferAdditional: fundTransferAdditionalData,
      approvalSteps,
      paymentModel: this.paymentModel
    };
    this.presenter.chuyenCap(body);
  },
  finalApproval(status, approvalLevel) {
    // fundTransfer
    const fundTransfer = {
      approvalLevel,
      id: this.detailData.id,
      status,
      assigne: ""
    };
    if (status === FUND_TRANSFER_STATUS.OnHold) {
      const soNgayHoSoHetHan = 2;
      fundTransfer.expiredDate = $addWorkingDays(
        new Date(),
        soNgayHoSoHetHan,
        this.holidays
      );
    }
    if (status === FUND_TRANSFER_STATUS.Accepted) {
      fundTransfer.expiredDate = $getExpriedTimeAccepted(
        new Date(),
        this.holidays
      );
    }
    this.action = ACTION_STEP_NAME.duyet;
    this.changeAdditionalData.push({
      field: "status",
      oldValue: this.detailData.status,
      newValue: status
    });
    this.changeAdditionalData.push({
      field: "approvalLevel",
      oldValue: this.detailData.approvalLevel,
      newValue: approvalLevel
    });
    this.changeAdditionalData.push({
      field: "assignLog",
      oldValue: null,
      newValue: JSON.stringify({
        approvalLevel: this.detailData.approvalLevel,
        assigne: this.infoUser.id
      })
    });
    // steps
    const data = this.changeAdditionalData.map((data) => $toStringObj(data));
    const approvalSteps = {
      action: this.action,
      data,
      additionalDataId: this.responseData.fundTransferAdditional
        ? this.responseData.fundTransferAdditional.id
        : null,
      pvbFundTransferId: this.detailData.id
    };
    const body = {
      fundTransfer,
      approvalSteps,
      paymentModel: this.paymentModel,
      resultCheck: this.form.lbKetQuaKiemTra.selectedKey
    };
    $showLoading(this.view);
    this.presenter.finalApproval(body);
  },
  verifySwiftCode(swiftCode) {
    this.presenter.verifySwiftCode({ swiftCode });
  },
  setMaxLengthTheoKenh(data) {
    if (data.channelCode === CHANNEL.Nostro) {
      this.amountOfLineNoiDungChuyenTien = 4;
      this.amountOfAddressLine = 2;
      this.amountOfAddressLineNguoiHuong = 2;
      this.detailUI.txtDiaChiNguoiThuHuong.restrictCharactersSet =
        T24_RESTRICT_CHARACTER;
      this.diaChiNguoiHuongTextBoxs.forEach(textBox => {
        textBox.onTextChange = (txt) => {
          const text = $trim(txt.text).toUpperCase();
          txt.text = text;
          if (text.length > 0 && text[0] === "-") {
            this.showErrorMessage("Vui lòng không nhập - ở đầu dòng.");
            return;
          }
          if ($isContainsVietnamese(text)) {
            this.showErrorMessage("Vui lòng nhập tiếng Anh.");
            return;
          }
        };
      })
      this.form.btnAddDiaChiNguoiChuyen.onClick = () => { this.onClickBtnAddDiaChiNguoiChuyen(); }
      this.form.btnAddDiaChiNguoiHuong.onClick = () => { this.onClickBtnAddDiaChiNguoiHuong(); }
      this.form.btnAddNoiDungChuyenTien.onClick = () => { this.onClickBtnAddNoiDungChuyenTien(); }
      this.setDiaChiTextBoxKeyUp();
      this.setDiaChiNguoiHuongTextBoxKeyUp();
      this.setNoiDungThanhToanTextBoxKeyUp();
      return;
    }
    if (
      data.channelCode === CHANNEL.NiumLocal ||
      data.channelCode === CHANNEL.NiumSwift
    ) {
      this.amountOfLineNoiDungChuyenTien = 8;
      if (
        ["AUD", "GBP", "USD", "SGD", "CAD", "JPY"].includes(data.foreinCurrency)
      ) {
        this.amountOfAddressLine = 8;
      }
      if (data.foreinCurrency === "NZD") {
        this.amountOfAddressLine = 2;
      }
      if (data.foreinCurrency === "EUR") {
        this.amountOfAddressLine = 4;
      }
      this.amountOfAddressLineNguoiHuong = 6
      this.detailUI.txtDiaChiNguoiThuHuong.restrictCharactersSet = "";
      this.form.btnAddDiaChiNguoiChuyen.onClick = () => { this.onClickBtnAddDiaChiNguoiChuyen(); };
      this.form.btnAddDiaChiNguoiHuong.onClick = () => { this.onClickBtnAddDiaChiNguoiHuong(); }
      this.form.btnAddNoiDungChuyenTien.onClick = () => { this.onClickBtnAddNoiDungChuyenTien(); }
      this.setDiaChiNguoiHuongTextBoxKeyUp();
      this.setDiaChiTextBoxKeyUp();
      this.setNoiDungThanhToanTextBoxKeyUp();
      return;
    }
  },
  createCountryListBox() {
    const countryEntries = this.countries.map((obj) => [
      $trim(obj.Code),
      `${obj.Name} - ${$trim(obj.Code)}`
    ]);
    this.detailUI.lbCountry.masterData = countryEntries;
  },
  generateErrorMessage(errorArray, fieldChange, channelCode) {
    const channel = this.listChannels.filter(
      (channel) => channel.code === channelCode
    )[0];
    let errorMessage = `${channel.name} - ${channel.code} không khả dụng vì các lý do sau: \n`;
    for (let i = 0; i < errorArray.length; i++) {
      let field = errorArray[i].field;
      let errorType = errorArray[i].error;
      let fieldName = fieldChange[field] || field;
      const errorName = {
        regex: "regex ",
        required: "Bắt buộc"
      };
      if (!errorMessage.includes(fieldName)) {
        if (errorType === "required") {
          errorMessage += `    - Vui lòng không để trống trường  "${fieldName}".\n`;
        }
        else
          if (errorType === "regex") {
            errorMessage += `    - Giá trị trường "${fieldName}" không thỏa mãn điều kiện ${errorName[errorType]
              }${errorArray[i].regex ? errorArray[i].regex : "."}\n`;
          }
      }
    }
    return errorMessage;
  },
  showWarningPopup(message) {
    this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = true;
    this.view.CopyflxPopUpTopColor0e442b9b0742843.skin =
      DEFAULT_SKIN.WarningPopup;
    this.view.CopylblPopUpMainMessage0g3eda8bde3854e.text = message;
    this.view.CopybtnPopUpSave0cabfb6db5c5347.isVisible = false;
    this.view.CopybtnPopUpCancel0f3298c2214fe47.onClick = () => {
      this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
    };
    this.view.CopyflxPopUpClose0b9f4641e1b4845.onClick = () => {
      this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
    };
    this.view.forceLayout();
  },
  validateChannel(channelCode = "", callback = () => { }) {
    if ($isNullOrEmpty(channelCode)) {
      $hideLoading(this.view);
      this.showErrorMessage("Vui lòng chọn kênh giao dịch");
      return;
    }
    this.callbackAfterValidate = callback;
    const diaChiNganHangThuHuong = [];
    this.nganHangThuHuongTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        diaChiNganHangThuHuong.push($trim(key.text));
    });
    const tenKhachHang = [];
    this.tenKhachHangTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        tenKhachHang.push($trim(key.text));
    });
    const diaChi = [];
    this.diaChiNguoiChuyenTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        diaChi.push($trim(key.text));
    });
    const diaChiNguoiHuong = [];
    this.diaChiNguoiHuongTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        diaChiNguoiHuong.push($trim(key.text));
    });
    const noiDungChuyenTien = [];
    this.noiDungChuyenTienTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        noiDungChuyenTien.push($trim(key.text));
    });
    const fundTransfer = {
      ...this.detailData,
      transferPurposeName: "",
      customerNameEn: tenKhachHang.join(SEPARATOR_OPERATOR),
      customerAddressEn: diaChi.join(SEPARATOR_OPERATOR),
      // beneficiaryIdNumber: this.detailUI.txtSoGiayTo.text,
      paymentNoteEn: noiDungChuyenTien.join(SEPARATOR_OPERATOR),
      beneficiaryAddressEn: diaChiNguoiHuong.join(SEPARATOR_OPERATOR),
      beneficiaryBankAddress: diaChiNganHangThuHuong.join(SEPARATOR_OPERATOR),
      beneficiaryCountryCode:
        this.detailUI.lbCountry.selectedKey === ""
          ? this.detailData.beneficiaryCountryCode || ""
          : this.detailUI.lbCountry.selectedKey,
      customerType: this.detailUI.lbPhanLoaiKhachHang.selectedKey,
      customerAccountType: this.detailUI.txtLoaiTaiKhoanNguoiChuyen.text,
      customerCountryCode: this.detailUI.txtMaQuocGiaNguoiChuyen.text,
      customerPostcode: this.detailUI.txtMaBuuChinhNguoiChuyen.text,
      customerIdentificationType: this.detailUI.txtLoaiGiayToTuyThan.text,
      channelCode,
      localConversionCurrency: this.detailUI.txtNgoaiTeChuyenDoi.text
    };
    //additional
    const {
      txtTaiKhoanNostro,
      cbHoSo,
      cbNoChungTu,
      txtMoTaLyDoChiTiet,
      lbKetQuaKiemTra,
      lbKiemTraPCRT,
      txtSwiftMT103SentTo,
      txtPhanHoiCuaDVKD,
      txtPhanHoiCuaTTTTQT
    } = this.form;
    const { fundTransferAdditional = {} } = this.responseData;
    delete fundTransferAdditional.pvbFundTransferId;
    const senderToReceiverInfor = [];
    this.senderToReceiverInfoTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text)))
        senderToReceiverInfor.push($trim(key.text));
    });
    const f77B = [];
    this.f77bTextBoxs.forEach((key) => {
      if (!$isNullOrEmpty($trim(key.text))) f77B.push($trim(key.text));
    });
    const payload = {
      nostroAcountNumber: txtTaiKhoanNostro.text,
      isException: cbHoSo.selectedKey === "NgoaiLe",
      isDocumentsDebt: cbNoChungTu.selectedKey === "No",
      paymentModel: this.paymentModel,
      otherProblem: $trim(txtMoTaLyDoChiTiet.text),
      pvbFundTransferId: this.detailData.id,
      senderToReceiverInfo: senderToReceiverInfor.join(
        SEPARATOR_OPERATOR
      ),
      regulatoryReporting: f77B.join(SEPARATOR_OPERATOR),
      resultCheck: lbKetQuaKiemTra.selectedKey,
      pcrtBranch: lbKiemTraPCRT.selectedKey,
      swiftMt103: $trim(txtSwiftMT103SentTo.text),
      feedbackDvkd: $trim(txtPhanHoiCuaDVKD.text),
      feedbackTtTtqt: $trim(txtPhanHoiCuaTTTTQT.text)
    };
    if (this.detailUI.lbKenhGiaoDich.selectedKey === CHANNEL.Nostro) {
      if (Boolean(this.detailData.manualSwiftCode)) {
        payload.beneficiaryBankIdentifierCode = this.detailUI.txtBSBorRouting.text;
      }
      else {
        payload.extraCode = this.detailUI.txtBSBorRouting.text;
      }
    }
    else {
      payload.routingCode = this.detailUI.txtBSBorRouting.text;
    }
    let fundTransferAdditionalData = {};
    const isNew = $isEmptyObject(fundTransferAdditional);
    if (isNew) {
      fundTransferAdditionalData = $findDifferentFields({}, payload, true);
    } else {
      fundTransferAdditionalData = {
        ...fundTransferAdditional,
        ...payload
      };
    }
    const body = {
      fundTransfer,
      fundTransferAdditional: fundTransferAdditionalData,
      channelCode
    };
    this.presenter.getAccessibleChannel(body);
  },
  onClickBtnAddDiaChiNguoiChuyen() {
    for (var i = 0; i < this.amountOfAddressLine; i++) {
      if (!this.diaChiNguoiChuyenTextBoxs[i].isVisible) {
        this.diaChiNguoiChuyenTextBoxs[i].isVisible = true;
        break;
      }
    }
    if ($isLessThan(this.tableThongTinNguoiChuyenTienLeft[5].height, this.generalHeight * this.amountOfAddressLine + "px")) {
      this.tableThongTinNguoiChuyenTienLeft[4].height = $addUnit(
        this.tableThongTinNguoiChuyenTienLeft[4].height,
        this.generalHeight + "px"
      );
      this.tableThongTinNguoiChuyenTienLeft[5].height = $addUnit(
        this.tableThongTinNguoiChuyenTienLeft[5].height,
        this.generalHeight + "px"
      );
      this.tableThongTinNguoiChuyenTienLeft[6].top = $addUnit(
        this.tableThongTinNguoiChuyenTienLeft[6].top,
        this.generalHeight + "px"
      );
      this.tableThongTinNguoiChuyenTienLeft[7].top = $addUnit(
        this.tableThongTinNguoiChuyenTienLeft[7].top,
        this.generalHeight + "px"
      );
      if ($isGreaterThan($getElementTop(this.tableThongTinNguoiChuyenTienLeft[7]), this.generalHeight * 7 + "px")) {
        this.flxThongTinNguoiChuyen.height = $addUnit(
          this.flxThongTinNguoiChuyen.height,
          this.generalHeight + "px"
        );
        this.reRenderUIThongTinNguoiChuyenTien();
      }
    }
  },
  onClickBtnAddNoiDungChuyenTien() {
    for (var i = 0; i < this.amountOfLineNoiDungChuyenTien; i++) {
      if (!this.noiDungChuyenTienTextBoxs[i].isVisible) {
        this.noiDungChuyenTienTextBoxs[i].isVisible = true;
        break;
      }
    }
    if ($isLessThan(this.tableThongTinGiaoDichLeft[5].height, this.generalHeight * this.amountOfLineNoiDungChuyenTien + "px")) {
      this.tableThongTinGiaoDichLeft[4].height = $addUnit(
        this.tableThongTinGiaoDichLeft[4].height,
        this.generalHeight + "px"
      );
      this.tableThongTinGiaoDichLeft[5].height = $addUnit(
        this.tableThongTinGiaoDichLeft[5].height,
        this.generalHeight + "px"
      );
      if ($isGreaterThan($getElementTop(this.tableThongTinGiaoDichLeft[5]), this.generalHeight * 3 + "px")) {
        this.flxThongTinGiaoDich.height = $addUnit(
          this.flxThongTinGiaoDich.height,
          this.generalHeight + "px"
        );
        this.reRenderUIThongTinGiaoDich();
      }
    }
  },
  onClickBtnAddDiaChiNguoiHuong() {
    for (var i = 0; i < this.amountOfAddressLineNguoiHuong; i++) {
      if (!this.diaChiNguoiHuongTextBoxs[i].isVisible) {
        this.diaChiNguoiHuongTextBoxs[i].isVisible = true;
        break;
      }
    }
    if ($isLessThan(this.tableThongTinNguoiThuHuongLeft[5].height, this.generalHeight * this.amountOfAddressLineNguoiHuong + "px")) {
      this.tableThongTinNguoiThuHuongLeft[4].height = $addUnit(
        this.tableThongTinNguoiThuHuongLeft[4].height,
        this.generalHeight + "px"
      );
      this.tableThongTinNguoiThuHuongLeft[5].height = $addUnit(
        this.tableThongTinNguoiThuHuongLeft[5].height,
        this.generalHeight + "px"
      );
      this.tableThongTinNguoiThuHuongLeft[6].top = $addUnit(
        this.tableThongTinNguoiThuHuongLeft[6].top,
        this.generalHeight + "px"
      );
      this.tableThongTinNguoiThuHuongLeft[7].top = $addUnit(
        this.tableThongTinNguoiThuHuongLeft[7].top,
        this.generalHeight + "px"
      );
      if ($isGreaterThan($getElementTop(this.tableThongTinNguoiThuHuongLeft[7]), this.generalHeight * 5 + "px")) {
        this.flxThongTinNguoiThuHuong.height = $addUnit(
          this.flxThongTinNguoiThuHuong.height,
          this.generalHeight + "px"
        );
        this.reRenderUIThongTinNguoiThuHuong();
      }
    }
  },
  setDiaChiTextBoxKeyUp() {
    for (let i = 0; i < this.amountOfAddressLine - 1; i++) {
      const textBox = this.diaChiNguoiChuyenTextBoxs[i];
      const index = i;
      textBox.onTextChange = (textBox) => {
        const text = $trim(textBox.text);
        if (text.length > 0 && text[0] === "-") {
          this.showErrorMessage("Vui lòng không nhập - ở đầu dòng.");
          return;
        }
        if ($isContainsVietnamese(text)) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh.");
          return;
        }
      };
      if (index === 0) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length == 35) {
          if (this.diaChi2.isVisible === false) {
            this.diaChi2.isVisible = true;
            this.addOneLineDiaChi();
          }
          this.diaChi2.setFocus(true);
        }
      }
      if (index === 1) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.diaChi3.isVisible === false) {
            this.diaChi3.isVisible = true;
            this.addOneLineDiaChi();
          }
          this.diaChi3.setFocus(true);
        }
      }
      if (index === 2) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.diaChi4.isVisible === false) {
            this.diaChi4.isVisible = true;
            this.addOneLineDiaChi();
          }
          this.diaChi4.setFocus(true);
        }
      }
      if (index === 3) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.diaChi5.isVisible === false) {
            this.diaChi5.isVisible = true;
            this.addOneLineDiaChi();
          }
          this.diaChi5.setFocus(true);
        }
      }
      if (index === 4) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.diaChi6.isVisible === false) {
            this.diaChi6.isVisible = true;
            this.addOneLineDiaChi();
          }
          this.diaChi6.setFocus(true);
        }
      }
      if (index === 5) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.diaChi7.isVisible === false) {
            this.diaChi7.isVisible = true;
            this.addOneLineDiaChi();
          }
          this.diaChi7.setFocus(true);
        }
      }
      if (index === 6) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.diaChi8.isVisible === false) {
            this.diaChi8.isVisible = true;
            this.addOneLineDiaChi();
          }
          this.diaChi8.setFocus(true);
        }
      }
    };
  },
  setDiaChiNguoiHuongTextBoxKeyUp() {
    for (let i = 0; i < this.amountOfAddressLineNguoiHuong - 1; i++) {
      const textBox = this.diaChiNguoiHuongTextBoxs[i];
      const index = i;
      textBox.onTextChange = (textBox) => {
        const text = $trim(textBox.text);
        if (text.length > 0 && text[0] === "-") {
          this.showErrorMessage("Vui lòng không nhập - ở đầu dòng.");
          return;
        }
        if ($isContainsVietnamese(text)) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh.");
          return;
        }
      };
      if (index === 0) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length == 35) {
          if (this.diaChiNguoiHuong2.isVisible === false) {
            this.diaChiNguoiHuong2.isVisible = true;
            this.addOneLineDiaChiNguoiHuong();
          }
          this.diaChiNguoiHuong2.setFocus(true);
        }
      }
      if (index === 1) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.diaChiNguoiHuong3.isVisible === false) {
            this.diaChiNguoiHuong3.isVisible = true;
            this.addOneLineDiaChiNguoiHuong();
          }
          this.diaChiNguoiHuong3.setFocus(true);
        }
      }
      if (index === 2) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.diaChiNguoiHuong4.isVisible === false) {
            this.diaChiNguoiHuong4.isVisible = true;
            this.addOneLineDiaChiNguoiHuong();
          }
          this.diaChiNguoiHuong4.setFocus(true);
        }
      }
      if (index === 3) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.diaChiNguoiHuong5.isVisible === false) {
            this.diaChiNguoiHuong5.isVisible = true;
            this.addOneLineDiaChiNguoiHuong();
          }
          this.diaChiNguoiHuong5.setFocus(true);
        }
      }
      if (index === 4) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.diaChiNguoiHuong6.isVisible === false) {
            this.diaChiNguoiHuong6.isVisible = true;
            this.addOneLineDiaChiNguoiHuong();
          }
          this.diaChiNguoiHuong6.setFocus(true);
        }
      }
    };
  },
  setNoiDungThanhToanTextBoxKeyUp() {
    for (let i = 0; i < this.amountOfLineNoiDungChuyenTien - 1; i++) {
      const textBox = this.noiDungChuyenTienTextBoxs[i];
      const index = i;
      textBox.onTextChange = (textBox) => {
        const text = $trim(textBox.text);
        if (text.length > 0 && text[0] === "-") {
          this.showErrorMessage("Vui lòng không nhập - ở đầu dòng.");
          return;
        }
        if ($isContainsVietnamese(text)) {
          this.showErrorMessage("Vui lòng nhập tiếng Anh.");
          return;
        }
      };
      if (index === 0) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length == 35) {
          if (this.noiDungChuyenTien2.isVisible === false) {
            this.noiDungChuyenTien2.isVisible = true;
            this.addOneLineNoiDungThanhToan();
          }
          this.noiDungChuyenTien2.setFocus(true);
        }
      }
      if (index === 1) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.noiDungChuyenTien3.isVisible === false) {
            this.noiDungChuyenTien3.isVisible = true;
            this.addOneLineNoiDungThanhToan();
          }
          this.noiDungChuyenTien3.setFocus(true);
        }
      }
      if (index === 2) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.noiDungChuyenTien4.isVisible === false) {
            this.noiDungChuyenTien4.isVisible = true;
            this.addOneLineNoiDungThanhToan();
          }
          this.noiDungChuyenTien4.setFocus(true);
        }
      }
      if (index === 3) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.noiDungChuyenTien5.isVisible === false) {
            this.noiDungChuyenTien5.isVisible = true;
            this.addOneLineNoiDungThanhToan();
          }
          this.noiDungChuyenTien5.setFocus(true);
        }
      }
      if (index === 4) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.noiDungChuyenTien6.isVisible === false) {
            this.noiDungChuyenTien6.isVisible = true;
            this.addOneLineNoiDungThanhToan();
          }
          this.noiDungChuyenTien6.setFocus(true);
        }
      }
      if (index === 5) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.noiDungChuyenTien7.isVisible === false) {
            this.noiDungChuyenTien7.isVisible = true;
            this.addOneLineNoiDungThanhToan();
          }
          this.noiDungChuyenTien7.setFocus(true);
        }
      }
      if (index === 6) textBox.onKeyUp = (textBox) => {
        if (textBox.text.length === 35) {
          if (this.noiDungChuyenTien8.isVisible === false) {
            this.noiDungChuyenTien8.isVisible = true;
            this.addOneLineNoiDungThanhToan();
          }
          this.noiDungChuyenTien8.setFocus(true);
        }
      }
    };
  },
  showPopup(message, confirm = () => { }, cancel = () => { }) {
    this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = true;
    this.view.CopyflxPopUpTopColor0e442b9b0742843.skin =
      DEFAULT_SKIN.WarningPopup;
    this.view.CopylblPopUpMainMessage0g3eda8bde3854e.text = message;
    this.view.CopybtnPopUpSave0cabfb6db5c5347.onClick = () => {
      this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
      confirm();
    };
    this.view.CopybtnPopUpCancel0f3298c2214fe47.onClick = () => {
      this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
      cancel()
    };
    this.view.CopyflxPopUpClose0b9f4641e1b4845.onClick = () => {
      this.view.CopyflxPopupContainer0if9c0d9a82d247.isVisible = false;
      cancel()
    }
    this.view.forceLayout();
  },
  showProcessLog(processLogData) {
    this.view.TabPanel.CopyFlexContainer0f9a94bcb4a9148.isVisible = true
    //xóa data trước đó
    const div = document.getElementById("frmDetailAndLog_TabPanel_FlexContainer0e87ac447008144");
    div.innerHTML = "";
    if (processLogData.length) {
      //Hiển thị process log
      //tạo header
      const flxHeader = $createFlexContainer(null, { skin: "processLog__header" })
      const lbType = $createLabel("Type", { skin: "processLog__header-item" })
      flxHeader.add(lbType)
      const lbStartTime = $createLabel("Start time", { skin: "processLog__header-item" })
      flxHeader.add(lbStartTime)
      const lbEndTime = $createLabel("End time", { skin: "processLog__header-item" })
      flxHeader.add(lbEndTime)
      const lbResponseData = $createLabel("Status", { skin: "processLog__header-item" })
      flxHeader.add(lbResponseData)
      const lbTransactionId = $createLabel("Transaction id", { skin: "processLog__header-item" })
      flxHeader.add(lbTransactionId)
      this.view.TabPanel.FlexContainer0e87ac447008144.add(flxHeader)
      //tạo body
      const flxBody = $createFlexContainer(null, { skin: "processLog__body" })
      const renderStatusResponse = (item) => {
        const parseData = JSON.parse(item.responseData)
        switch (item.type) {
          case TYPE_PROCESS_LOG.createFTPvcombank: return parseData.status == 400 ? parseData.title : parseData.successIndicator;
          case TYPE_PROCESS_LOG.createPaymentNium: return parseData.code === 400 ? parseData.title : parseData.description;
          case TYPE_PROCESS_LOG.createBookFxByCurrency: return parseData.description;
          case TYPE_PROCESS_LOG.thuPhiNgoaiGiaoDich: return parseData.successIndicator
          case TYPE_PROCESS_LOG.createFXPvcombank: return parseData.description
          case TYPE_PROCESS_LOG.createFX1Pvcombank: return parseData.description
          case TYPE_PROCESS_LOG.createFX2Pvcombank: return parseData.description
        }
      }
      const tenButToan = {
        createFX1Pvcombank: "FX mua bán với khách hàng",
        thuPhiNgoaiGiaoDich: "Thu phí khách hàng",
        createBookFxByCurrency: "Book Fx Nium",
        createFX2Pvcombank: "FX mua bán với Nium",
        createPaymentNium: "Tạo giao dịch với Nium",
        createFTPvcombank: "FT",
      }
      processLogData.map(item => {
        const flxBodyItem = $createFlexContainer(null, { skin: "processLog__body-box" })
        const txtType = $createLabel(tenButToan[item.type], { skin: "processLog__body-item" })
        flxBodyItem.add(txtType)
        const txtStartTime = $createLabel($convertToHmsDDMMYYYY(item.startTime), { skin: "processLog__body-item" })
        flxBodyItem.add(txtStartTime)
        const txtEndTime = $createLabel($convertToHmsDDMMYYYY(item.endTime), { skin: "processLog__body-item" })
        flxBodyItem.add(txtEndTime)
        const status = renderStatusResponse(item).includes("Success") ? "Success" : "Fail";
        const txtResponseData = $createLabel(status, { skin: `processLog__body-item ${status === "Success" ? "greenLabel" : "skinRedLabel"}` })
        flxBodyItem.add(txtResponseData)
        const txtTransactionId = $createLabel(item.transactionId, { skin: "processLog__body-item" })
        flxBodyItem.add(txtTransactionId)
        flxBody.add(flxBodyItem)
      })
      this.view.TabPanel.FlexContainer0e87ac447008144.add(flxBody)
    } else {
      const lbNoData = $createLabel("Không có dữ liệu")
      this.view.TabPanel.FlexContainer0e87ac447008144.add(lbNoData)
    }
  },
  isHoSoCompleted(status) {
    if (status === FUND_TRANSFER_STATUS.Completed || status === FUND_TRANSFER_STATUS.NotCompleted || status === FUND_TRANSFER_STATUS.AwaitingFunds || status === FUND_TRANSFER_STATUS.confirm) {
      return true;
    }
    return false;
  }
});
