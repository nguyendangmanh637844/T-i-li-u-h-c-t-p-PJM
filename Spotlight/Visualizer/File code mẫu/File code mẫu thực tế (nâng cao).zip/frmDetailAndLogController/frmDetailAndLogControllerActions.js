define({
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_e198d192c036405c9eef2a56644381fb: function AS_Button_e198d192c036405c9eef2a56644381fb(eventobject) {
        var self = this;
    },
    AS_DataGrid_f22a2c0cd4e84438821f5660027f9787: function AS_DataGrid_f22a2c0cd4e84438821f5660027f9787(eventobject) {
        var self = this;
        this.handleClickRowHistory(eventobject);
    },
    AS_Tab_b3c023d7a51345f5ac3de613c672c38c: function AS_Tab_b3c023d7a51345f5ac3de613c672c38c(eventobject) {
        var self = this;
    },
    AS_Tab_ba3c38666ab249f0984b4010b8c49960: function AS_Tab_ba3c38666ab249f0984b4010b8c49960(eventobject) {
        var self = this;
    },
    AS_TabPane_ab0eaf3e10864fd2b5338b133d43d12e: function AS_TabPane_ab0eaf3e10864fd2b5338b133d43d12e(eventobject, currentindex, isexpanded) {
        var self = this;
        this.onTabSelected(currentindex);
    },
    AS_Form_a4ab087362174e0d956484840c7319ec: function AS_Form_a4ab087362174e0d956484840c7319ec(eventobject) {
        var self = this;
        this.postShowActions();
    },
    AS_Form_j258c33374c54482b870948d353a799b: function AS_Form_j258c33374c54482b870948d353a799b(eventobject) {
        var self = this;
        this.preShowActions();
    }
});